import React, { useState, useEffect } from "react";
import { 
  Home, 
  LayoutDashboard, 
  PlusCircle, 
  HelpCircle, 
  Activity, 
  FileText, 
  History, 
  LineChart, 
  Video, 
  User, 
  ShieldAlert, 
  Menu, 
  X, 
  Radio,
  Sparkles,
  Lock,
  Unlock,
  Bell
} from "lucide-react";

import { MedicalScan, WellnessRecord } from "./types";
import HomeView from "./components/HomeView";
import DashboardView from "./components/DashboardView";
import ImageAnalysisView from "./components/ImageAnalysisView";
import AiAssistantView from "./components/AiAssistantView";
import WellnessMonitoringView from "./components/WellnessMonitoringView";
import ReportsView from "./components/ReportsView";
import HistoryListView from "./components/HistoryListView";
import AnalyticsView from "./components/AnalyticsView";
import TelemedicineView from "./components/TelemedicineView";
import ProfileView from "./components/ProfileView";
import AdminPanel from "./components/AdminPanel";
import ClinicalIntelligenceSuite from "./components/ClinicalIntelligenceSuite";
import FuturisticBackground from "./components/FuturisticBackground";
import BiometricLock from "./components/BiometricLock";

export default function App() {
  const [activeTab, setActiveTab] = useState<string>("Home");
  const [scans, setScans] = useState<MedicalScan[]>([]);
  const [wellness, setWellness] = useState<WellnessRecord[]>([]);
  const [selectedScan, setSelectedScan] = useState<MedicalScan | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);
  const [isBiometricAuthenticated, setIsBiometricAuthenticated] = useState<boolean>(false);

  // Notification states & unacknowledged track list
  const [acknowledgedScanIds, setAcknowledgedScanIds] = useState<string[]>([]);
  const [acknowledgedWellnessIds, setAcknowledgedWellnessIds] = useState<string[]>([]);
  const [isNotificationCenterOpen, setIsNotificationCenterOpen] = useState<boolean>(false);

  // Derive active alert lists from scans and wellness arrays
  const activeAlertsForScans = scans.filter(s => s.riskLevel === 'High' && !acknowledgedScanIds.includes(s.id));
  const pendingScansList = scans.filter(s => s.status === 'Pending');
  const activeAlertsForWellness = wellness.filter(w => 
    (w.heartRate > 100 || w.heartRate < 50 || w.systolicBP >= 140 || w.diastolicBP >= 90) && 
    !acknowledgedWellnessIds.includes(w.id)
  );

  const totalUnacknowledgedAlertsCount = activeAlertsForScans.length + pendingScansList.length + activeAlertsForWellness.length;

  const handleClearScanAlert = (id: string) => {
    setAcknowledgedScanIds(prev => [...prev, id]);
  };

  const handleClearWellnessAlert = (id: string) => {
    setAcknowledgedWellnessIds(prev => [...prev, id]);
  };

  const handleClearAllAlerts = () => {
    setAcknowledgedScanIds(prev => [...prev, ...activeAlertsForScans.map(s => s.id)]);
    setAcknowledgedWellnessIds(prev => [...prev, ...activeAlertsForWellness.map(w => w.id)]);
  };

  const SENSITIVE_TABS = [
    "Dashboard", 
    "Image Analysis", 
    "Clinical Suite", 
    "Reports", 
    "History", 
    "Analytics", 
    "Admin Panel"
  ];

  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    return (localStorage.getItem("clinical-theme") as 'dark' | 'light') || "dark";
  });

  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === "light") {
      root.classList.add("light-theme");
      root.classList.remove("dark");
    } else {
      root.classList.remove("light-theme");
      root.classList.add("dark");
    }
    localStorage.setItem("clinical-theme", theme);
  }, [theme]);

  // Email injected by platform or fallback standard onc email
  const clinicianEmail = "av7065304@gmail.com";

  // Navigation schema matches requirements
  const navigationItems = [
    { name: "Home", icon: Home },
    { name: "Dashboard", icon: LayoutDashboard },
    { name: "Image Analysis", icon: PlusCircle },
    { name: "Clinical Suite", icon: Sparkles },
    { name: "AI Assistant", icon: HelpCircle },
    { name: "Wellness Monitoring", icon: Activity },
    { name: "Reports", icon: FileText },
    { name: "History", icon: History },
    { name: "Analytics", icon: LineChart },
    { name: "Telemedicine", icon: Video },
    { name: "Profile", icon: User },
    { name: "Admin Panel", icon: ShieldAlert }
  ];

  // Fetch scans and wellness indicators from backend Express routes
  const loadClinicalData = async () => {
    try {
      const responseScans = await fetch("/api/scans");
      if (responseScans.ok) {
        setScans(await responseScans.json());
      }
      const responseWel = await fetch("/api/wellness");
      if (responseWel.ok) {
        setWellness(await responseWel.json());
      }
    } catch (err) {
      console.error("Clinical fetching failure", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadClinicalData();
  }, []);

  const handleScanSaved = (newScan: MedicalScan) => {
    setScans(prev => [newScan, ...prev]);
  };

  const handleAddWellness = async (newRecord: WellnessRecord) => {
    try {
      const response = await fetch("/api/wellness", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newRecord)
      });
      if (response.ok) {
        const savedRecord = await response.json();
        setWellness(prev => [...prev.filter(w => w.id !== newRecord.id), savedRecord]);
      } else {
        setWellness(prev => [...prev, newRecord]);
      }
    } catch (err) {
      console.error("Failed to save wellness record to API", err);
      setWellness(prev => [...prev, newRecord]);
    }
  };

  const handleDeleteScan = (id: string) => {
    setScans(prev => prev.filter(s => s.id !== id));
  };

  const handleUpdateScanNotes = (id: string, notes: string) => {
    setScans(prev => prev.map(s => s.id === id ? { ...s, notes } : s));
  };

  // Launch XAI / detailed view overlay trigger
  const handleSelectScanForAnalysis = (scan: MedicalScan) => {
    setSelectedScan(scan);
    setActiveTab("Image Analysis");
  };

  return (
    <div className={`min-h-screen font-sans flex flex-col md:flex-row antialiased transition-colors duration-300 relative ${
      theme === "light" ? "bg-slate-50 text-slate-900" : "bg-slate-950 text-slate-100"
    }`}>
      {/* Premium Artificial Intelligence Backdrop */}
      <FuturisticBackground theme={theme} />
      
      {/* Sidebar Navigation Bar */}
      <aside className="w-full md:w-64 max-w-xs shrink-0 bg-slate-900 border-b md:border-b-0 md:border-r border-slate-800 flex flex-col justify-between py-6 md:h-screen sticky top-0 z-40">
        <div className="space-y-6">
          
          {/* Clinic Branding Head */}
          <div className="px-6 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-teal-500/10 text-teal-400 border border-teal-500/25 rounded-xl">
                <Radio className="w-5 h-5 animate-pulse" />
              </div>
              <div className="text-left">
                <h1 className="font-bold text-base leading-none tracking-tight font-sans">CancerVision <span className="text-teal-400 font-extrabold text-sm font-mono block mt-0.5">ONCOLOGY AI</span></h1>
              </div>
            </div>

            {/* Mobile Menu Toggle */}
            <button 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)} 
              className="md:hidden p-1.5 text-slate-400 hover:text-white rounded"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

          {/* Links Nav */}
          <nav className={`px-4 space-y-1 ${mobileMenuOpen ? "block" : "hidden md:block"}`}>
            {navigationItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.name;

              // Compute badge counters and styling for specific clinical navigation items
              let badgeCount = 0;
              let badgeColor = "bg-rose-500/20 text-red-400 border border-red-500/30";
              let badgeLabel = "";

              if (item.name === "Dashboard") {
                badgeCount = activeAlertsForScans.length + activeAlertsForWellness.length;
                badgeColor = "bg-red-500 text-slate-950 font-bold animate-pulse px-1.5 rounded-full";
              } else if (item.name === "Image Analysis") {
                badgeCount = pendingScansList.length;
                badgeColor = "text-yellow-400 bg-yellow-500/10 border border-yellow-500/25";
                if (badgeCount > 0) badgeLabel = "QUEUED";
              } else if (item.name === "Wellness Monitoring") {
                badgeCount = activeAlertsForWellness.length;
                badgeColor = "text-amber-400 bg-amber-500/10 border border-amber-500/25 animate-pulse font-bold";
                if (badgeCount > 0) badgeLabel = "! URGENT";
              } else if (item.name === "History") {
                badgeCount = activeAlertsForScans.length;
                badgeColor = "text-red-400 bg-red-500/10 border border-red-500/25 font-bold";
              }

              return (
                <button
                  key={item.name}
                  id={`nav-tab-${item.name.replace(/\s+/g, '-').toLowerCase()}`}
                  onClick={() => {
                    setActiveTab(item.name);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-left text-xs font-semibold transition-all duration-200 uppercase font-mono tracking-wider ${
                    isActive 
                      ? "bg-teal-500/10 text-teal-400 border border-teal-500/20" 
                      : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/40"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-teal-400' : 'text-slate-400'}`} />
                    <span>{item.name}</span>
                  </div>
                  {badgeCount > 0 && (
                    <span className={`px-1.5 py-0.5 text-[8.5px] font-sans rounded-md select-none shrink-0 ${badgeColor}`}>
                      {badgeLabel || badgeCount}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Clinician Profile Summary Foot */}
        <div className="px-5 hidden md:block border-t border-slate-800/80 pt-4 text-left">
          <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block font-mono">Assigned Oncologist</span>
          <p className="text-xs font-bold text-slate-350 truncate">{clinicianEmail}</p>
          <div className="flex flex-col gap-2 mt-2.5">
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full ${isBiometricAuthenticated ? 'bg-teal-400' : 'bg-rose-500 animate-pulse'}`} />
              <span className={`text-[10px] font-semibold font-mono tracking-wide uppercase ${isBiometricAuthenticated ? 'text-teal-400' : 'text-rose-400'}`}>
                {isBiometricAuthenticated ? 'Registry Decrypted' : 'Registry Locked'}
              </span>
            </div>
            {isBiometricAuthenticated ? (
              <button
                type="button"
                onClick={() => setIsBiometricAuthenticated(false)}
                className="w-full bg-slate-950/80 hover:bg-rose-950/20 text-rose-500 hover:text-rose-400 border border-slate-850 hover:border-rose-900 text-[10px] font-mono py-1 rounded-lg font-bold flex items-center justify-center gap-1 transition-all"
              >
                <Lock className="w-3 h-3" /> Lock Session
              </button>
            ) : (
              <span className="text-[9px] text-slate-500 font-mono italic">Bio-clearance required</span>
            )}
          </div>
        </div>
      </aside>

      {/* Main Content Stage */}
      <main className="flex-1 min-w-0 flex flex-col h-screen overflow-y-auto">
        
        {/* Top Header telemetry */}
        <header className="bg-slate-900/40 border-b border-slate-800/60 py-4 px-6 md:px-8 flex items-center justify-between sticky top-0 backdrop-blur-md z-30">
          <div className="flex items-center gap-3">
            <span className="text-slate-300 text-xs font-mono font-bold">{activeTab}</span>
          </div>

          <div className="flex items-center gap-4">
            {/* Interactive Notification Bell */}
            <div className="relative">
              <button
                type="button"
                id="header-notification-bell"
                onClick={() => setIsNotificationCenterOpen(!isNotificationCenterOpen)}
                className="p-1.5 rounded-full bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-teal-400 transition-all flex items-center justify-center relative cursor-pointer"
                title="View oncology alerts"
              >
                <Bell className="w-4 h-4" />
                {totalUnacknowledgedAlertsCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-600 border border-slate-950 rounded-full flex items-center justify-center text-[8px] font-sans font-bold text-white leading-none">
                    {totalUnacknowledgedAlertsCount}
                  </span>
                )}
              </button>

              {/* Notification Dropdown Portal */}
              {isNotificationCenterOpen && (
                <div className="absolute right-0 mt-3 w-80 sm:w-96 bg-slate-950 border border-slate-850 rounded-2xl shadow-2xl p-4 space-y-4 text-left z-50 animate-in fade-in duration-200">
                  <div className="flex items-center justify-between border-b border-slate-900 pb-2.5">
                    <h4 className="text-xs font-bold font-mono text-slate-200 flex items-center gap-1.5">
                      <Bell className="w-3.5 h-3.5 text-teal-400" />
                      ONCOLOGY TELEMETRY ALERTS
                    </h4>
                    <span className="text-[9.5px] text-slate-500 font-mono tracking-wide">{totalUnacknowledgedAlertsCount} UNRESOLVED</span>
                  </div>

                  <div className="space-y-3.5 max-h-[320px] overflow-y-auto pr-1">
                    {/* High-Risk/New Scans portion */}
                    {activeAlertsForScans.length > 0 && (
                      <div className="space-y-2">
                        <span className="text-[9.5px] text-slate-400 font-bold font-mono uppercase tracking-wider block border-l border-red-500 pl-1.5">New Patient Scans (High Risk)</span>
                        {activeAlertsForScans.map(scan => (
                          <div key={scan.id} className="bg-slate-905 border border-slate-850 hover:border-red-500/25 p-2.5 rounded-xl space-y-1 relative group text-left">
                            <div className="flex justify-between items-start">
                              <div>
                                <span className="text-xs font-bold text-white block truncate max-w-[150px]">{scan.patientName}</span>
                                <span className="text-[10px] text-slate-400 block font-mono mt-0.5">{scan.patientAge}y • {scan.patientSex} | {scan.scanType} Scan</span>
                              </div>
                              <span className="text-[10px] font-mono text-red-400 font-bold bg-red-950/40 px-1 py-0.5 rounded border border-red-500/20">High Risk</span>
                            </div>
                            <p className="text-[10px] text-slate-400 leading-normal line-clamp-1 italic">"{scan.prediction}"</p>
                            <div className="flex items-center justify-between pt-1.5 border-t border-slate-905 mt-1">
                              <button
                                type="button"
                                onClick={() => {
                                  setSelectedScan(scan);
                                  setActiveTab("Image Analysis");
                                  setIsNotificationCenterOpen(false);
                                }}
                                className="text-[9px] font-bold font-mono text-teal-400 hover:text-teal-300"
                              >
                                Examine XAI
                              </button>
                              <button
                                type="button"
                                onClick={() => handleClearScanAlert(scan.id)}
                                className="text-[9px] font-mono text-slate-500 hover:text-red-450"
                              >
                                Clear Alert
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Pending scans portion */}
                    {pendingScansList.length > 0 && (
                      <div className="space-y-2">
                        <span className="text-[9.5px] text-slate-400 font-bold font-mono uppercase tracking-wider block border-l border-yellow-500 pl-1.5">Unresolved Queues</span>
                        {pendingScansList.map(scan => (
                          <div key={scan.id} className="bg-slate-905 border border-slate-850 p-2.5 rounded-xl space-y-1 text-left">
                            <div className="flex justify-between items-start">
                              <span className="text-xs font-bold text-white block">{scan.patientName}</span>
                              <span className="text-[10px] font-mono text-yellow-405 font-bold bg-yellow-950/40 px-1 py-0.5 rounded border border-yellow-500/20">Pending</span>
                            </div>
                            <div className="flex justify-between items-center text-[10px] text-slate-500">
                              <span>Uploaded: {scan.date}</span>
                              <button
                                type="button"
                                onClick={() => {
                                  setSelectedScan(scan);
                                  setActiveTab("Image Analysis");
                                  setIsNotificationCenterOpen(false);
                                }}
                                className="text-[9px] font-bold font-mono text-teal-400 hover:text-teal-300"
                              >
                                Analyze Now
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Urgent Wellness indicators portion */}
                    {activeAlertsForWellness.length > 0 && (
                      <div className="space-y-2">
                        <span className="text-[9.5px] text-slate-400 font-bold font-mono uppercase tracking-wider block border-l border-amber-500 pl-1.5">Urgent Wellness Warnings</span>
                        {activeAlertsForWellness.map(rec => (
                          <div key={rec.id} className="bg-slate-905 border border-slate-850 hover:border-amber-500/25 p-2.5 rounded-xl space-y-1.5 text-left">
                            <div className="flex justify-between items-start">
                              <div>
                                <span className="text-xs font-bold text-amber-400 flex items-center gap-1">
                                  ⚠️ Cardio-Toxic / Vital Spike
                                </span>
                                <span className="text-[10px] text-slate-400 font-mono mt-0.5">Logged: {rec.date}</span>
                              </div>
                              <span className="text-[10px] font-mono bg-red-950/40 text-red-400 border border-red-500/20 px-1 py-0.5 rounded font-bold animate-pulse">Critical</span>
                            </div>
                            
                            <div className="grid grid-cols-2 gap-1.5 text-[10px] font-mono p-1.5 bg-slate-950 rounded-lg">
                              <div>
                                <span className="text-slate-500 block uppercase text-[8.5px]">Heart Rate</span>
                                <span className={rec.heartRate > 100 || rec.heartRate < 50 ? "text-red-400 font-bold" : "text-slate-300"}>
                                  {rec.heartRate} BPM
                                </span>
                              </div>
                              <div>
                                <span className="text-slate-500 block uppercase text-[8.5px]">Blood Pressure</span>
                                <span className={rec.systolicBP >= 140 || rec.diastolicBP >= 90 ? "text-red-400 font-bold" : "text-slate-300"}>
                                  {rec.systolicBP}/{rec.diastolicBP} mmHg
                                </span>
                              </div>
                            </div>

                            <div className="flex items-center justify-between pt-1 border-t border-slate-905">
                              <button
                                type="button"
                                onClick={() => {
                                  setActiveTab("Wellness Monitoring");
                                  setIsNotificationCenterOpen(false);
                                }}
                                className="text-[9px] font-bold font-mono text-teal-400 hover:text-teal-300"
                              >
                                Open Ledger
                              </button>
                              <button
                                type="button"
                                onClick={() => handleClearWellnessAlert(rec.id)}
                                className="text-[9px] font-mono text-slate-500 hover:text-red-450"
                              >
                                Dismiss Alert
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Empty State */}
                    {totalUnacknowledgedAlertsCount === 0 && (
                      <div className="py-8 text-center space-y-2">
                        <p className="text-emerald-450 font-mono font-bold text-xs uppercase">✓ System Status Nominal</p>
                        <p className="text-[10.5px] text-slate-500 font-medium leading-normal">All active triage files and wellness records acknowledged by physician.</p>
                      </div>
                    )}
                  </div>

                  {totalUnacknowledgedAlertsCount > 0 && (
                    <div className="pt-2 border-t border-slate-900">
                      <button
                        type="button"
                        onClick={handleClearAllAlerts}
                        className="w-full py-1.5 text-center text-[10px] font-mono font-bold uppercase tracking-wider text-teal-400 bg-slate-900 hover:bg-slate-850 rounded-xl transition-all border border-slate-800 cursor-pointer"
                      >
                        Acknowledge All Active Alerts ({totalUnacknowledgedAlertsCount})
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>

            <div className="h-6 w-px bg-slate-850 hidden sm:block" />

            {/* Lock Status indicator in top header */}
            <div className="flex items-center gap-1.5 bg-slate-950/80 border border-slate-850 px-2.5 py-1 rounded-full">
              {isBiometricAuthenticated ? (
                <>
                  <Unlock className="w-3 h-3 text-teal-400" />
                  <span className="text-[9px] text-teal-400 font-mono font-bold uppercase tracking-wider">BIO-AUTH GRANTED</span>
                </>
              ) : (
                <>
                  <Lock className="w-3 h-3 text-rose-400" />
                  <span className="text-[9px] text-rose-400 font-mono font-bold uppercase tracking-wider">REGISTRY SECURE</span>
                </>
              )}
            </div>

            <div className="h-6 w-px bg-slate-850 hidden sm:block" />
            <div className="hidden sm:flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-ping" />
              <span className="text-[10px] text-slate-400 font-mono tracking-wide">HIPAA CLOUD ACCESSIBLE</span>
            </div>
            <div className="h-6 w-px bg-slate-850 hidden sm:block" />
            <span className="text-[10px] text-slate-400 font-mono">UTC TIME: 2026-06-04</span>
          </div>
        </header>

        {/* Content body switcher */}
        <div className="p-6 md:p-8 flex-1">
          {isLoading ? (
            <div className="h-full flex flex-col items-center justify-center gap-3 py-24">
              <div className="w-10 h-10 border-4 border-teal-400 border-t-transparent rounded-full animate-spin" />
              <p className="text-sm font-mono text-slate-400 animate-pulse">Establishing clinical secure connection...</p>
            </div>
          ) : (
            <div className="max-w-7xl mx-auto h-full relative min-h-[500px]">
              {SENSITIVE_TABS.includes(activeTab) && !isBiometricAuthenticated ? (
                <BiometricLock onUnlock={() => setIsBiometricAuthenticated(true)} />
              ) : (
                <>
                  {activeTab === "Home" && (
                    <HomeView setActiveTab={setActiveTab} />
                  )}
                  {activeTab === "Dashboard" && (
                    <DashboardView 
                      scans={scans} 
                      wellness={wellness} 
                      onSelectScan={handleSelectScanForAnalysis}
                      setActiveTab={setActiveTab}
                    />
                  )}
                  {activeTab === "Image Analysis" && (
                    <ImageAnalysisView 
                      onScanSaved={handleScanSaved}
                      userEmail={clinicianEmail}
                    />
                  )}
                  {activeTab === "Clinical Suite" && (
                    <ClinicalIntelligenceSuite 
                      scans={scans}
                      theme={theme}
                    />
                  )}
                  {activeTab === "AI Assistant" && (
                    <AiAssistantView userEmail={clinicianEmail} />
                  )}
                  {activeTab === "Wellness Monitoring" && (
                    <WellnessMonitoringView 
                      wellness={wellness}
                      onAddRecord={handleAddWellness}
                    />
                  )}
                  {activeTab === "Reports" && (
                    <ReportsView scans={scans} />
                  )}
                  {activeTab === "History" && (
                    <HistoryListView 
                      scans={scans} 
                      onSelectScan={handleSelectScanForAnalysis}
                      onDeleteScan={handleDeleteScan}
                      onUpdateNotes={handleUpdateScanNotes}
                    />
                  )}
                  {activeTab === "Analytics" && (
                    <AnalyticsView />
                  )}
                  {activeTab === "Telemedicine" && (
                    <TelemedicineView />
                  )}
                  {activeTab === "Profile" && (
                    <ProfileView 
                      userEmail={clinicianEmail} 
                      theme={theme}
                      setTheme={setTheme}
                    />
                  )}
                  {activeTab === "Admin Panel" && (
                    <AdminPanel />
                  )}
                </>
              )}
            </div>
          )}
        </div>
      </main>

    </div>
  );
}
