import React, { useMemo } from "react";

interface FuturisticBackgroundProps {
  theme: "dark" | "light";
}

export default function FuturisticBackground({ theme }: FuturisticBackgroundProps) {
  const isDark = theme === "dark";

  // Coordinates and attributes for dynamic floating medical particles
  const particles = useMemo(() => {
    return [
      { id: 1, cx: "10%", cy: "15%", r: 3, color: "fill-cyan-400", duration: "14s" },
      { id: 2, cx: "85%", cy: "12%", r: 2, color: "fill-purple-400", duration: "18s" },
      { id: 3, cx: "20%", cy: "45%", r: 4, color: "fill-pink-500", duration: "22s" },
      { id: 4, cx: "75%", cy: "65%", r: 3, color: "fill-teal-300", duration: "16s" },
      { id: 5, cx: "40%", cy: "85%", r: 2.5, color: "fill-violet-400", duration: "25s" },
      { id: 6, cx: "90%", cy: "80%", r: 3.5, color: "fill-blue-450", duration: "19s" },
      { id: 7, cx: "65%", cy: "25%", r: 2, color: "fill-fuchsia-400", duration: "15s" },
      { id: 8, cx: "5%", cy: "75%", r: 4, color: "fill-emerald-450", duration: "21s" },
    ];
  }, []);

  const nodes = useMemo(() => {
    return [
      { id: 1, cx: "15%", cy: "25%", r: 4.5, drift: "animate-pulse" },
      { id: 2, cx: "30%", cy: "55%", r: 3, drift: "animate-[pulse_3s_infinite]" },
      { id: 3, cx: "82%", cy: "30%", r: 5, drift: "animate-[pulse_4s_infinite]" },
      { id: 4, cx: "72%", cy: "75%", r: 3.5, drift: "animate-[pulse_2.5s_infinite]" },
      { id: 5, cx: "48%", cy: "82%", r: 4, drift: "animate-[pulse_5s_infinite]" },
      { id: 6, cx: "94%", cy: "62%", r: 3, drift: "animate-pulse" },
      { id: 7, cx: "58%", cy: "18%", r: 3, drift: "animate-[pulse_3.5s_infinite]" },
    ];
  }, []);

  const lines = useMemo(() => {
    return [
      { x1: "15%", y1: "25%", x2: "30%", y2: "55%", delay: "0.2s" },
      { x1: "30%", y1: "55%", x2: "48%", y2: "82%", delay: "0.5s" },
      { x1: "82%", y1: "30%", x2: "94%", y2: "62%", delay: "0s" },
      { x1: "94%", y1: "62%", x2: "72%", y2: "75%", delay: "0.8s" },
      { x1: "72%", y1: "75%", x2: "48%", y2: "82%", delay: "0.3s" },
      { x1: "58%", y1: "18%", x2: "82%", y2: "30%", delay: "1.1s" },
    ];
  }, []);

  // Soft glowing neon coordinates (vibrant mix of pink, violet, blue, cyan and purple)
  const glowPoints = useMemo(() => {
    return [
      { style: "top-[-10%] left-[-5%] w-[45rem] h-[45rem] bg-indigo-500/15 rounded-full blur-[160px]" },
      { style: "bottom-[-10%] right-[-5%] w-[50rem] h-[50rem] bg-pink-500/10 rounded-full blur-[180px]" },
      { style: "top-[30%] right-[25%] w-[40rem] h-[40rem] bg-cyan-500/12 rounded-full blur-[150px]" },
      { style: "bottom-[20%] left-[20%] w-[38rem] h-[38rem] bg-violet-600/12 rounded-full blur-[140px]" },
    ];
  }, []);

  const activeEcgPath = "M 0 100 Q 50 100, 100 100 T 150 100 T 200 100 L 220 100 L 225 70 L 230 140 L 235 90 L 240 105 L 245 100 L 300 100 L 350 100 Q 400 100, 450 100 T 550 100 T 650 100 L 670 100 L 675 60 L 680 145 L 685 85 L 690 105 L 695 100 L 800 100 T 950 100 T 1100 100 L 1120 100 L 1125 70 L 1130 140 L 1135 90 L 1140 105 L 1145 100 L 1300 100 T 1500 100 Z";

  return (
    <div 
      className={`fixed inset-0 pointer-events-none select-none z-0 overflow-hidden transition-opacity duration-700 ${
        isDark ? "opacity-100" : "opacity-90"
      }`}
      id="futuristic-medical-tech-backdrop"
    >
      {/* 1. Global Vibrant Gradient Backdrop with Neon Undertones */}
      <div 
        className={`absolute inset-0 transition-all duration-500 ${
          isDark 
            ? "bg-slate-950 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-900/40 via-violet-950/15 via-slate-950 to-slate-950" 
            : "bg-slate-50 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-teal-50/20 via-slate-50 to-purple-50/10"
        }`}
      />

      {/* 2. Soft-glowing multicolored nebulas */}
      {glowPoints.map((glow, idx) => (
        <div key={idx} className={`absolute ${glow.style} animate-[pulse_12s_infinite_alternate]`} />
      ))}

      {/* 3. Tech Grid Pattern Layer */}
      <div 
        className="absolute inset-0" 
        style={{
          backgroundImage: isDark
            ? "radial-gradient(circle, rgba(99, 102, 241, 0.15) 1px, transparent 1px), linear-gradient(to right, rgba(56, 189, 248, 0.04) 1px, transparent 1px), linear-gradient(to bottom, rgba(168, 85, 247, 0.04) 1px, transparent 1px)"
            : "radial-gradient(circle, rgba(13, 148, 136, 0.08) 1px, transparent 1px), linear-gradient(to right, rgba(13, 148, 136, 0.02) 1px, transparent 1px), linear-gradient(to bottom, rgba(13, 148, 136, 0.02) 1px, transparent 1px)",
          backgroundSize: "36px 36px, 72px 72px, 72px 72px",
          backgroundPosition: "0 0",
          opacity: 0.8
        }}
      />

      {/* 4. Active Full-screen Holographic Laser Scanner bar */}
      <div className="absolute left-0 right-0 h-1 z-[2] bg-gradient-to-r from-transparent via-cyan-400 via-teal-300 via-pink-400 to-transparent shadow-[0_0_15px_rgba(34,211,238,0.8)] opacity-40 animate-[scantrack_15s_ease-in-out_infinite]" />

      {/* 5. SVG Interactive Biology Stage (Healthy cells, anomalous Cancer cells, and molecular structures) */}
      <div className="absolute inset-0 z-[1]">
        <svg className="w-full h-full">
          {/* Subtle connecting mesh */}
          {lines.map((line, idx) => (
            <line
              key={idx}
              x1={line.x1}
              y1={line.y1}
              x2={line.x2}
              y2={line.y2}
              stroke={isDark ? "url(#neon-line-grad)" : "#3b82f6"}
              strokeWidth="1"
              strokeOpacity={isDark ? "0.22" : "0.14"}
              className="animate-pulse"
              style={{ animationDelay: line.delay }}
            />
          ))}

          {/* Gradients definitions */}
          <defs>
            <linearGradient id="neon-line-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.4" />
              <stop offset="50%" stopColor="#ec4899" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#a855f7" stopOpacity="0.4" />
            </linearGradient>
            <radialGradient id="healthy-cell-grad" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.4" />
              <stop offset="60%" stopColor="#0ea5e9" stopOpacity="0.15" />
              <stop offset="100%" stopColor="#0284c7" stopOpacity="0" />
            </radialGradient>
            <radialGradient id="cancer-cell-grad" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#f43f5e" stopOpacity="0.5" />
              <stop offset="40%" stopColor="#d946ef" stopOpacity="0.2" />
              <stop offset="100%" stopColor="#9d174d" stopOpacity="0" />
            </radialGradient>
          </defs>

          {/* Holographic illustration of healthy cell structures */}
          <g className="animate-[float_28s_infinite] opacity-35">
            <circle cx="20%" cy="30%" r="32" fill="url(#healthy-cell-grad)" className="stroke-cyan-500/25" strokeWidth="1" strokeDasharray="3 3" />
            <circle cx="20%" cy="30%" r="10" fill="#0ea5e9" fillOpacity="0.1" className="stroke-cyan-400/50" />
            <circle cx="20%" cy="30%" r="4" fill="#22d3ee" className="animate-ping" />
          </g>
          <g className="animate-[float_34s_infinite_reverse] opacity-25" style={{ animationDelay: "5s" }}>
            <circle cx="80%" cy="65%" r="45" fill="url(#healthy-cell-grad)" className="stroke-teal-500/20" strokeWidth="1" strokeDasharray="4 2" />
            <circle cx="80%" cy="65%" r="14" fill="#0d9488" fillOpacity="0.1" className="stroke-teal-400/40" />
            <circle cx="79%" cy="64%" r="4" fill="#14b8a6" />
          </g>

          {/* Holographic illustration of mutant Cancer Cells (Atypical, Jagged, Multi-nucleated) */}
          <g className="animate-[float_22s_infinite] opacity-30" style={{ animationDelay: "3s" }}>
            <circle cx="70%" cy="20%" r="28" fill="url(#cancer-cell-grad)" className="stroke-rose-500/30" strokeWidth="1" />
            {/* Spiculed atypical projections */}
            <path d="M 69.5% 17% L 66% 12% M 70.5% 17% L 75% 11% M 67% 20% L 61% 19% M 73% 20% L 79% 21% M 68% 23% L 64% 28% M 72% 23% L 76% 27%" stroke="#ef4444" strokeWidth="1.2" strokeOpacity="0.5" />
            <circle cx="69%" cy="19%" r="6" fill="#f43f5e" fillOpacity="0.3" stroke="#e11d48" strokeWidth="1" />
            <circle cx="72%" cy="21%" r="5" fill="#ec4899" fillOpacity="0.3" stroke="#db2777" strokeWidth="1" />
          </g>

          {/* Floating medical microscopic particles */}
          {particles.map((p) => (
            <circle
              key={p.id}
              cx={p.cx}
              cy={p.cy}
              r={p.r}
              className={`${p.color} opacity-40 animate-[bubble_20s_infinite_linear]`}
              style={{
                animationDuration: p.duration,
              }}
            />
          ))}

          {/* Spheroid Cellular nodes in network */}
          {nodes.map((node) => (
            <g key={node.id} className={node.drift}>
              <circle
                cx={node.cx}
                cy={node.cy}
                r={node.r * 2.2}
                fill={isDark ? "rgba(99, 102, 241, 0.06)" : "rgba(13, 148, 136, 0.04)"}
              />
              <circle
                cx={node.cx}
                cy={node.cy}
                r={node.r}
                fill={isDark ? "#0ea5e9" : "#0d9488"}
                className="opacity-60"
              />
              <circle
                cx={node.cx}
                cy={node.cy}
                r={node.r * 4.5}
                fill="none"
                stroke={isDark ? "rgba(236, 72, 153, 0.08)" : "rgba(37, 99, 235, 0.04)"}
                strokeWidth="0.8"
                strokeDasharray="3 3"
              />
            </g>
          ))}
        </svg>
      </div>

      {/* 6. Abstract ECG Waves Pathway */}
      <div className={`absolute bottom-[8%] left-0 right-0 h-32 overflow-hidden ${isDark ? "opacity-20" : "opacity-10"}`}>
        <svg className="w-full h-full" viewBox="0 0 1500 200" preserveAspectRatio="none">
          <path
            d={activeEcgPath}
            fill="none"
            stroke={isDark ? "#38bdf8" : "#0d9488"}
            strokeWidth="1.2"
            strokeDasharray="1800"
            strokeDashoffset="1800"
            className="animate-[dash_60s_linear_infinite]"
          />
        </svg>
      </div>

      {/* 7. DNA Helix rotating in vertical column */}
      <div className={`absolute top-[20%] right-[3%] w-48 h-80 overflow-hidden hidden xl:block ${isDark ? "opacity-10" : "opacity-5"}`}>
        <svg viewBox="0 0 120 300" className="w-full h-full">
          {Array.from({ length: 11 }).map((_, i) => {
            const y = 30 + i * 24;
            const amp = 30;
            const rad1 = (i * Math.PI) / 3.5;
            const rad2 = rad1 + Math.PI;
            const x1 = 60 + Math.sin(rad1) * amp;
            const x2 = 60 + Math.sin(rad2) * amp;
            return (
              <g key={i}>
                <line x1={x1} y1={y} x2={x2} y2={y} stroke={isDark ? "#f472b6" : "#2563eb"} strokeWidth="1" strokeDasharray="1 3" />
                <circle cx={x1} cy={y} r="3" fill="#06b6d4" className="animate-pulse" />
                <circle cx={x2} cy={y} r="3" fill="#e879f9" className="animate-pulse" />
              </g>
            );
          })}
        </svg>
      </div>

      {/* 8. HD Academic Oncology Typographic Watermarks & Telemetry Overlay */}
      <div className={`absolute inset-0 font-mono text-[9px] md:text-[10px] tracking-[0.25em] uppercase pointer-events-none select-none z-[1] ${
        isDark ? "text-cyan-400/8 text-violet-400/6" : "text-slate-500/5"
      }`}>
        <div className="absolute top-[8%] left-[4%] -rotate-6">
          <span>ONCOLOGY NEURAL DECODE MATRIX // SgRNA-TP53 // APOPTOSIS RECRUITER</span>
        </div>
        <div className="absolute top-[48%] left-[2%] rotate-90 origin-top-left -translate-y-1/2 opacity-50">
          <span>MALIGNANCY INTEGRITY SCANNER [0.9928 ATTENTION ALIGN]</span>
        </div>
        <div className="absolute top-[28%] right-[8%] rotate-6">
          <span>GENOME SEGMENT-X94 CHROMOSOME 17P13.1 INDEL MUTATIONS</span>
        </div>
        <div className="absolute bottom-[35%] left-[8%] rotate-3">
          <span>ADENOCARCINOMA PATHWAY SURVEILLANCE // CYTO-RESIST ENSEMBLE</span>
        </div>
        <div className="absolute bottom-[5%] right-[3%]">
          <span>CANCERVISION DIAGNOSTIC CORE // NEURAL PIXEL WEIGHT SPICULAR</span>
        </div>
      </div>

      {/* Inject custom visual animation styles directly */}
      <style>{`
        @keyframes dash {
          to {
            stroke-dashoffset: -1800;
          }
        }
        @keyframes scantrack {
          0% { top: 3%; }
          50% { top: 97%; }
          100% { top: 3%; }
        }
        @keyframes float {
          0% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-12px) rotate(180deg); }
          100% { transform: translateY(0px) rotate(360deg); }
        }
        @keyframes bubble {
          0% { transform: translateY(0px) translateX(0px); opacity: 0.1; }
          40% { opacity: 0.45; }
          100% { transform: translateY(-160px) translateX(15px); opacity: 0; }
        }
      `}</style>
    </div>
  );
}
