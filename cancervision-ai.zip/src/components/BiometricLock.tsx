import React, { useState, useEffect } from "react";
import { 
  Fingerprint, 
  Lock, 
  Unlock, 
  ShieldAlert, 
  Eye, 
  Check, 
  RefreshCw, 
  User, 
  Activity, 
  ShieldCheck, 
  Key, 
  Info, 
  BellRing,
  Smartphone
} from "lucide-react";

interface BiometricLockProps {
  onUnlock: () => void;
  onLockStateChange?: (isLocked: boolean) => void;
}

export default function BiometricLock({ onUnlock, onLockStateChange }: BiometricLockProps) {
  const [scanType, setScanType] = useState<"fingerprint" | "facial" | "passcode">("fingerprint");
  const [scanStatus, setScanStatus] = useState<"idle" | "scanning" | "success" | "failed">("idle");
  const [progress, setProgress] = useState<number>(0);
  const [activeLogs, setActiveLogs] = useState<string[]>([]);
  const [passcode, setPasscode] = useState<string>("");
  const [attempts, setAttempts] = useState<number>(0);

  // Play satisfying UI audio feedback using Web Audio API (standard, lightweight)
  const playBeep = (freq: number, type: "sine" | "triangle" | "sawtooth" | "square", duration: number) => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(0.06, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch (e) {
      // Audio context block safely ignored
    }
  };

  // Add system telemetry feedback log line-by-line
  const addLog = (msg: string) => {
    setActiveLogs((prev) => [msg, ...prev.slice(0, 5)]);
  };

  // Trigger scanning sequence
  const startScanning = () => {
    if (scanStatus === "scanning" || scanStatus === "success") return;
    
    setScanStatus("scanning");
    setProgress(0);
    setActiveLogs([]);
    addLog("Initializing visual telemetry interface...");
    playBeep(440, "sine", 0.1);

    // Incremental progress loop simulating bio-signature inspection
    let currentProgress = 0;
    const interval = setInterval(() => {
      currentProgress += Math.floor(Math.random() * 15) + 5;
      if (currentProgress >= 100) {
        currentProgress = 100;
        clearInterval(interval);
        
        // Final evaluation
        setProgress(100);
        setScanStatus("success");
        addLog("Decimation match found. Patient credentials decrypted.");
        playBeep(880, "sine", 0.25);
        setTimeout(() => {
          playBeep(1200, "sine", 0.15);
        }, 100);

        // Notify parent after brief confirmation window
        setTimeout(() => {
          onUnlock();
          if (onLockStateChange) onLockStateChange(false);
        }, 1200);

      } else {
        setProgress(currentProgress);
        // Staged telemetry details
        if (currentProgress > 20 && currentProgress <= 45 && activeLogs.length === 1) {
          addLog(scanType === "fingerprint" 
            ? "Mapping friction ridge minutiae..." 
            : "Calibrating multi-point corneal geometry..."
          );
          playBeep(600, "triangle", 0.05);
        } else if (currentProgress > 45 && currentProgress <= 75 && activeLogs.length === 2) {
          addLog("Authorizing deep neural vector similarity...");
          playBeep(700, "triangle", 0.05);
        } else if (currentProgress > 75 && currentProgress < 95 && activeLogs.length === 3) {
          addLog("Verifying HSM medical cryptographic keys...");
          playBeep(800, "triangle", 0.05);
        }
      }
    }, 150);
  };

  // Passcode submission handling (Oncologist Emergency Bypass PIN: 7065)
  const handlePasscodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (passcode === "7065") {
      setScanStatus("success");
      addLog("Master clinical passcode matches credentials. Access granted.");
      playBeep(880, "sine", 0.2);
      setTimeout(() => {
        onUnlock();
        if (onLockStateChange) onLockStateChange(false);
      }, 1000);
    } else {
      setAttempts(prev => prev + 1);
      playBeep(220, "sawtooth", 0.35);
      addLog("ERR // Code invalid. Security integrity preserved.");
      setPasscode("");
      if (attempts >= 2) {
        addLog("CRITICAL: Multiple failures. Biometric locks loaded.");
      }
    }
  };

  const handleQuickFillCode = () => {
    setPasscode("7065");
  };

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center p-4" id="biometric-auth-lock-overlay">
      {/* Heavy Blur backdrop */}
      <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-xl" />

      {/* Main biometric module card */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 max-w-md w-full relative z-10 shadow-2xl text-center space-y-6 overflow-hidden">
        {/* Decorative corner indicators styled like high-tech targeting reticle */}
        <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-teal-500/40 rounded-tl-xl pointer-events-none" />
        <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-teal-500/40 rounded-tr-xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-teal-500/40 rounded-bl-xl pointer-events-none" />
        <div className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-teal-500/40 rounded-br-xl pointer-events-none" />

        {/* Lock Head */}
        <div className="flex flex-col items-center space-y-2">
          <div className="p-3.5 bg-rose-500/10 text-rose-400 border border-rose-500/20 rounded-full animate-pulse">
            <Lock className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-slate-100 text-lg font-bold tracking-tight uppercase font-sans">
              Clinical Registry Locked
            </h3>
            <p className="text-slate-400 text-xs mt-1 max-w-xs mx-auto">
              This panel contains HIPAA-regulated medical records. Biometric authentication is required to access files.
            </p>
          </div>
        </div>

        {/* Dynamic Mode Tabs */}
        <div className="flex bg-slate-950/80 p-0.5 rounded-xl border border-slate-850 justify-between items-center text-xs">
          <button 
            type="button"
            onClick={() => { setScanType("fingerprint"); setScanStatus("idle"); setProgress(0); }}
            className={`flex-1 py-1 px-1.5 rounded-lg flex items-center justify-center gap-1 font-mono uppercase text-[10px] tracking-wide transition-all ${
              scanType === "fingerprint" 
                ? "bg-teal-500 text-slate-950 font-black shadow-md" 
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            <Fingerprint className="w-3.5 h-3.5" />
            Ridge Scan
          </button>
          
          <button 
            type="button"
            onClick={() => { setScanType("facial"); setScanStatus("idle"); setProgress(0); }}
            className={`flex-1 py-1 px-1.5 rounded-lg flex items-center justify-center gap-1 font-mono uppercase text-[10px] tracking-wide transition-all ${
              scanType === "facial" 
                ? "bg-teal-500 text-slate-950 font-black shadow-md" 
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            Retinal Face
          </button>

          <button 
            type="button"
            onClick={() => { setScanType("passcode"); setScanStatus("idle"); }}
            className={`flex-1 py-1 px-1.5 rounded-lg flex items-center justify-center gap-1 font-mono uppercase text-[10px] tracking-wide transition-all ${
              scanType === "passcode" 
                ? "bg-teal-500 text-slate-950 font-black shadow-md" 
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            <Key className="w-3.5 h-3.5" />
            Manual PIN
          </button>
        </div>

        {/* main scanner visuals */}
        <div className="bg-slate-950/80 border border-slate-850 rounded-2xl p-6 min-h-[180px] flex flex-col justify-center items-center relative overflow-hidden">
          
          {scanType === "passcode" ? (
            <form onSubmit={handlePasscodeSubmit} className="w-full space-y-3.5">
              <span className="text-[10px] uppercase font-mono tracking-wider text-slate-500 block font-semibold text-center">
                Hospital Override Code
              </span>
              <div className="flex gap-2">
                <input 
                  type="password"
                  placeholder="••••"
                  value={passcode}
                  onChange={(e) => setPasscode(e.target.value)}
                  maxLength={4}
                  className="bg-slate-900 border border-slate-800 text-slate-100 text-center tracking-widest text-lg font-mono rounded-xl p-2.5 flex-1 focus:outline-none focus:border-teal-500"
                />
                <button 
                  type="submit"
                  className="bg-teal-500 text-slate-950 px-4 rounded-xl font-bold font-mono text-xs hover:bg-teal-400"
                >
                  Verify
                </button>
              </div>
              <div className="text-center">
                <button 
                  type="button"
                  onClick={handleQuickFillCode}
                  className="text-teal-400/80 hover:text-teal-300 text-[10px] font-mono underline"
                >
                  Retrieve Clinician Master PIN (7065)
                </button>
              </div>
            </form>
          ) : (
            // Scanning interactive viewport
            <div className="relative flex flex-col items-center">
              
              {/* Scan target circle with anims */}
              <button
                type="button"
                onClick={startScanning}
                disabled={scanStatus === "scanning" || scanStatus === "success"}
                className={`w-24 h-24 rounded-full border-2 flex items-center justify-center relative group transition-all duration-300 ${
                  scanStatus === "scanning" 
                    ? "border-teal-400/90 bg-teal-500/5 animate-pulse" 
                    : scanStatus === "success" 
                    ? "border-emerald-400 bg-emerald-500/10 text-emerald-400" 
                    : "border-slate-800 hover:border-teal-500/80 bg-slate-900 hover:bg-teal-500/3 cursor-pointer text-slate-400 hover:text-teal-400"
                }`}
                id="interactive-biometric-circle-btn"
              >
                {/* Horizontal scanner beam line overlay (only during scan) */}
                {scanStatus === "scanning" && (
                  <div className="absolute left-0 right-0 h-0.5 bg-teal-400 opacity-90 animate-[bounce_1.8s_infinite] shadow-[0_0_12px_rgba(20,184,166,0.8)]" />
                )}

                {scanStatus === "success" ? (
                  <Check className="w-10 h-10 animate-bounce" />
                ) : scanType === "fingerprint" ? (
                  <Fingerprint className={`w-12 h-12 transition-transform ${scanStatus === "scanning" ? "scale-95 text-teal-400" : "group-hover:scale-105"}`} />
                ) : (
                  <Eye className={`w-12 h-12 transition-transform ${scanStatus === "scanning" ? "scale-95 text-teal-400" : "group-hover:scale-105"}`} />
                )}
              </button>

              <span className="text-[10px] font-mono text-slate-500 mt-4 uppercase tracking-widest block">
                {scanStatus === "scanning" ? (
                  <span className="text-teal-400">Inspecting Signature... {progress}%</span>
                ) : scanStatus === "success" ? (
                  <span className="text-emerald-400 font-bold">Session Access Granted</span>
                ) : (
                  "Tap Scanner To Scan Biometrics"
                )}
              </span>
            </div>
          )}

        </div>

        {/* Real-time encryption subsystem logs */}
        <div className="bg-slate-950 p-3 rounded-2xl border border-slate-850/65 text-left text-[10px] font-mono h-24 overflow-y-auto space-y-1 select-none">
          <span className="text-[9px] uppercase font-bold text-slate-500 tracking-wider block border-b border-slate-900 pb-1.5 mb-1.5">
            🔑 Biometric Subsystem Protocol Output
          </span>
          {activeLogs.length === 0 ? (
            <div className="text-slate-600 italic">Waiting for authentication trigger sequence...</div>
          ) : (
            activeLogs.map((log, idx) => (
              <div key={idx} className={`${log.startsWith("ERR") ? "text-rose-400" : log.startsWith("CRITICAL") ? "text-purple-400 font-bold" : idx === 0 ? "text-teal-400" : "text-slate-500"}`}>
                &gt; {log}
              </div>
            ))
          )}
        </div>

        {/* HIPAA compliance label */}
        <div className="flex items-center gap-2 bg-slate-950/40 p-2.5 rounded-xl text-[10px] text-slate-400 font-medium">
          <Info className="w-3.5 h-3.5 text-teal-400 shrink-0" />
          <p className="leading-tight text-left">
            Clinician authorization sessions expire automatically after tab reload to prevent physical device intrusion.
          </p>
        </div>

      </div>
    </div>
  );
}
