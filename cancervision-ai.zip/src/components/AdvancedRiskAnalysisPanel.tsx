import React, { useState, useMemo } from "react";
import { CancerType, RiskLevel } from "../types";
import { 
  TrendingUp, 
  ShieldAlert, 
  Heart, 
  Activity, 
  Flame, 
  Clock, 
  Sparkles, 
  Dna, 
  BriefcaseMedical, 
  BookOpen, 
  Info, 
  HeartPulse, 
  Scale, 
  Gauge, 
  Sliders, 
  CheckCircle2, 
  AlertTriangle 
} from "lucide-react";

interface AdvancedRiskAnalysisPanelProps {
  cancerType: CancerType;
  riskLevel: RiskLevel;
  confidence: number;
  patientAge: number;
  patientSex: string;
}

export default function AdvancedRiskAnalysisPanel({
  cancerType,
  riskLevel,
  confidence,
  patientAge,
  patientSex
}: AdvancedRiskAnalysisPanelProps) {
  // Clinician Simulator modifiers for the advanced interactive experience
  const [therapyModifier, setTherapyModifier] = useState<"standard" | "immunotherapy" | "targeted">("standard");
  const [earlyDetectionBoost, setEarlyDetectionBoost] = useState<boolean>(true);
  const [selectedYearParam, setSelectedYearParam] = useState<number | null>(5);
  const [hoveredYear, setHoveredYear] = useState<number | null>(null);

  // Derive stage automatically if not overridden
  const stage = useMemo(() => {
    if (riskLevel === "High") {
      return patientAge > 65 ? "Stage IV" : "Stage III";
    } else if (riskLevel === "Medium") {
      return "Stage II";
    } else {
      return "Stage I";
    }
  }, [riskLevel, patientAge]);

  // Comprehensive static data map per cancer type to power clinical parameters with realistic statistics
  const baseStats = useMemo(() => {
    const statsMap: Record<string, {
      baseSurvival: number; // base 5-year survival rate (%)
      severity: number; // base severity rating (%)
      aggressiveness: number; // baseline tumor growth speed (1 to 10 scale)
      earlyDetectedAdvantage: number; // percentage survival bonus for ultra-early detection
      lifestyleFactors: { icon: string; title: string; desc: string }[];
    }> = {
      "Brain Tumor": {
        baseSurvival: 36,
        severity: 78,
        aggressiveness: 8.4,
        earlyDetectedAdvantage: 35,
        lifestyleFactors: [
          { icon: "🧠", title: "Neurological Surveillance", desc: "Periodic high-field strength MRI (3T) ensures early identification of fluid accumulation surrounding potential edema tissue." },
          { icon: "🛡️", title: "Oxidative Balance", desc: "Reducing direct neuro-inflammatory factors through target omega-3 fatty acids and standard ketogenic support protocols." },
          { icon: "⚡", title: "Cognitive Load", desc: "Maintaining standard neuro-rehabilitative exercises to strengthen neural plasticity during therapeutic interventions." }
        ]
      },
      "Lung Cancer": {
        baseSurvival: 23,
        severity: 85,
        aggressiveness: 9.1,
        earlyDetectedAdvantage: 48,
        lifestyleFactors: [
          { icon: "🫁", title: "Pulmonary Hygiene", desc: "Immediate cessation of all tobacco, vape, or particle exposure. Implement standard HEPA filtration in key environments." },
          { icon: "🏃", title: "Cardiorespiratory Fitness", desc: "Standard low-impact aerobic thresholds improve oxygen saturation and lung capacity, preparing parenchymal reserves." },
          { icon: "🥦", title: "Antioxidant Ingestion", desc: "Increasing dietary cruciferous vegetables containing standard sulforaphanes to assist cellular repair mechanisms." }
        ]
      },
      "Breast Cancer": {
        baseSurvival: 90,
        severity: 42,
        aggressiveness: 4.8,
        earlyDetectedAdvantage: 25,
        lifestyleFactors: [
          { icon: "🩸", title: "Endocrine Monitoring", desc: "Tracking estrogen/progesterone pathways and avoiding phytoestrogen concentrates where endocrine receptor statuses indicate positive matches." },
          { icon: "⚖️", title: "Adipose Regulation", desc: "Maintaining a standard body mass index reduces peripheral estrogen conversion within fatty tissues." },
          { icon: "🥗", title: "Anti-Inflammatory Intake", desc: "Emphasizing a Mediterranean clinical nutrition framework rich in monounsaturated fats and natural polyphenols." }
        ]
      },
      "Skin Cancer": {
        baseSurvival: 93,
        severity: 28,
        aggressiveness: 3.2,
        earlyDetectedAdvantage: 15,
        lifestyleFactors: [
          { icon: "☀️", title: "UV Radiance Shielding", desc: "Rigid daily application of medical-grade mineral sunscreen SPF 50+ and complete physical barrier gear during peak UV periods." },
          { icon: "🔍", title: "Dermatological Mapping", desc: "Regular self-exams following the ABCDE clinical melanoma criteria paired with serial professional dermoscopy." },
          { icon: "🍃", title: "Immune Enhancements", desc: "Ensuring adequate Vitamin D3 synthesis or clinical supplementation to support natural cutaneous immune surveillance." }
        ]
      },
      "Colon Cancer": {
        baseSurvival: 65,
        severity: 58,
        aggressiveness: 5.9,
        earlyDetectedAdvantage: 30,
        lifestyleFactors: [
          { icon: "🥕", title: "Prebiotic Fiber Load", desc: "Daily ingestion of 30g+ soluble and insoluble fibers to optimize gut microflora motility and standard short-chain fatty acid levels." },
          { icon: "🥩", title: "Red Meat Cessation", desc: "Eliminating cured nitrosamines and heavily charred meats that present high direct mutational risk in bowel epithelium." },
          { icon: "🩺", title: "Endoscopic Auditing", desc: "Periodic high-definition colonoscopy to detect and completely ablate precancerous neoplastic adenomas early." }
        ]
      },
      "Pancreatic Cancer": {
        baseSurvival: 11,
        severity: 94,
        aggressiveness: 9.6,
        earlyDetectedAdvantage: 50,
        lifestyleFactors: [
          { icon: "🍬", title: "Glycemic Stability", desc: "Rigid monitoring of metabolic indices to avoid insulin hyper-secretion which can promote ductal neoplasia stimulation." },
          { icon: "🍷", title: "Pancreatic Rest", desc: "Complete elimination of ethanol and highly refined glucose concentrates to minimize tissue digestive enzyme strain." },
          { icon: "🥬", title: "Enzymatic Optimization", desc: "Integrating clinical pancreatic enzyme replacement therapies where ductal blockages reduce normal absorption." }
        ]
      }
    };

    // Return specific mapping or evaluate dynamic baseline based on cancer type name
    const resolvedName = statsMap[cancerType] ? cancerType : "Default";
    if (resolvedName === "Default") {
      // Dynamic fallback generator based on string hashing of cancer type for stable realistic numbers
      let hash = 0;
      for (let i = 0; i < cancerType.length; i++) {
        hash += cancerType.charCodeAt(i);
      }
      const isAggressive = hash % 2 === 0;
      const baseSurvival = Math.max(15, Math.min(88, 75 - (hash % 45)));
      const severity = Math.max(30, Math.min(92, 40 + (hash % 50)));
      const aggressiveness = Number((4.5 + (hash % 5) + (isAggressive ? 1.5 : -1)).toFixed(1));
      const earlyDetectedAdvantage = Math.max(15, Math.min(45, 20 + (hash % 25)));

      return {
        baseSurvival,
        severity,
        aggressiveness,
        earlyDetectedAdvantage,
        lifestyleFactors: [
          { icon: "📋", title: "Integrated Surveillance", desc: `Establish standard imaging frequency for early stage mapping of potential cellular mutation pathways.` },
          { icon: "🍎", title: "Nutritional Fortification", desc: `Adopt diet protocols focused on cellular membrane stability and standard antioxidant enzymes.` },
          { icon: "🧘", title: "Metabolic Stabilization", desc: `Control metabolic markers and minimize environmental inflammatory triggers through guided activity.` }
        ]
      };
    }

    return statsMap[resolvedName];
  }, [cancerType]);

  // Compute final risk scores incorporating our real input parameters (riskLevel, patientAge, clinical overrides)
  const stats = useMemo(() => {
    // 1. Risk Percentage
    let riskPercent = 50;
    if (riskLevel === "High") riskPercent = 82;
    else if (riskLevel === "Medium") riskPercent = 48;
    else riskPercent = 22;

    // Age modifier for risk/severity (slightly higher with age)
    const ageModifier = Math.min(15, Math.max(-10, (patientAge - 50) * 0.35));
    riskPercent = Math.max(10, Math.min(99, Math.round(riskPercent + ageModifier)));

    // Let's create an "Advanced Risk Indicator" reflecting "Critical" level
    let actualRiskLabel: "Low" | "Moderate" | "High" | "Critical" = "Moderate";
    if (riskPercent < 35) actualRiskLabel = "Low";
    else if (riskPercent >= 35 && riskPercent < 60) actualRiskLabel = "Moderate";
    else if (riskPercent >= 60 && riskPercent < 80) actualRiskLabel = "High";
    else actualRiskLabel = "Critical";

    // 2. Base Survival Probability
    let survivalChance = baseStats.baseSurvival;
    
    // Therapy simulation mod
    if (therapyModifier === "immunotherapy") {
      survivalChance = Math.min(98, survivalChance + 14);
    } else if (therapyModifier === "targeted") {
      survivalChance = Math.min(98, survivalChance + 22);
    }

    // Early detection bonus
    if (earlyDetectionBoost) {
      survivalChance = Math.min(98, survivalChance + Math.round(baseStats.earlyDetectedAdvantage * 0.6));
    }

    // Age modifier on survival (slightly decreases with age)
    const ageSurvivalPenalty = Math.max(0, (patientAge - 45) * 0.25);
    survivalChance = Math.max(4, Math.min(99, Math.round(survivalChance - ageSurvivalPenalty)));

    // 3. Recovery Chance Percentage
    let recoveryChance = survivalChance + 8;
    // Cap at 98% or floor at 10%
    recoveryChance = Math.max(8, Math.min(98, Math.round(recoveryChance)));

    // 4. Disease Severity Score
    let severityScore = baseStats.severity;
    if (riskLevel === "High") severityScore = Math.min(98, severityScore + 15);
    if (riskLevel === "Low") severityScore = Math.max(10, severityScore - 15);
    // Dynamic modifier
    if (earlyDetectionBoost) severityScore = Math.max(8, severityScore - 12);
    severityScore = Math.max(5, Math.min(98, Math.round(severityScore)));

    // 5. Tumor Aggressiveness
    let aggressivenessScore = baseStats.aggressiveness;
    if (riskLevel === "High") aggressivenessScore = Math.min(10, aggressivenessScore + 0.8);
    if (riskLevel === "Low") aggressivenessScore = Math.max(1, aggressivenessScore - 1.2);
    aggressivenessScore = Number(aggressivenessScore.toFixed(1));

    // Treatment Success Percentage
    let treatmentSuccess = recoveryChance - 4;
    if (therapyModifier === "targeted") treatmentSuccess += 8;
    treatmentSuccess = Math.max(12, Math.min(98, Math.round(treatmentSuccess)));

    return {
      riskPercent,
      actualRiskLabel,
      survivalChance,
      recoveryChance,
      severityScore,
      aggressivenessScore,
      treatmentSuccess,
      stage
    };
  }, [baseStats, riskLevel, patientAge, therapyModifier, earlyDetectionBoost, stage]);

  // SVG Line Path calculation for Interactive Survival Probability Chart
  const survivalDataPoints = useMemo(() => {
    // Generate 6 years (Year 0 to Year 5) data sequence representing survival rate trajectory
    const years = [0, 1, 2, 3, 4, 5];
    
    // Baseline trajectory without modifiers
    const standardTrajectory = years.map((yr) => {
      if (yr === 0) return 100;
      // Exponential decay approach
      const decayRate = Math.log(100 / baseStats.baseSurvival) / 5;
      const rate = 100 * Math.exp(-decayRate * yr);
      return Math.round(Math.max(baseStats.baseSurvival, rate));
    });

    // Modified active trajectory based on therapies and age
    const activeTrajectory = years.map((yr) => {
      if (yr === 0) return 100;
      // Exponential decay toward final survival chance
      const decayRate = Math.log(100 / stats.survivalChance) / 5;
      const rate = 100 * Math.exp(-decayRate * yr);
      return Math.round(Math.max(stats.survivalChance, rate));
    });

    return { years, standardTrajectory, activeTrajectory };
  }, [baseStats, stats.survivalChance]);

  // Chart width/height constants
  const chartW = 500;
  const chartH = 220;
  const paddingX = 45;
  const paddingY = 25;

  // Transform coordinates to pixel points
  const points = useMemo(() => {
    const scaleX = (val: number) => paddingX + (val / 5) * (chartW - paddingX * 2);
    const scaleY = (val: number) => chartH - paddingY - (val / 100) * (chartH - paddingY * 2);

    const activeLinePoints = survivalDataPoints.activeTrajectory.map((yVal, xVal) => ({
      x: scaleX(xVal),
      y: scaleY(yVal),
      yr: xVal,
      pct: yVal
    }));

    const standardLinePoints = survivalDataPoints.standardTrajectory.map((yVal, xVal) => ({
      x: scaleX(xVal),
      y: scaleY(yVal),
      yr: xVal,
      pct: yVal
    }));

    // Generate SVG path string with curves
    const generatePath = (pts: typeof activeLinePoints) => {
      let path = `M ${pts[0].x} ${pts[0].y}`;
      for (let i = 0; i < pts.length - 1; i++) {
        const cpX = (pts[i].x + pts[i + 1].x) / 2;
        path += ` C ${cpX} ${pts[i].y}, ${cpX} ${pts[i + 1].y}, ${pts[i + 1].x} ${pts[i + 1].y}`;
      }
      return path;
    };

    return {
      activeLine: generatePath(activeLinePoints),
      standardLine: generatePath(standardLinePoints),
      activeMarkers: activeLinePoints,
      stdMarkers: standardLinePoints
    };
  }, [survivalDataPoints, chartW, chartH]);

  // Get color scale for gauges
  const getRiskColor = (level: "Low" | "Moderate" | "High" | "Critical") => {
    if (level === "Low") return { text: "text-emerald-400", border: "border-emerald-500/25", bg: "bg-emerald-500/10", fill: "#10b981", barBg: "bg-emerald-500" };
    if (level === "Moderate") return { text: "text-amber-400", border: "border-amber-500/25", bg: "bg-amber-500/10", fill: "#f59e0b", barBg: "bg-amber-500" };
    if (level === "High") return { text: "text-rose-400", border: "border-rose-500/25", bg: "bg-rose-500/10", fill: "#f43f5e", barBg: "bg-rose-500" };
    return { text: "text-purple-400", border: "border-purple-500/25", bg: "bg-purple-500/10", fill: "#a855f7", barBg: "bg-purple-500" };
  };

  const riskVisuals = getRiskColor(stats.actualRiskLabel);

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 lg:p-7 space-y-6 shadow-2xl relative overflow-hidden" id="advanced-risk-survival-module">
      {/* Background Subtle Gradient Glow */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-teal-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-rose-500/3 w-80 h-80 rounded-full blur-3xl pointer-events-none" />

      {/* Header Panel */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2 mb-1.5 flex-wrap">
            <span className="bg-teal-500/15 border border-teal-500/30 text-teal-400 text-[10px] font-mono uppercase tracking-wider px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
              <Sparkles className="w-3 h-3 animate-pulse" />
              Advanced Analytics Suite
            </span>
            <span className="bg-amber-500/10 border border-amber-500/20 text-amber-400 text-[10px] font-mono uppercase tracking-wider px-2 py-0.5 rounded-full font-semibold">
              Live Modifiers Enabled
            </span>
          </div>
          <h2 className="text-slate-100 text-lg md:text-xl font-bold tracking-tight">
            Advanced Risk & Survival Analysis Dashboard
          </h2>
          <p className="text-slate-400 text-xs mt-1">
            Dynamic oncology metrics & staging simulations for <span className="text-slate-200 font-bold">{cancerType}</span>.
          </p>
        </div>

        {/* Clinical Control Mini-Panel */}
        <div className="bg-slate-950/80 border border-slate-850 p-3 rounded-2xl flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <div className="space-y-1 sm:border-r sm:border-slate-800 sm:pr-3 sm:mr-1">
            <span className="text-[9px] uppercase tracking-wider text-slate-500 font-mono block font-bold">Simulation Controls</span>
            <div className="flex items-center gap-1.5">
              <Sliders className="w-3 h-3 text-teal-400" />
              <span className="text-[10px] font-bold text-slate-300">Therapy Modifiers</span>
            </div>
          </div>

          <div className="flex items-center gap-1 bg-slate-900 p-0.5 rounded-xl border border-slate-800">
            {(["standard", "immunotherapy", "targeted"] as const).map((method) => (
              <button
                key={method}
                type="button"
                onClick={() => setTherapyModifier(method)}
                className={`px-2.5 py-1 text-[10px] font-mono rounded-lg transition-all capitalize ${
                  therapyModifier === method
                    ? "bg-teal-500 text-slate-950 font-bold shadow-md"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                {method === "standard" ? "Base" : method === "targeted" ? "Targeted" : "Immuno"}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* CORE VISUAL DASHBOARD: 5 Circle / Gauge Progress Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3.5 sm:gap-4 md:gap-3.5">
        
        {/* PANEL 1: Color-Coded Risk Gauge */}
        <div className="bg-slate-950/80 border border-slate-850 rounded-2xl p-4 flex flex-col items-center text-center justify-between min-h-40 relative group hover:border-slate-750 transition-all">
          <div className="w-full flex items-center justify-between text-[10px] font-mono text-slate-500 font-bold uppercase mb-2">
            <span>Risk Level</span>
            <ShieldAlert className="w-3 h-3 text-red-500" />
          </div>
          
          {/* Radial circle for risk percentage */}
          <div className="relative w-20 h-20 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90">
              <circle cx="40" cy="40" r="32" className="stroke-slate-800" strokeWidth="6" fill="transparent" />
              <circle 
                cx="40" 
                cy="40" 
                r="32" 
                stroke={riskVisuals.fill} 
                strokeWidth="6.5" 
                fill="transparent" 
                strokeDasharray={2 * Math.PI * 32}
                strokeDashoffset={2 * Math.PI * 32 * (1 - stats.riskPercent / 100)}
                strokeLinecap="round"
                className="transition-all duration-700 ease-out"
              />
            </svg>
            <div className="absolute flex flex-col items-center">
              <span className="text-sm font-black text-slate-100 font-mono tracking-tighter">{stats.riskPercent}%</span>
              <span className="text-[7.5px] font-bold text-slate-500 uppercase">INDEX</span>
            </div>
          </div>

          <div className="mt-3.5 w-full">
            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${riskVisuals.bg} ${riskVisuals.text} border ${riskVisuals.border}`}>
              {stats.actualRiskLabel}
            </span>
          </div>
        </div>

        {/* PANEL 2: Survival Chance Progress Gauge */}
        <div className="bg-slate-950/80 border border-slate-850 rounded-2xl p-4 flex flex-col items-center text-center justify-between min-h-40 group hover:border-slate-750 transition-all">
          <div className="w-full flex items-center justify-between text-[10px] font-mono text-slate-500 font-bold uppercase mb-2">
            <span>5-Yr Survival</span>
            <Heart className="w-3 h-3 text-teal-400" />
          </div>
          
          <div className="relative w-20 h-20 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90">
              <circle cx="40" cy="40" r="32" className="stroke-slate-800" strokeWidth="6" fill="transparent" />
              <circle 
                cx="40" 
                cy="40" 
                r="32" 
                stroke="#14b8a6" 
                strokeWidth="6.5" 
                fill="transparent" 
                strokeDasharray={2 * Math.PI * 32}
                strokeDashoffset={2 * Math.PI * 32 * (1 - stats.survivalChance / 100)}
                strokeLinecap="round"
                className="transition-all duration-700 ease-out"
              />
            </svg>
            <div className="absolute flex flex-col items-center">
              <span className="text-sm font-black text-slate-100 font-mono tracking-tighter">{stats.survivalChance}%</span>
              <span className="text-[7.5px] font-bold text-slate-500 uppercase">PROBABILITY</span>
            </div>
          </div>

          <div className="mt-3 text-[10px] text-teal-400 font-mono font-medium truncate max-w-full">
            Trajectory: Stable
          </div>
        </div>

        {/* PANEL 3: Recovery Chance Circle */}
        <div className="bg-slate-950/80 border border-slate-850 rounded-2xl p-4 flex flex-col items-center text-center justify-between min-h-40 group hover:border-slate-750 transition-all">
          <div className="w-full flex items-center justify-between text-[10px] font-mono text-slate-500 font-bold uppercase mb-2">
            <span>Recovery Rate</span>
            <Activity className="w-3 h-3 text-emerald-400" />
          </div>
          
          <div className="relative w-20 h-20 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90">
              <circle cx="40" cy="40" r="32" className="stroke-slate-800" strokeWidth="6" fill="transparent" />
              <circle 
                cx="40" 
                cy="40" 
                r="32" 
                stroke="#10b981" 
                strokeWidth="6.5" 
                fill="transparent" 
                strokeDasharray={2 * Math.PI * 32}
                strokeDashoffset={2 * Math.PI * 32 * (1 - stats.recoveryChance / 100)}
                strokeLinecap="round"
                className="transition-all duration-700 ease-out"
              />
            </svg>
            <div className="absolute flex flex-col items-center">
              <span className="text-sm font-black text-slate-100 font-mono tracking-tighter">{stats.recoveryChance}%</span>
              <span className="text-[7.5px] font-bold text-slate-500 uppercase">POTENTIAL</span>
            </div>
          </div>

          <div className="mt-3 text-[10px] text-emerald-400 font-mono font-medium truncate max-w-full">
            Full Remission Max
          </div>
        </div>

        {/* PANEL 4: Confidence Score Card */}
        <div className="bg-slate-950/80 border border-slate-850 rounded-2xl p-4 flex flex-col items-center text-center justify-between min-h-40 group hover:border-slate-750 transition-all">
          <div className="w-full flex items-center justify-between text-[10px] font-mono text-slate-500 font-bold uppercase mb-2">
            <span>AI Confidence</span>
            <Gauge className="w-3 h-3 text-blue-400" />
          </div>
          
          <div className="relative w-20 h-20 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90">
              <circle cx="40" cy="40" r="32" className="stroke-slate-800" strokeWidth="6" fill="transparent" />
              <circle 
                cx="40" 
                cy="40" 
                r="32" 
                stroke="#3b82f6" 
                strokeWidth="6.5" 
                fill="transparent" 
                strokeDasharray={2 * Math.PI * 32}
                strokeDashoffset={2 * Math.PI * 32 * (1 - confidence / 100)}
                strokeLinecap="round"
                className="transition-all duration-700 ease-out"
              />
            </svg>
            <div className="absolute flex flex-col items-center">
              <span className="text-sm font-black text-slate-100 font-mono tracking-tighter">{confidence}%</span>
              <span className="text-[7.5px] font-bold text-slate-500 uppercase">ACCURACY</span>
            </div>
          </div>

          <div className="mt-3 text-[10px] text-blue-400 font-mono font-medium truncate max-w-full">
            ViT Pixel Matches
          </div>
        </div>

        {/* PANEL 5: Disease Severity Score */}
        <div className="bg-slate-950/80 border border-slate-850 rounded-2xl p-4 flex flex-col items-center text-center justify-between min-h-40 group hover:border-slate-750 transition-all col-span-2 md:col-span-1">
          <div className="w-full flex items-center justify-between text-[10px] font-mono text-slate-500 font-bold uppercase mb-2">
            <span>Severity index</span>
            <AlertTriangle className="w-3 h-3 text-amber-500" />
          </div>
          
          <div className="relative w-20 h-20 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90">
              <circle cx="40" cy="40" r="32" className="stroke-slate-800" strokeWidth="6" fill="transparent" />
              <circle 
                cx="40" 
                cy="40" 
                r="32" 
                stroke="#f59e0b" 
                strokeWidth="6.5" 
                fill="transparent" 
                strokeDasharray={2 * Math.PI * 32}
                strokeDashoffset={2 * Math.PI * 32 * (1 - stats.severityScore / 100)}
                strokeLinecap="round"
                className="transition-all duration-700 ease-out"
              />
            </svg>
            <div className="absolute flex flex-col items-center">
              <span className="text-sm font-black text-slate-100 font-mono tracking-tighter">{stats.severityScore}%</span>
              <span className="text-[7.5px] font-bold text-slate-500 uppercase">SEVERITY</span>
            </div>
          </div>

          <div className="mt-3 text-[10px] text-amber-500 font-mono font-medium truncate max-w-full">
            Ductal Mass Level
          </div>
        </div>

      </div>

      {/* DETAILED INTERACTIVE SURVIVAL CURVE GRID SECTION */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        
        {/* Left Side: Dynamic Plot Chart */}
        <div className="lg:col-span-7 bg-slate-950/60 border border-slate-850 p-4 sm:p-5 rounded-2xl flex flex-col justify-between">
          <div className="mb-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5">
              <h4 className="text-slate-200 text-xs font-bold uppercase tracking-wider font-mono flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5 text-teal-400" />
                Interactive Survival Probability Curve
              </h4>
              
              <div className="flex items-center gap-2">
                <span className="flex items-center gap-1 text-[9px] font-mono text-slate-500 shrink-0">
                  <span className="w-2.5 h-0.5 bg-slate-500 inline-block line-through opacity-60" /> Standard
                </span>
                <span className="flex items-center gap-1 text-[9px] font-mono text-teal-400 shrink-0">
                  <span className="w-2.5 h-0.5 bg-teal-400 inline-block" /> Adjusted Active
                </span>
              </div>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              Simulates patients survival probability decay trend across a 5-year post-diagnosis timeframe. Click or hover coordinates.
            </p>
          </div>

          {/* SVG Interactive Cartesian Plot Graph */}
          <div className="relative w-full overflow-x-auto select-none mt-2">
            <svg 
              className="w-full min-w-[320px] h-[220px]" 
              viewBox={`0 0 ${chartW} ${chartH}`}
              preserveAspectRatio="none"
              onMouseLeave={() => setHoveredYear(null)}
            >
              {/* horizontal grid lines with indicators */}
              {[100, 75, 50, 25, 0].map((gridLine, idx) => {
                const gridY = paddingY + (1 - gridLine / 100) * (chartH - paddingY * 2);
                return (
                  <g key={gridLine} className="opacity-40">
                    <line 
                      x1={paddingX} 
                      y1={gridY} 
                      x2={chartW - paddingX} 
                      y2={gridY} 
                      stroke="#1e293b" 
                      strokeWidth="1" 
                      strokeDasharray="3 3"
                    />
                    <text 
                      x={paddingX - 10} 
                      y={gridY + 4} 
                      fill="#64748b" 
                      className="text-[10px] font-mono text-right" 
                      textAnchor="end"
                    >
                      {gridLine}%
                    </text>
                  </g>
                );
              })}

              {/* standard baseline trajectory (dashed gray, with slightly curved slope) */}
              <path 
                d={points.standardLine} 
                fill="none" 
                stroke="#64748b" 
                strokeWidth="1.8" 
                strokeDasharray="4 4" 
                className="opacity-40"
              />

              {/* gradient fill overlay below active path */}
              <defs>
                <linearGradient id="activeGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#14b8a6" stopOpacity="0.18" />
                  <stop offset="100%" stopColor="#14b8a6" stopOpacity="0.0" />
                </linearGradient>
              </defs>
              <path
                d={`${points.activeLine} L ${points.activeMarkers[points.activeMarkers.length - 1].x} ${chartH - paddingY} L ${points.activeMarkers[0].x} ${chartH - paddingY} Z`}
                fill="url(#activeGrad)"
                className="transition-all duration-300"
              />

              {/* active trajectory curve */}
              <path 
                d={points.activeLine} 
                fill="none" 
                stroke="#14b8a6" 
                strokeWidth="2.8" 
                className="transition-all duration-300"
              />

              {/* interactive marker nodes */}
              {points.activeMarkers.map((activeM, idx) => {
                const stdM = points.stdMarkers[idx];
                const isHovered = hoveredYear === activeM.yr || selectedYearParam === activeM.yr;
                return (
                  <g 
                    key={activeM.yr}
                    className="cursor-pointer group"
                    onMouseEnter={() => setHoveredYear(activeM.yr)}
                    onClick={() => setSelectedYearParam(activeM.yr)}
                  >
                    {/* Hover hotspot radius */}
                    <circle 
                      cx={activeM.x} 
                      cy={activeM.y} 
                      r="16" 
                      fill="transparent" 
                    />

                    {/* standard trajectory points */}
                    <circle 
                      cx={stdM.x} 
                      cy={stdM.y} 
                      r="3.5" 
                      fill="#1e293b" 
                      stroke="#64748b" 
                      strokeWidth="1.5" 
                      className="opacity-60"
                    />

                    {/* active calculated points */}
                    <circle 
                      cx={activeM.x} 
                      cy={activeM.y} 
                      r={isHovered ? "6.5" : "4.5"} 
                      fill="#030712" 
                      stroke="#14b8a6" 
                      strokeWidth={isHovered ? "3.5" : "2"} 
                      className="transition-all duration-150"
                    />

                    {/* Coordinate popup on hover */}
                    {isHovered && (
                      <g className="pointer-events-none transition-opacity duration-200">
                        <rect 
                          x={activeM.x - 38} 
                          y={activeM.y - 34} 
                          width="76" 
                          height="22" 
                          fill="#0f172a" 
                          stroke="#14b8a6" 
                          strokeWidth="1" 
                          rx="4" 
                          className="shadow-2xl" 
                        />
                        <text 
                          x={activeM.x} 
                          y={activeM.y - 20} 
                          fill="#ffffff" 
                          className="text-[9.5px] font-mono font-bold" 
                          textAnchor="middle"
                        >
                          Yr {activeM.yr}: {activeM.pct}%
                        </text>
                      </g>
                    )}
                  </g>
                );
              })}

              {/* Years label line on axis */}
              {points.activeMarkers.map((m) => (
                <text 
                  key={m.yr} 
                  x={m.x} 
                  y={chartH - 6} 
                  fill="#94a3b8" 
                  className="text-[10.5px] font-mono font-semibold" 
                  textAnchor="middle"
                >
                  {m.yr === 0 ? "Diagn." : `Yr ${m.yr}`}
                </text>
              ))}
            </svg>
          </div>

          <div className="flex justify-between items-center bg-slate-900 border border-slate-850 p-2 px-3 rounded-xl text-xs font-mono mt-3">
            <span className="text-slate-500 uppercase text-[9px] tracking-wider font-bold">Timeline readout:</span>
            <span className="text-slate-300">
              {selectedYearParam !== null ? (
                <>
                  Year <b className="text-teal-400 font-bold">{selectedYearParam}</b> Probability:{" "}
                  <b className="text-slate-100 font-extrabold text-sm">{survivalDataPoints.activeTrajectory[selectedYearParam]}%</b>{" "}
                  <span className="text-[10px] text-slate-500">(Std Baseline was: {survivalDataPoints.standardTrajectory[selectedYearParam]}%)</span>
                </>
              ) : "Select a point on the curve to lock coordinate telemetry."}
            </span>
          </div>
        </div>

        {/* Right Side: Additional Oncology Metrics & Disclaimers */}
        <div className="lg:col-span-5 space-y-4">
          
          {/* Diagnostic Metrics Matrix */}
          <div className="bg-slate-950/60 border border-slate-850 p-4.5 rounded-2xl space-y-3.5">
            <h4 className="text-slate-200 text-xs font-bold uppercase tracking-wider font-mono flex items-center gap-1.5">
              <Dna className="w-3.5 h-3.5 text-blue-400" />
              Diagnostic Metrics Suite
            </h4>

            <div className="grid grid-cols-2 gap-3 text-xs">
              
              <div className="bg-slate-900 border border-slate-850/60 p-3 rounded-xl flex flex-col justify-between">
                <div>
                  <span className="text-slate-500 uppercase text-[9px] font-mono font-bold block mb-0.5">Stage Classification</span>
                  <div className="flex items-center gap-1.5 mt-1">
                    <span className="w-2 h-2 rounded-full bg-teal-400 animate-pulse" />
                    <span className="text-slate-200 text-sm font-black font-semibold">{stats.stage}</span>
                  </div>
                </div>
                <p className="text-[9.5px] text-slate-500 leading-normal mt-2">Determined organically from patient metrics.</p>
              </div>

              <div className="bg-slate-900 border border-slate-850/60 p-3 rounded-xl flex flex-col justify-between">
                <div>
                  <span className="text-slate-500 uppercase text-[9px] font-mono font-bold block mb-0.5">Early Detection advantage</span>
                  <div className="flex items-center gap-1.5 mt-1 text-teal-400 font-bold">
                    <TrendingUp className="w-3.5 h-3.5" />
                    <span className="text-sm font-black text-slate-100">+{baseStats.earlyDetectedAdvantage}%</span>
                  </div>
                </div>
                <p className="text-[9.5px] text-slate-500 leading-normal mt-2">Estimated boost with immediate early-stage mitigation.</p>
              </div>

              <div className="bg-slate-900 border border-slate-850/60 p-3 rounded-xl flex flex-col justify-between">
                <div>
                  <span className="text-slate-500 uppercase text-[9px] font-mono font-bold block mb-0.5">Tumor Aggressiveness</span>
                  <div className="flex items-center gap-1.5 mt-1">
                    <Flame className="w-3.5 h-3.5 text-rose-500" />
                    <span className="text-slate-200 text-sm font-black font-semibold">{stats.aggressivenessScore} <span className="text-[10px] text-slate-500">/ 10</span></span>
                  </div>
                </div>
                <p className="text-[9.5px] text-slate-500 leading-normal mt-2">Mitigation rate relative to tissue replication threshold.</p>
              </div>

              <div className="bg-slate-900 border border-slate-850/60 p-3 rounded-xl flex flex-col justify-between">
                <div>
                  <span className="text-slate-500 uppercase text-[9px] font-mono font-bold block mb-0.5">Tx Success rate</span>
                  <div className="flex items-center gap-1.5 mt-1">
                    <BriefcaseMedical className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-slate-200 text-sm font-black font-semibold">{stats.treatmentSuccess}%</span>
                  </div>
                </div>
                <p className="text-[9.5px] text-slate-500 leading-normal mt-2">Likelihood of cellular remission targets met.</p>
              </div>

            </div>

            {/* Simulated Early Detection Toggle Switch */}
            <div className="bg-slate-950 border border-slate-850 p-2.5 rounded-xl flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-teal-400" />
                <div>
                  <span className="text-slate-200 block font-bold text-[11px]">Apply Early Detection Factor</span>
                  <span className="text-slate-500 text-[9.5px] block">Simulates shifting diagnosis standard backward</span>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={earlyDetectionBoost} 
                  onChange={(e) => setEarlyDetectionBoost(e.target.checked)} 
                  className="sr-only peer" 
                />
                <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-slate-400 after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-teal-500 peer-checked:after:bg-slate-950" />
              </label>
            </div>
          </div>

          {/* Personalized Health Risk Meter */}
          <div className="bg-slate-950/60 border border-slate-850 p-4 rounded-2xl">
            <h4 className="text-slate-200 text-xs font-bold uppercase tracking-wider font-mono flex items-center gap-1.5 mb-3">
              <Scale className="w-3.5 h-3.5 text-amber-500" />
              Personalized Health Risk Meter
            </h4>

            {/* Gradient scale gauge */}
            <div className="space-y-3.5 text-[11px]">
              <div>
                <div className="flex justify-between text-[10px] text-slate-400 mb-1">
                  <span>Tumor Asymmetry Coefficient</span>
                  <span className="text-slate-200 font-mono font-semibold">{stats.severityScore}%</span>
                </div>
                <div className="w-full h-2.5 bg-slate-900 rounded-full overflow-hidden border border-slate-800 flex">
                  <div className={`h-full ${riskVisuals.barBg} transition-all duration-500`} style={{ width: `${stats.severityScore}%` }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[10px] text-slate-400 mb-1">
                  <span>Genetic Risk Marker Matching</span>
                  <span className="text-slate-200 font-mono font-semibold">{patientAge > 55 ? "72%" : "44%"}</span>
                </div>
                <div className="w-full h-2.5 bg-slate-900 rounded-full overflow-hidden border border-slate-800 flex">
                  <div className="h-full bg-blue-500 transition-all duration-500" style={{ width: patientAge > 55 ? "72%" : "44%" }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[10px] text-slate-400 mb-1">
                  <span>Parenchymal Tissue Displacement</span>
                  <span className="text-slate-200 font-mono font-semibold">{stats.riskPercent - 10}%</span>
                </div>
                <div className="w-full h-2.5 bg-slate-900 rounded-full overflow-hidden border border-slate-800 flex">
                  <div className="h-full bg-rose-500 transition-all duration-500" style={{ width: `${Math.max(10, stats.riskPercent - 10)}%` }} />
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* LIFESTYLE & CLINICAL IMPACT ASSESSMENT */}
      <div className="bg-slate-950/60 border border-slate-850 p-4.5 sm:p-5 rounded-2xl space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-800/80 pb-3">
          <HeartPulse className="w-5 h-5 text-emerald-400" />
          <div>
            <h4 className="text-slate-200 text-sm font-bold uppercase tracking-wider font-mono">
              Oncology Lifestyle & Preventile Clinical Assessment
            </h4>
            <p className="text-slate-400 text-[11px] mt-0.5">
              Evidence-based, non-invasive habits to optimize biological cellular integrity and support ongoing chemotherapy or endocrine resistance.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {baseStats.lifestyleFactors.map((factor, i) => (
            <div key={i} className="p-3.5 bg-slate-900/60 border border-slate-850 rounded-xl space-y-2 hover:bg-slate-900 transition-all">
              <div className="flex items-center gap-2">
                <span className="text-lg bg-slate-950/90 p-1.5 rounded-lg border border-slate-850 inline-block text-center">{factor.icon}</span>
                <span className="text-slate-200 font-bold text-xs truncate">{factor.title}</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed font-normal">
                {factor.desc}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* CLINICAL DISCLAIMER & REGULATORY STATEMENT */}
      <div className="bg-slate-950 border-2 border-dashed border-slate-800 p-4 rounded-2xl flex flex-col sm:flex-row items-center sm:items-start gap-4">
        <div className="p-2 bg-amber-500/10 border border-amber-500/20 text-amber-500 rounded-xl shrink-0">
          <AlertTriangle className="w-6 h-6 shrink-0" />
        </div>
        <div className="space-y-1.5 text-center sm:text-left">
          <h5 className="text-slate-300 font-bold text-xs uppercase tracking-wider font-mono">
            ⚠️ Clinical Educational Notice & AI Disclaimer
          </h5>
          <p className="text-[10px] text-slate-400 leading-relaxed">
            All survival parameters, disease severity metrics, tumor aggressiveness ratings, early detection benchmarks, and recovery estimates listed within this system are <strong className="text-amber-400 font-bold">strictly AI-generated simulated estimates</strong> for clinical educational training purposes. They do <strong className="text-rose-400 font-semibold">NOT</strong> constitute actual medical diagnostic advice, prognosis predictions, or physiological treatment guidelines. 
          </p>
          <p className="text-[10px] text-slate-400 leading-relaxed">
            Patients and caregivers must consult qualified board-certified oncology coordinators, radiologists, and treatment teams for precise medical diagnostics, direct tissue path-lab inspections, and physical therapy prescriptions. 
          </p>
        </div>
      </div>

    </div>
  );
}
