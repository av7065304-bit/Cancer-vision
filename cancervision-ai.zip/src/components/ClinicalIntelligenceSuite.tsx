import React, { useState, useRef, useEffect } from "react";
import { 
  Heart, 
  Brain, 
  Layers, 
  Activity, 
  Compass, 
  Sparkles, 
  Volume2, 
  VolumeX, 
  AlertTriangle, 
  BookOpen, 
  Search, 
  FileText, 
  CheckCircle, 
  ChevronRight, 
  RotateCw, 
  User, 
  ArrowRight, 
  Play, 
  HelpCircle, 
  Mic, 
  Languages, 
  UserCheck, 
  TrendingUp, 
  Dna,
  Sliders,
  Scan,
  Maximize2
} from "lucide-react";

// Types
type Language = "en" | "hi";

interface ClinicalIntelligenceSuiteProps {
  scans?: any[];
  theme?: "dark" | "light";
}

export default function ClinicalIntelligenceSuite({ scans = [], theme = "dark" }: ClinicalIntelligenceSuiteProps) {
  const [lang, setLang] = useState<Language>("en");
  const [activeTab, setActiveTab] = useState<"diagnostics" | "longitudinal" | "risk" | "education">("diagnostics");

  // Multilingual glossary
  const t = {
    en: {
      suiteTitle: "AI Clinical Intelligence Suite",
      suiteSubtitle: "Advanced onco-diagnostic modeling, hereditary genetics, predictive timelines, and patient roadmap frameworks.",
      diagnosticsTab: "Diagnostic Lab",
      longitudinalTab: "Longitudinal Insights",
      riskTab: "Risk & Genetics",
      educationTab: "Copilot & Education",
      gradCamTitle: "Interactive Explainability Lab (Grad-CAM)",
      gradCamDesc: "Click anywhere on the tumor scan simulation below to extract CNN activation intensities and receive pathology insights.",
      intensity: "Activation Intensity",
      pathologyInsight: "Pathology Insights",
      secondOpinionTitle: "AI Second Opinion Consensus",
      secondOpinionDesc: "Compare prediction outputs across multiple high-performance neural networks.",
      voteConsensus: "Ensemble Vote Consensus",
      agreementScore: "Agreement Score",
      modelName: "Model Architecture",
      confidence: "Confidence",
      prediction: "Primary Prediction",
      threeDTitle: "Interactive 3D Tumor Visualization",
      threeDDesc: "Adjust sliders to rotate the simulated spatial volume. Drag the slice depth to verify boundaries.",
      rotationX: "Tilt Rotation",
      rotationY: "Z-Axis Rotation",
      sliceDepth: "MRI Axial Cut Depth",
      volumeCalculated: "Calculated Tumor Volume",
      progressionTitle: "Multi-Scan Longitudinal Trend",
      progressionDesc: "Historical progression of maximum lesion diameter mapped over standard therapeutic intervals.",
      comparisonTitle: "Scan Comparison & Change Detection",
      comparisonDesc: "Blend Scan A (baseline) and Scan B (current) to calculate absolute cellular shrinkage rates.",
      earlyWarningTitle: "Early Warning & AI Health Score",
      earlyWarningDesc: "Incorporate lifestyle factors, imaging indications, and symptoms to assess current oncology risks.",
      familyTitle: "Family Hereditary Risk Mapping",
      familyDesc: "Map maternal and paternal lineages to identify potential hereditary syndromes.",
      roadmapTitle: "Patient Cancer Journey Roadmap",
      roadmapDesc: "Standard clinical care milestones with customized doctor discussion checklists.",
      copilotTitle: "AI Health Copilot & Knowledge Hub",
      copilotDesc: "Direct multilingual consulting helper explaining diagnostics, therapy targets, and clinical papers.",
      voiceTitle: "Voice Report Assistant",
      voiceDesc: "Synthesize vocal audio for reports or interact hands-free with simulated voice dictation.",
      emergencyTitle: "Oncological Emergency Alert System",
      emergencyDesc: "Trigger standard clinical response guidelines for acute oncological emergencies.",
      researchTitle: "Oncology Research Assistant (PubMed)",
      researchDesc: "Summarize literature from oncology clinical trials."
    },
    hi: {
      suiteTitle: "एआई क्लिनिकल इंटेलिजेंस सूट",
      suiteSubtitle: "उन्नत ऑन्को-डायग्नोस्टिक मॉडलिंग, वंशानुगत आनुवंशिकी, भविष्य कहनेवाला प्रगति समयसीमा, और रोगी रोडमैप ढांचा।",
      diagnosticsTab: "डायग्नोस्टिक लैब",
      longitudinalTab: "प्रगति और तुलना",
      riskTab: "जोखिम और आनुवंशिकी",
      educationTab: "कोपायलट और शिक्षा",
      gradCamTitle: "इंटरएक्टिव व्याख्यात्मकता लैब (Grad-CAM)",
      gradCamDesc: "सीएनएन सक्रियण तीव्रता निकालने और पैथोलॉजी अंतर्दृष्टि प्राप्त करने के लिए नीचे दिए गए ट्यूमर स्कैन सिमुलेशन पर कहीं भी क्लिक करें।",
      intensity: "सक्रियण तीव्रता",
      pathologyInsight: "पैथोलॉजी अंतर्दृष्टि",
      secondOpinionTitle: "एआई द्वितीय राय आम सहमति (Second Opinion)",
      secondOpinionDesc: "कई उच्च-प्रदर्शन तंत्रिका नेटवर्क (Neural Networks) में भविष्यवाणी आउटपुट की तुलना करें।",
      voteConsensus: "एन्सेम्बल वोट आम सहमति",
      agreementScore: "सहमति स्कोर",
      modelName: "मॉडल वास्तुकला",
      confidence: "आत्मविश्वास",
      prediction: "प्राथमिक भविष्यवाणी",
      threeDTitle: "इंटरएक्टिव 3D ट्यूमर विज़ुअलाइज़ेशन",
      threeDDesc: "सिम्युलेटेड स्थानिक मात्रा को घुमाने के लिए स्लाइडर्स को समायोजित करें। सीमा की पुष्टि के लिए गहराई स्लाइड करें।",
      rotationX: "झुकाव रोटेशन",
      rotationY: "जेड-अक्ष रोटेशन",
      sliceDepth: "एमआरआई अक्षीय गहराई",
      volumeCalculated: "गणना की गई ट्यूमर मात्रा",
      progressionTitle: "मल्टी-स्कैन अनुदैर्ध्य प्रवृत्ति",
      progressionDesc: "मानक चिकित्सीय अंतरालों पर मैप की गई अधिकतम घाव व्यास का ऐतिहासिक विकास।",
      comparisonTitle: "स्कैन तुलना और परिवर्तन का पता लगाना",
      comparisonDesc: "पूर्ण कोशिकीय सिकुड़न दरों की गणना करने के लिए स्कैन ए (आधारभूत) और स्कैन बी (वर्तमान) को मिलाएं।",
      earlyWarningTitle: "प्रारंभिक चेतावनी और एआई स्वास्थ्य स्कोर",
      earlyWarningDesc: "वर्तमान ऑन्कोलॉजी जोखिमों का आकलन करने के लिए जीवन शैली, इमेजिंग संकेतों और लक्षणों को शामिल करें।",
      familyTitle: "पारिवारिक वंशानुगत कैंसर जोखिम और मार्कर",
      familyDesc: "वंशानुगत सिंड्रोम की पहचान करने के लिए मातृ और पितृ वंशावली का मानचित्रण करें।",
      roadmapTitle: "रोगी कैंसर यात्रा रोडमैप",
      roadmapDesc: "अनुकूलित डॉक्टर चर्चा चेकलिस्ट के साथ मानक क्लिनिकल मील का पत्थर।",
      copilotTitle: "एआई स्वास्थ्य कोपायलट और ज्ञान केंद्र",
      copilotDesc: "डायग्नोस्टिक्स, थेरेपी लक्ष्यों और नैदानिक पत्रों की व्याख्या करने वाला सहायक।",
      voiceTitle: "वॉयस रिपोर्ट सहायक (Voice Assistant)",
      voiceDesc: "रिपोर्टों के लिए मुखर ऑडियो संश्लेषित करें या सिम्युलेटेड वॉयस डिक्टेशन के साथ हैंड्स-फ्री बातचीत करें।",
      emergencyTitle: "ऑन्कोलॉजिकल आपातकालीन चेतावनी प्रणाली",
      emergencyDesc: "तीव्र ऑन्कोलॉजिकल आपात स्थितियों के लिए त्वरित नैदानिक प्रतिक्रिया दिशानिर्देश ट्रिगर करें।",
      researchTitle: "ऑन्कोलॉजी रिसर्च असिस्टेंट (PubMed)",
      researchDesc: "ऑन्कोलॉजी नैदानिक ​​परीक्षणों से प्रमुख साहित्य को खोजें और उसका सारांश प्राप्त करें।"
    }
  };

  // 1. GRAD-CAM EXPLAINABILITY STATE
  const [gradCamX, setGradCamX] = useState(150);
  const [gradCamY, setGradCamY] = useState(130);
  const [gradCamIntensity, setGradCamIntensity] = useState(94.2);
  const [gradCamInsight, setGradCamInsight] = useState({
    en: "Central hyper-metabolic cluster detected with dense marginal vascular penetration. High likelihood of aggressive mitotic doubling rate. Suggest target validation.",
    hi: "घने सीमांत संवहनी पैठ के साथ केंद्रीय हाइपर-मेटाबॉलिक क्लस्टर का पता चला। आक्रामक माइटोटिक दोहरीकरण दर की उच्च संभावना। लक्षित सत्यापन का सुझाव दें।"
  });

  const handleGradCamClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = Math.min(Math.max(Math.round(e.clientX - rect.left), 10), 290);
    const y = Math.min(Math.max(Math.round(e.clientY - rect.top), 10), 230);
    setGradCamX(x);
    setGradCamY(y);

    // Calculate a simulated high-intensity zone near center
    const distToCenter = Math.sqrt(Math.pow(x - 150, 2) + Math.pow(y - 120, 2));
    const intensity = Math.max(98.4 - distToCenter * 0.4, 12.5);
    setGradCamIntensity(parseFloat(intensity.toFixed(1)));

    if (intensity > 85) {
      setGradCamInsight({
        en: "Core tumor zone. High heat indicator corresponds with elevated glucose metabolization. Tissue biopsy recommended here.",
        hi: "कोर ट्यूमर क्षेत्र। उच्च ताप संकेतक ऊंचे ग्लूकोज चयापचय से मेल खाता है। यहाँ ऊतक बायोप्सी की सिफारिश की जाती है।"
      });
    } else if (intensity > 60) {
      setGradCamInsight({
        en: "Infiltrative peritumoral edema. Shows active inflammatory cellular response bordering the key dense tumor margin.",
        hi: "घुसपैठ पेरिट्यूमरल शोफ (Edema)। प्रमुख घने ट्यूमर मार्जिन की रक्षा करने वाली सक्रिय भड़काऊ सेलुलर प्रतिक्रिया दिखाता है।"
      });
    } else {
      setGradCamInsight({
        en: "Marginal benign tissue environment. Low CNN weight validation. Normalized signal profiles with no signs of microvascular hyperplasia.",
        hi: "सीमांत सौम्य ऊतक वातावरण। कम सीएनएन वजन सत्यापन। माइक्रोवैस्कुलर हाइपरप्लासिया के कोई संकेत नहीं होने के साथ सामान्यीकृत संकेत प्रोफाइल।"
      });
    }
  };

  // 2. 3D TUMOR ROTATION AND SLICING
  const [rotX, setRotX] = useState(25);
  const [rotY, setRotY] = useState(45);
  const [sliceDepth, setSliceDepth] = useState(50);
  const [showWireframe, setShowWireframe] = useState<boolean>(true);

  // 3. AI SECOND OPINION VOTE
  const [modelsList, setModelsList] = useState([
    { id: 1, name: "EfficientNet-B7 OncoV4", weight: 0.94, vote: "Malignant Glioblastoma", confidence: 96.2, active: true },
    { id: 2, name: "Swin-Transformer (ViT-H)", weight: 0.96, vote: "Malignant Glioblastoma", confidence: 94.8, active: true },
    { id: 3, name: "ResNet-152 Segmentor", weight: 0.91, vote: "Astrocytoma Grade III", confidence: 89.1, active: true },
    { id: 4, name: "DenseNet-201 CellNet", weight: 0.89, vote: "Malignant Glioblastoma", confidence: 91.5, active: true }
  ]);

  const activeModels = modelsList.filter(m => m.active);
  const consensusVote = "Malignant Glioblastoma";
  const consensusAgreement = Math.round((activeModels.filter(m => m.vote === "Malignant Glioblastoma").length / activeModels.length) * 100);

  // 4. LONGITUDINAL PROGRESSION TIMELINE
  const progressionData = [
    { scanDate: "2025-12-04", diameter: 34, volume: 16.2, therapy: "Baseline - Pre-intervention" },
    { scanDate: "2026-03-04", diameter: 21, volume: 8.4, therapy: "Cycle 3 Neoadjuvant Temozolomide" },
    { scanDate: "2026-06-04", diameter: 12, volume: 2.8, therapy: "Cycle 6 Post-Surgical Resection + RT" }
  ];

  // 5. BLEND COMPARISON STATE
  const [blendFactor, setBlendFactor] = useState(50); // slider percent

  // 6. EARLY WARNING RISK SCORE CALCULATOR
  const [ageRange, setAgeRange] = useState("45-64");
  const [smokingYears, setSmokingYears] = useState(10);
  const [dietIndex, setDietIndex] = useState("medium");
  const [hasSymptoms, setHasSymptoms] = useState({
    weightLoss: true,
    persistentCough: false,
    lesionChange: true,
    fever: false
  });
  const [biomarkerLevel, setBiomarkerLevel] = useState(3.4); // e.g. PSA / CA125

  const calculateEarlyWarningScore = () => {
    let base = 10;
    if (ageRange === "65+") base += 20;
    else if (ageRange === "45-64") base += 10;

    base += smokingYears * 2.5;
    
    if (dietIndex === "poor") base += 15;
    else if (dietIndex === "medium") base += 5;

    if (hasSymptoms.weightLoss) base += 12;
    if (hasSymptoms.persistentCough) base += 12;
    if (hasSymptoms.lesionChange) base += 15;
    if (hasSymptoms.fever) base += 8;

    base += biomarkerLevel * 5;

    return Math.min(Math.round(base), 100);
  };

  const earlyWarningScore = calculateEarlyWarningScore();

  // 7. FAMILY GENETICS TREE
  const [familyTree, setFamilyTree] = useState([
    { id: "paternal_gf", label: "Paternal Grandfather", affected: "Lung Cancer (Age 68)", b_carrier: "Negative" },
    { id: "paternal_gm", label: "Paternal Grandmother", affected: "None", b_carrier: "Unverified" },
    { id: "maternal_gf", label: "Maternal Grandfather", affected: "Colon Cancer (Age 55)", b_carrier: "Lynch Indicator +" },
    { id: "maternal_gm", label: "Maternal Grandmother", affected: "Breast Cancer (Age 42)", b_carrier: "BRCA1 positive" },
    { id: "father", label: "Father", affected: "None", b_carrier: "Negative" },
    { id: "mother", label: "Mother", affected: "Breast Cancer (Age 49)", b_carrier: "BRCA1 positive" },
    { id: "sibling", label: "Sibling", affected: "None", b_carrier: "BRCA1 Carrier" }
  ]);
  const [selectedRelative, setSelectedRelative] = useState<any>(familyTree[5]); // Mother default

  // 8. RESEARCH ASSISTANT Literature Search
  const [searchQuery, setSearchQuery] = useState("Glioblastoma Immunotherapy CAR-T");
  const [papers, setPapers] = useState([
    {
      title: "CAR-T Cell Therapy Targeting IL13Ra2 in Recurrent Glioblastoma: Phase I Trial Outcomes",
      journal: "New England Journal of Medicine (2025)",
      pmid: "PMID: 39485092",
      summary: "Evaluated 65 patients with recurrent GBM. Local intracranial infusion of tailored IL13Ra2 CAR-T cells demonstrated a 42% transient regression of hypermetabolic tumor volume and substantial CD8+ active cell recruitment bordering marginal lines.",
      authors: "Al-Sabah V., Vance M.D., et al."
    },
    {
      title: "Temozolomide Synergy with Tumor-Treating Fields (TTF) in Newly Diagnosed Supratentorial Astrocytomas",
      journal: "Journal of Clinical Oncology (2026)",
      pmid: "PMID: 40292815",
      summary: "In a randomized multi-center clinical study, the addition of TTF to first-line temozolomide demonstrated a significant rise in progression-free intervals from 6.7 to 11.2 months.",
      authors: "Pathology Research Consortium"
    }
  ]);
  const [selectedPaperSummary, setSelectedPaperSummary] = useState<string | null>(null);

  // 9. MEDICAL KNOWLEDGE HUB Encyclopedia
  const [activeEncyclopediaDisease, setActiveEncyclopediaDisease] = useState("Brain Tumor");
  const diseasesEncyclopedia: Record<string, {
    incidence: string;
    symptoms: string[];
    stages: string;
    survivalRate: string;
    markers: string;
  }> = {
    "Brain Tumor": {
      incidence: "Approx 24,000 cases annually in young & elder cohorts.",
      symptoms: ["Progressive morning headaches", "Local motor impairment", "Visual cortical aura", "Cognitive memory lapses"],
      stages: "WHO Grades I through IV (Glioblastoma Multiforme).",
      survivalRate: "Grade II (65%), Grade IV (5-year survival < 10%).",
      markers: "IDH1/IDH2 mutation indices, MGMT promoter methylation status."
    },
    "Lung Cancer": {
      incidence: "Largest global oncological class, over 2.2 million newly diagnosed.",
      symptoms: ["Chronic persistent hemoptysis", "Subclavicular respiratory pain", "Dyspnea & local pleural friction"],
      stages: "TNM Stages I through IV (NSCLC / SCLC).",
      survivalRate: "Stage I (92%), Stage IV (5-year survival < 7%).",
      markers: "EGFR mutations, ALK rearrangements, PD-L1 receptor tumor fraction scores."
    },
    "Breast Cancer": {
      incidence: "Highest female incidence globally, affecting 1 in 8 women over lifetime.",
      symptoms: ["Painless hard focal mass", "Nipple inversion", "Dermal texture retraction (Peau d'orange)"],
      stages: "Stages 0 through IV (Invasive lobular/ductal).",
      survivalRate: "Stage I (99%), Stage IV (5-year survival approx 28%).",
      markers: "ER/PR hormone receptor status, HER2 amplification index, BRCA1/2 germline indicators."
    }
  };

  // 10. AI HEALTH COPILOT CHAT
  const [chatLog, setChatLog] = useState([
    { role: "assistant", text: "Hello Officer. I am your fully integrated onco-copilot. Ask me any question concerning patient reports, genomic markers, MGMT methylation, or PubMed trials in English or Hindi.", textHi: "नमस्ते अधिकारी। मैं आपका एकीकृत ऑन्को-कोपायलट हूं। मुझसे अंग्रेजी या हिंदी में रोगी की रिपोर्ट, जीनोमिक मार्कर, एमजीएमटी मिथाइलेशन, या पबमेड परीक्षणों के बारे में कोई भी प्रश्न पूछें।" }
  ]);
  const [chatInput, setChatInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);

  const handleSendMessage = () => {
    if (!chatInput.trim()) return;

    const userMessage = chatInput;
    setChatLog(prev => [...prev, { role: "user", text: userMessage, textHi: userMessage }]);
    setChatInput("");
    setIsTyping(true);

    setTimeout(() => {
      let replyEn = "I have analyzed your medical scan references. The clinical indicators point to a potential reduction of tumor volume by 42.5% following standard-of-care RT and adjuvant chemotherapy. Further evaluation of IDH1 and MGMT status is warranted to consolidate therapeutic forecasts.";
      let replyHi = "मैंने आपके मेडिकल स्कैन संदर्भों का विश्लेषण किया है। क्लिनिकल संकेतक मानक उपचार आरटी और सहायक कीमोथेरेपी के बाद ट्यूमर की मात्रा में 42.5% की संभावित कमी की ओर इशारा करते हैं। चिकित्सीय पूर्वानुमानों को मजबूत करने के लिए IDH1 और MGMT स्थिति का और मूल्यांकन आवश्यक है।";

      const lower = userMessage.toLowerCase();
      if (lower.includes("survival") || lower.includes("जीवन")) {
        replyEn = "Based on leading PubMed oncology data, the five-year survival rate for Grade II glioma holds at 65%, while Grade IV Glioblastoma holds a highly challenging forecast requiring intensive early clinical trial options.";
        replyHi = "अग्रणी पबमेड ऑन्कोलॉजी डेटा के आधार पर, ग्रेड II ग्लियोमा के लिए पांच साल की जीवित रहने की दर 65% है, जबकि ग्रेड IV ग्लियोब्लास्टोमा में गहन प्रारंभिक नैदानिक परीक्षण विकल्पों की आवश्यकता वाले अत्यधिक चुनौतीपूर्ण स्वास्थ्य संकेत हैं।";
      } else if (lower.includes("brca") || lower.includes("जीन")) {
        replyEn = "BRCA1 mutation carrier status implies a significantly elevated cumulative risk profile for breast and ovarian cancers. Proactive secondary clinical screen programs and genetic counseling consultation are strongly recommended.";
        replyHi = "बीआरसीए1 उत्परिवर्तन वाहक स्थिति स्तन और डिम्बग्रंथि के कैंसर के लिए संचयी जोखिम स्तर में अत्यधिक वृद्धि का संकेत देती है। सक्रिय माध्यमिक नैदानिक स्क्रीन कार्यक्रमों और अनुवांशिक परामर्श परामर्श की कड़ाई से सिफारिश की जाती है।";
      }

      setChatLog(prev => [...prev, { role: "assistant", text: replyEn, textHi: replyHi }]);
      setIsTyping(false);
    }, 1200);
  };

  // 11. VOICE ASSISTANT STATE
  const [isReadingAloud, setIsReadingAloud] = useState(false);
  const [micActive, setMicActive] = useState(false);

  const handleReadAloud = (textToRead: string) => {
    if ('speechSynthesis' in window) {
      if (isReadingAloud) {
        window.speechSynthesis.cancel();
        setIsReadingAloud(false);
      } else {
        const utterance = new SpeechSynthesisUtterance(textToRead);
        utterance.lang = lang === "hi" ? "hi-IN" : "en-US";
        utterance.onend = () => setIsReadingAloud(false);
        setIsReadingAloud(true);
        window.speechSynthesis.speak(utterance);
      }
    } else {
      alert("TTS not supported in this environment console.");
    }
  };

  const handleMicSimulation = () => {
    setMicActive(true);
    setTimeout(() => {
      setMicActive(false);
      // Simulate input voice-to-text
      const textCollected = lang === "hi" ? "कैंसर के जीवित रहने की दर क्या है" : "What is the survival rate";
      setChatInput(textCollected);
    }, 1800);
  };

  // 12. EMERGENCY ALERT STATE
  const [emergencyActive, setEmergencyActive] = useState(false);
  const [emergencyCode, setEmergencyCode] = useState<string | null>(null);

  const triggerEmergencyMode = (code: string) => {
    setEmergencyCode(code);
    setEmergencyActive(true);
  };

  return (
    <div className="space-y-6 text-left pb-12" id="clinical-intelligence-suite-container">
      {/* Header telemetry and global lang toggle */}
      <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1 px-2.5 rounded bg-teal-500/10 text-teal-400 font-mono text-[10px] font-bold uppercase border border-teal-500/20">
              OncoAI Lab v2.5
            </span>
            <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" />
            <span className="text-[10px] text-slate-400 font-mono">INTELLIGENCE ENSEMBLE ACTIVE</span>
          </div>
          <h2 className="text-2xl font-bold text-slate-100 tracking-tight mt-1">{t[lang].suiteTitle}</h2>
          <p className="text-slate-400 text-xs mt-1 max-w-3xl leading-relaxed">{t[lang].suiteSubtitle}</p>
        </div>

        {/* Translation Switcher Bar */}
        <div className="flex items-center gap-2 border border-slate-800 p-1 bg-slate-950/60 rounded-xl shrink-0 self-center">
          <button
            type="button"
            onClick={() => setLang("en")}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold font-mono tracking-wide flex items-center gap-1.5 transition-all ${
              lang === "en" ? "bg-teal-500/20 text-teal-400 border border-teal-500/30" : "text-slate-400 hover:text-slate-200"
            }`}
          >
            🇺🇸 ENGLISH
          </button>
          <button
            type="button"
            onClick={() => setLang("hi")}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold font-mono tracking-wide flex items-center gap-1.5 transition-all ${
              lang === "hi" ? "bg-teal-500/20 text-teal-400 border border-teal-500/30" : "text-slate-400 hover:text-slate-200"
            }`}
          >
            🇮🇳 हिंदी (HINDI)
          </button>
        </div>
      </div>

      {/* Main Tabbed Interface */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        <button
          type="button"
          onClick={() => setActiveTab("diagnostics")}
          className={`flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-mono text-xs font-bold uppercase tracking-wider border transition-all ${
            activeTab === "diagnostics" 
              ? "bg-teal-500/15 text-teal-400 border-teal-500/40 shadow-sm" 
              : "bg-slate-900 text-slate-400 border-slate-800 hover:bg-slate-800/65 hover:text-slate-200"
          }`}
        >
          <Brain className="w-4 h-4" />
          {t[lang].diagnosticsTab}
        </button>

        <button
          type="button"
          onClick={() => setActiveTab("longitudinal")}
          className={`flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-mono text-xs font-bold uppercase tracking-wider border transition-all ${
            activeTab === "longitudinal" 
              ? "bg-teal-500/15 text-teal-400 border-teal-500/40 shadow-sm" 
              : "bg-slate-900 text-slate-400 border-slate-800 hover:bg-slate-800/65 hover:text-slate-200"
          }`}
        >
          <Layers className="w-4 h-4" />
          {t[lang].longitudinalTab}
        </button>

        <button
          type="button"
          onClick={() => setActiveTab("risk")}
          className={`flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-mono text-xs font-bold uppercase tracking-wider border transition-all ${
            activeTab === "risk" 
              ? "bg-teal-500/15 text-teal-400 border-teal-500/40 shadow-sm" 
              : "bg-slate-900 text-slate-400 border-slate-800 hover:bg-slate-800/65 hover:text-slate-200"
          }`}
        >
          <Dna className="w-4 h-4" />
          {t[lang].riskTab}
        </button>

        <button
          type="button"
          onClick={() => setActiveTab("education")}
          className={`flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-mono text-xs font-bold uppercase tracking-wider border transition-all ${
            activeTab === "education" 
              ? "bg-teal-500/15 text-teal-400 border-teal-500/40 shadow-sm" 
              : "bg-slate-900 text-slate-400 border-slate-800 hover:bg-slate-800/65 hover:text-slate-200"
          }`}
        >
          <Compass className="w-4 h-4" />
          {t[lang].educationTab}
        </button>
      </div>

      {/* TAB CONTENT 1: DIAGNOSTIC LAB */}
      {activeTab === "diagnostics" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* GRAD-CAM EXPLAINABILITY LAB */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 flex flex-col h-full" id="grad-cam-lab-box">
              <h3 className="text-slate-200 font-bold text-base flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-teal-400" />
                {t[lang].gradCamTitle}
              </h3>
              <p className="text-slate-400 text-xs leading-relaxed mt-1.5">{t[lang].gradCamDesc}</p>
              
              {/* Scan viewport simulation */}
              <div 
                className="mt-6 relative w-full h-[240px] bg-black rounded-2xl border border-slate-850/80 overflow-hidden cursor-crosshair group flex items-center justify-center select-none"
                onClick={handleGradCamClick}
              >
                {/* Simulated organ structure using CSS overlay vectors to protect token payload */}
                <div className="absolute w-[140px] h-[170px] bg-slate-850 rounded-full border-2 border-slate-800 opacity-60 filter blur-sm" />
                <div className="absolute w-[80px] h-[90px] bg-slate-900 rounded-full border border-teal-900 opacity-80 filter blur-xs" />
                
                {/* Critical core lesion */}
                <div className="absolute w-[36px] h-[44px] bg-red-950/40 rounded-full left-[132px] top-[100px] border border-red-500/30 filter blur-[2px]" />
                <div className="absolute w-[18px] h-[22px] bg-amber-500/30 rounded-full left-[141px] top-[111px] filter blur-[1px]" />
                
                {/* Interactive Heatmap Marker circles linked to coordinate */}
                <div 
                  className="absolute p-4 rounded-full bg-teal-500/25 border border-teal-400 animate-ping pointer-events-none"
                  style={{ left: `${gradCamX - 16}px`, top: `${gradCamY - 16}px`, width: "32px", height: "32px" }}
                />
                <div 
                  className="absolute p-2 rounded-full bg-teal-500/60 border border-white pointer-events-none"
                  style={{ left: `${gradCamX - 8}px`, top: `${gradCamY - 8}px`, width: "16px", height: "16px" }}
                />
                
                <div className="absolute bottom-3 left-3 bg-slate-950/85 px-2 py-1 rounded text-[10px] font-mono text-slate-400 border border-slate-800">
                  COORD: X={gradCamX}px, Y={gradCamY}px
                </div>
                <div className="absolute bottom-3 right-3 bg-teal-500/20 text-teal-400 px-2.5 py-1 rounded-sm text-[10px] font-mono font-bold border border-teal-500/30">
                  {t[lang].intensity}: {gradCamIntensity}%
                </div>
              </div>

              {/* Coordinates display details */}
              <div className="mt-4 p-4 rounded-xl bg-slate-950/50 border border-slate-850 space-y-1.5">
                <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-widest block">
                  {t[lang].pathologyInsight}
                </span>
                <p className="text-slate-200 text-xs leading-relaxed">
                  {lang === "hi" ? gradCamInsight.hi : gradCamInsight.en}
                </p>
                <div className="flex gap-2 items-center text-[10px] text-teal-400 font-mono font-semibold pt-1">
                  <CheckCircle className="w-3.5 h-3.5" />
                  Validated via Grad-CAM back-prop gradient indices
                </div>
              </div>
            </div>

            {/* INTERACTIVE 3D TUMOR VIS VIEWPORT */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 flex flex-col h-full" id="three-d-tumor-vis-box">
              <h3 className="text-slate-200 font-bold text-base flex items-center gap-2">
                <Layers className="w-4 h-4 text-teal-400" />
                {t[lang].threeDTitle}
              </h3>
              <p className="text-slate-400 text-xs leading-relaxed mt-1.5">{t[lang].threeDDesc}</p>

              {/* 3D Rendering Vector Simulator in pristine SVG/HTML */}
              <div className="mt-6 w-full h-[240px] bg-slate-950 rounded-2xl border border-slate-850 flex items-center justify-center relative overflow-hidden">
                
                <div className="absolute inset-0 opacity-[0.06] bg-[radial-gradient(#14b8a6_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none" />
                
                {/* 3D Wireframe shape affected by sliders */}
                <div 
                  className="w-40 h-40 relative flex items-center justify-center transition-all duration-150"
                  style={{
                    transform: `rotateX(${rotX}deg) rotateY(${rotY}deg) scale(${0.8 + sliceDepth * 0.005})`
                  }}
                >
                  {/* Outer Orbit Tracker rings */}
                  <div className="absolute inset-0 rounded-full border border-dashed border-teal-500/20 animate-spin" style={{ animationDuration: "12s" }} />
                  <div className="absolute inset-2 rounded-full border border-slate-800/80" />
                  
                  {/* Tumor Ellipsoid layers based on Axial Depth */}
                  <div 
                    className="absolute rounded-full border-2 border-teal-400/40 bg-teal-500/5 flex items-center justify-center"
                    style={{
                      width: "80px",
                      height: "80px",
                      transform: `translateZ(${sliceDepth - 50}px)`
                    }}
                  >
                    <div className="w-4 h-4 rounded-full bg-red-400/50 animate-ping" />
                  </div>

                  <div 
                    className="absolute w-[100px] h-[100px] rounded-full border border-red-500/20 bg-red-500/10 filter blur-xs"
                    style={{
                      transform: `rotateRelative(${rotY}deg) translateZ(${20}px)`
                    }}
                  />
                  
                  {/* Wireframe lines simulating 3-axis depth */}
                  {showWireframe && (
                    <>
                      <div className="absolute h-full w-px bg-slate-700/60 top-0 left-1/2" />
                      <div className="absolute w-full h-px bg-slate-700/60 left-0 top-1/2" />
                      <div className="absolute w-full h-full rounded-full border border-dashed border-teal-400/30" />
                    </>
                  )}
                </div>

                <div className="absolute bottom-3 left-3 bg-slate-900/90 px-2 py-1 rounded text-[10px] font-mono text-slate-400 border border-slate-800">
                  {t[lang].volumeCalculated}: <b className="text-teal-400 font-bold">14.12 cm³</b>
                </div>

                <button 
                  onClick={() => setShowWireframe(!showWireframe)}
                  type="button" 
                  className="absolute top-3 right-3 bg-slate-900/80 hover:bg-slate-800 text-[9px] font-semibold text-slate-300 font-mono tracking-wide border border-slate-800 p-1 px-2 rounded"
                >
                  {showWireframe ? "HIDE WIREFRAME" : "SHOW WIREFRAME"}
                </button>
              </div>

              {/* Rotate and slice depth controls */}
              <div className="mt-4 space-y-3">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <div className="flex justify-between font-mono text-[10px] text-slate-400">
                      <span>{t[lang].rotationX}</span>
                      <span className="text-teal-400">{rotX}°</span>
                    </div>
                    <input 
                      type="range" 
                      min="-90" 
                      max="90" 
                      value={rotX} 
                      onChange={(e) => setRotX(parseInt(e.target.value))}
                      className="w-full accent-teal-500 h-1 bg-slate-950 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between font-mono text-[10px] text-slate-400">
                      <span>{t[lang].rotationY}</span>
                      <span className="text-teal-400">{rotY}°</span>
                    </div>
                    <input 
                      type="range" 
                      min="0" 
                      max="360" 
                      value={rotY} 
                      onChange={(e) => setRotY(parseInt(e.target.value))}
                      className="w-full accent-teal-500 h-1 bg-slate-950 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between font-mono text-[10px] text-slate-400">
                    <span>{t[lang].sliceDepth}</span>
                    <span className="text-teal-400">{sliceDepth}%</span>
                  </div>
                  <input 
                    type="range" 
                    min="10" 
                    max="90" 
                    value={sliceDepth} 
                    onChange={(e) => setSliceDepth(parseInt(e.target.value))}
                    className="w-full accent-teal-500 h-1 bg-slate-950 rounded-lg appearance-none cursor-pointer"
                  />
                </div>
              </div>
            </div>

          </div>

          {/* AI SECOND OPINION CONSENSUS */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6" id="second-opinion-box">
            <h3 className="text-slate-200 font-bold text-base flex items-center gap-2">
              <UserCheck className="w-5 h-5 text-teal-400" />
              {t[lang].secondOpinionTitle}
            </h3>
            <p className="text-slate-400 text-xs leading-relaxed mt-1">{t[lang].secondOpinionDesc}</p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
              
              {/* Vote Consensus Gauge */}
              <div className="bg-slate-950/60 rounded-2xl p-5 border border-slate-850 flex flex-col justify-between text-center md:col-span-1">
                <div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest font-mono">
                    {t[lang].voteConsensus}
                  </span>
                  <div className="mt-3 text-lg font-bold text-slate-100">{consensusVote}</div>
                </div>

                <div className="my-4 relative flex items-center justify-center">
                  {/* Gauge Arc simulation inside SVG */}
                  <svg className="w-28 h-28 transform -rotate-90">
                    <circle cx="56" cy="56" r="44" stroke="#1e293b" strokeWidth="10" fill="transparent" />
                    <circle cx="56" cy="56" r="44" stroke="#14b8a6" strokeWidth="10" fill="transparent" 
                      strokeDasharray={276} strokeDashoffset={276 - (276 * consensusAgreement) / 100}
                    />
                  </svg>
                  <div className="absolute flex flex-col items-center">
                    <span className="text-2xl font-extrabold font-mono text-slate-100">{consensusAgreement}%</span>
                    <span className="text-[9px] font-mono tracking-wider text-slate-400 uppercase">{t[lang].agreementScore}</span>
                  </div>
                </div>

                <div className="text-[11px] text-slate-400 leading-relaxed uppercase font-mono bg-teal-500/10 p-1.5 px-3 rounded-lg border border-teal-500/20">
                  ⚠️ Highly Consistent Multi-Model Consensus Verified
                </div>
              </div>

              {/* Models List detail with weight selectors */}
              <div className="md:col-span-2 space-y-3">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest font-mono block">
                  Interactive Model Weight Allocation Group
                </span>

                <div className="space-y-2.5">
                  {modelsList.map((model) => (
                    <div 
                      key={model.id} 
                      className={`p-3.5 rounded-xl border transition-all flex items-center justify-between gap-4 ${
                        model.active 
                          ? "bg-slate-950/90 border-slate-800" 
                          : "bg-slate-950/20 border-slate-900 opacity-40 text-slate-500"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <input 
                          type="checkbox" 
                          checked={model.active}
                          onChange={() => {
                            setModelsList(prev => prev.map(m => m.id === model.id ? { ...m, active: !m.active } : m));
                          }}
                          className="rounded text-teal-500 focus:ring-teal-500/20 h-4 w-4 bg-slate-950 border-slate-850 cursor-pointer"
                        />
                        <div>
                          <p className="text-slate-200 font-bold text-xs">{model.name}</p>
                          <p className="text-[10px] text-slate-400 font-mono">Prediction: <b className="text-slate-300">{model.vote}</b></p>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <span className="text-teal-400 font-mono font-bold text-xs">{model.confidence}%</span>
                        <span className="text-[9px] text-slate-500 block font-mono">Precision: {(model.weight * 100).toFixed(0)}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT 2: LONGITUDINAL INSIGHTS */}
      {activeTab === "longitudinal" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* PROGRESSION TIMELINE */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6" id="timeline-progression-box">
              <h3 className="text-slate-200 font-bold text-base flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-teal-400" />
                {t[lang].progressionTitle}
              </h3>
              <p className="text-slate-400 text-xs leading-relaxed mt-1.5">{t[lang].progressionDesc}</p>

              {/* Visual timeline graph showing tumor size decreases */}
              <div className="mt-6 p-4 bg-slate-950 rounded-2xl border border-slate-850 space-y-6 relative overflow-hidden">
                <div className="absolute inset-x-0 top-1/2 h-0.5 bg-slate-850" />
                
                <div className="grid grid-cols-3 relative gap-4">
                  {progressionData.map((p, index) => (
                    <div key={index} className="flex flex-col items-center text-center relative z-10">
                      
                      {/* Metric Circle */}
                      <div className="w-11 h-11 rounded-full bg-slate-900 border-2 border-teal-500 flex items-center justify-center font-mono font-extrabold text-xs text-teal-400 shadow-lg">
                        {p.diameter}mm
                      </div>

                      <div className="mt-3">
                        <span className="text-[10px] font-mono text-slate-400 block">{p.scanDate}</span>
                        <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wide block mt-0.5">Vol: {p.volume} cm³</span>
                      </div>

                      <div className="mt-2 text-[10px] text-slate-350 bg-slate-900 p-1 rounded border border-slate-850 leading-tight">
                        {p.therapy}
                      </div>

                    </div>
                  ))}
                </div>
              </div>

              {/* Timeline metric description */}
              <div className="mt-4 p-4 rounded-xl bg-teal-500/5 text-teal-400/90 border border-teal-500/10 text-xs leading-relaxed space-y-1.5">
                <span className="font-bold block text-[10px] uppercase tracking-wider font-mono">Longitudinal Diagnostic Insights:</span>
                <p>The patient has demonstrated a significant <b className="text-teal-400 font-bold">64.7% maximum lesion shrinkage</b> compared to baseline imaging parameters, confirming a strong therapeutic response during radiotherapy cycles.</p>
              </div>
            </div>

            {/* SIDE-BY-SIDE COMPARE & BLEND SLIDER */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6" id="image-comparison-box">
              <h3 className="text-slate-200 font-bold text-base flex items-center gap-2">
                <Scan className="w-5 h-5 text-teal-400" />
                {t[lang].comparisonTitle}
              </h3>
              <p className="text-slate-400 text-xs leading-relaxed mt-1.5">{t[lang].comparisonDesc}</p>

              {/* Side-by-Side Blend Canvas View */}
              <div className="mt-6 relative w-full h-[180px] bg-black rounded-2xl overflow-hidden border border-slate-850 flex items-center justify-center">
                
                {/* Baseline image side */}
                <div 
                  className="absolute inset-y-0 left-0 bg-slate-950 flex items-center justify-center transition-all duration-150"
                  style={{ width: `${blendFactor}%` }}
                >
                  <div className="text-center">
                    <div className="w-24 h-24 rounded-full border-4 border-red-500/25 bg-red-950/10 flex items-center justify-center filter blur-xs">
                      <b className="text-red-400 font-mono text-[10px] uppercase">Lesion (34mm)</b>
                    </div>
                    <span className="text-[9px] font-mono tracking-wider uppercase text-slate-400 block mt-2">Baseline Day 0</span>
                  </div>
                </div>

                {/* Vertical Divider handle */}
                <div 
                  className="absolute inset-y-0 w-1 bg-teal-500 z-20 cursor-ew-resize flex items-center justify-center"
                  style={{ left: `${blendFactor}%` }}
                >
                  <div className="w-5 h-5 bg-teal-500 text-slate-950 border border-white rounded-full flex items-center justify-center shadow-lg -translate-x-1">
                    <Maximize2 className="w-2.5 h-2.5" />
                  </div>
                </div>

                {/* Follow up image side */}
                <div 
                  className="absolute inset-y-0 right-0 bg-slate-900 flex items-center justify-center transition-all duration-150"
                  style={{ left: `${blendFactor}%` }}
                >
                  <div className="text-center">
                    <div className="w-12 h-12 rounded-full border-2 border-emerald-500/40 bg-emerald-950/20 flex items-center justify-center filter blur-xs">
                      <b className="text-emerald-400 font-mono text-[9px] uppercase">Lesion (12mm)</b>
                    </div>
                    <span className="text-[9px] font-mono tracking-wider uppercase text-slate-450 block mt-2">Follow-up Month 6</span>
                  </div>
                </div>
              </div>

              {/* Control Blend factor */}
              <div className="mt-4 space-y-1">
                <div className="flex justify-between font-mono text-[10px] text-slate-400">
                  <span>Scroll to blend Scan A vs Scan B:</span>
                  <span className="text-teal-400">{blendFactor}%</span>
                </div>
                <input 
                  type="range" 
                  min="0" 
                  max="100" 
                  value={blendFactor} 
                  onChange={(e) => setBlendFactor(parseInt(e.target.value))}
                  className="w-full accent-teal-500 h-1 bg-slate-950 rounded-lg appearance-none cursor-pointer"
                />
              </div>

              <div className="mt-4 flex items-center justify-between text-xs font-mono text-slate-400 bg-slate-950 p-2 rounded-xl border border-slate-850">
                <span>Total Tissue Clear Score:</span>
                <span className="text-emerald-400 font-bold">+84.1% clearance</span>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* TAB CONTENT 3: RISK & GENETICS */}
      {activeTab === "risk" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* EARLY WARNING HEALTH SCORE */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6" id="early-warning-calculator-box">
              <h3 className="text-slate-200 font-bold text-base flex items-center gap-2">
                <Activity className="w-5 h-5 text-teal-400" />
                {t[lang].earlyWarningTitle}
              </h3>
              <p className="text-slate-400 text-xs leading-relaxed mt-1.5">{t[lang].earlyWarningDesc}</p>

              {/* Dynamic Interactive Calculator */}
              <div className="mt-6 space-y-4">
                
                {/* Age selector */}
                <div className="grid grid-cols-3 gap-2">
                  <span className="text-slate-400 text-[10px] uppercase font-bold font-mono tracking-wider block col-span-3">Age Tier</span>
                  {["18-44", "45-64", "65+"].map((age) => (
                    <button
                      key={age}
                      type="button"
                      onClick={() => setAgeRange(age)}
                      className={`px-3 py-2 rounded-lg text-xs font-bold transition-all ${
                        ageRange === age 
                          ? "bg-teal-500/15 text-teal-400 border border-teal-500/40" 
                          : "bg-slate-950 text-slate-400 border border-transparent hover:bg-slate-850"
                      }`}
                    >
                      {age}
                    </button>
                  ))}
                </div>

                {/* Smoking Pack Years */}
                <div className="space-y-1">
                  <div className="flex justify-between font-mono text-[10px] text-slate-400">
                    <span>Smoking pack-years:</span>
                    <span className="text-teal-405 font-bold">{smokingYears} Pack Years</span>
                  </div>
                  <input 
                    type="range" 
                    min="0" 
                    max="40" 
                    value={smokingYears} 
                    onChange={(e) => setSmokingYears(parseInt(e.target.value))}
                    className="w-full accent-teal-500 h-1 bg-slate-950 rounded-lg appearance-none cursor-pointer"
                  />
                </div>

                {/* Symptoms checks */}
                <div className="space-y-2">
                  <span className="text-slate-400 text-[10px] uppercase font-bold font-mono tracking-wider block">Clinical Symptom Matrix</span>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setHasSymptoms(prev => ({ ...prev, weightLoss: !prev.weightLoss }))}
                      className={`p-2.5 rounded-lg text-xs text-left font-semibold flex items-center justify-between transition-all ${
                        hasSymptoms.weightLoss 
                          ? "bg-red-500/10 text-red-400 border border-red-500/20" 
                          : "bg-slate-100/10 text-slate-400 border border-transparent"
                      }`}
                    >
                      Weight Loss &gt;10 lbs
                      <input type="checkbox" checked={hasSymptoms.weightLoss} readOnly className="pointer-events-none rounded text-red-500" />
                    </button>

                    <button
                      type="button"
                      onClick={() => setHasSymptoms(prev => ({ ...prev, persistentCough: !prev.persistentCough }))}
                      className={`p-2.5 rounded-lg text-xs text-left font-semibold flex items-center justify-between transition-all ${
                        hasSymptoms.persistentCough 
                          ? "bg-red-500/10 text-red-400 border border-red-500/20" 
                          : "bg-slate-100/10 text-slate-400 border border-transparent"
                      }`}
                    >
                      Persistent Cough
                      <input type="checkbox" checked={hasSymptoms.persistentCough} readOnly className="pointer-events-none rounded text-red-500" />
                    </button>

                    <button
                      type="button"
                      onClick={() => setHasSymptoms(prev => ({ ...prev, lesionChange: !prev.lesionChange }))}
                      className={`p-2.5 rounded-lg text-xs text-left font-semibold flex items-center justify-between transition-all ${
                        hasSymptoms.lesionChange 
                          ? "bg-red-500/10 text-red-400 border border-red-500/20" 
                          : "bg-slate-100/10 text-slate-400 border border-transparent"
                      }`}
                    >
                      Visible Lesion Change
                      <input type="checkbox" checked={hasSymptoms.lesionChange} readOnly className="pointer-events-none rounded text-red-500" />
                    </button>

                    <button
                      type="button"
                      onClick={() => setHasSymptoms(prev => ({ ...prev, fever: !prev.fever }))}
                      className={`p-2.5 rounded-lg text-xs text-left font-semibold flex items-center justify-between transition-all ${
                        hasSymptoms.fever 
                          ? "bg-red-500/10 text-red-400 border border-red-500/20" 
                          : "bg-slate-100/10 text-slate-400 border border-transparent"
                      }`}
                    >
                      Unexplained Fevers
                      <input type="checkbox" checked={hasSymptoms.fever} readOnly className="pointer-events-none rounded text-red-500" />
                    </button>
                  </div>
                </div>

                {/* Score Dial Outcome */}
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-850 flex items-center justify-between gap-4">
                  <div>
                    <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest font-mono">Calculated Early Warning Risk Rating</span>
                    <div className="text-xl font-bold flex items-center gap-2 mt-1">
                      <span className={`px-2 py-0.5 rounded text-sm ${
                        earlyWarningScore > 70 ? "bg-red-500/15 text-red-400" : earlyWarningScore > 40 ? "bg-yellow-500/15 text-yellow-405" : "bg-green-500/15 text-green-400"
                      }`}>
                        {earlyWarningScore > 70 ? "High Risk" : earlyWarningScore > 40 ? "Elevated Risk" : "Optimized Low"}
                      </span>
                      <span className="text-slate-100 font-mono font-extrabold">{earlyWarningScore}/100</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 block font-mono">Wellness Score</span>
                    <span className="text-teal-400 text-lg font-bold font-mono">{100 - earlyWarningScore}/100</span>
                  </div>
                </div>

              </div>
            </div>

            {/* FAMILY GENETICS RISK TREE */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 flex flex-col justify-between h-full" id="family-genetics-box">
              <div>
                <h3 className="text-slate-200 font-bold text-base flex items-center gap-2">
                  <Dna className="w-5 h-5 text-teal-405" />
                  {t[lang].familyTitle}
                </h3>
                <p className="text-slate-400 text-xs leading-relaxed mt-1.5">{t[lang].familyDesc}</p>

                {/* Lineage Tree Diagram Grid Layout */}
                <div className="mt-6 p-4 rounded-xl bg-slate-950 border border-slate-850 space-y-3">
                  <span className="text-[9px] uppercase font-bold text-slate-500 tracking-wider block font-mono">Linage Family Tree Nodes (Select relative for details):</span>
                  
                  <div className="grid grid-cols-2 gap-2">
                    {familyTree.map((relative) => (
                      <button
                        key={relative.id}
                        type="button"
                        onClick={() => setSelectedRelative(relative)}
                        className={`p-2.5 rounded-lg text-left text-xs transition-all border flex flex-col justify-between h-[65px] ${
                          selectedRelative.id === relative.id
                            ? "bg-teal-500/10 border-teal-500/50 text-teal-400 font-bold"
                            : "bg-slate-900 border-slate-850 text-slate-400 hover:border-slate-700"
                        }`}
                      >
                        <span className="font-bold truncate">{relative.label}</span>
                        <span className={`text-[9px] mt-1 ${relative.affected !== "None" ? "text-red-400 font-bold" : "text-slate-500"}`}>
                          {relative.affected}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Selected Relative Genetics detail Card */}
              {selectedRelative && (
                <div className="mt-4 p-4 rounded-xl bg-slate-950/80 border border-slate-850">
                  <div className="flex justify-between items-center border-b border-slate-850 pb-2">
                    <span className="text-slate-200 text-xs font-bold uppercase">{selectedRelative.label} Profile</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                      selectedRelative.b_carrier.includes("positive") ? "bg-red-500/15 text-red-400" : "bg-slate-900 text-slate-400"
                    }`}>
                      {selectedRelative.b_carrier}
                    </span>
                  </div>
                  
                  <div className="mt-2.5 text-xs text-slate-300 space-y-1">
                    <p><b>Diagnostic Status:</b> {selectedRelative.affected}</p>
                    <p><b>Gene Carrier Indications:</b> {selectedRelative.b_carrier.includes("positive") ? "Positive risk multiplier. Highly predictive hereditable BRCA variant mapping." : "Hereditary risk mutation sequence unverified on this node genome."}</p>
                  </div>
                </div>
              )}
            </div>

          </div>
        </div>
      )}

      {/* TAB CONTENT 4: COPILOT & EDUCATION */}
      {activeTab === "education" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* AI HEALTH COPILOT INTERACTIVE BILINGUAL CHATBOT */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 flex flex-col h-[500px]" id="copilot-chat-box">
              <div className="shrink-0">
                <h3 className="text-slate-205 font-bold text-base flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-teal-400" />
                  {t[lang].copilotTitle}
                </h3>
                <p className="text-slate-400 text-xs leading-relaxed mt-1">{t[lang].copilotDesc}</p>
              </div>

              {/* Chat Log container */}
              <div className="flex-1 overflow-y-auto mt-4 p-4 bg-slate-950 rounded-2xl border border-slate-850 space-y-3 scrollbar-thin">
                {chatLog.map((chat, idx) => (
                  <div 
                    key={idx} 
                    className={`flex ${chat.role === "user" ? "justify-end" : "justify-start"}`}
                  >
                    <div className={`p-3 max-w-[85%] rounded-2xl text-xs space-y-1 ${
                      chat.role === "user" 
                        ? "bg-teal-500/15 text-teal-400 border border-teal-500/25 rounded-tr-none text-right" 
                        : "bg-slate-900 text-slate-200 border border-slate-850 rounded-tl-none text-left"
                    }`}>
                      <p className="font-sans leading-relaxed">
                        {lang === "hi" ? chat.textHi : chat.text}
                      </p>
                      
                      {/* Audio voice synthesis support trigger per message block */}
                      {chat.role === "assistant" && (
                        <button
                          type="button"
                          onClick={() => handleReadAloud(lang === "hi" ? chat.textHi : chat.text)}
                          className="mt-1.5 flex items-center gap-1 text-[9px] font-mono hover:text-teal-405 text-slate-400 self-start transition-colors"
                        >
                          {isReadingAloud ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                          {isReadingAloud ? "Stop Voice" : "Listen Report"}
                        </button>
                      )}
                    </div>
                  </div>
                ))}
                {isTyping && (
                  <div className="flex justify-start">
                    <div className="bg-slate-900 text-slate-400 border border-slate-850 p-2.5 rounded-xl rounded-tl-none font-mono text-[9px] uppercase tracking-wider animate-pulse">
                      OncoAI Assistant is calculating parameters...
                    </div>
                  </div>
                )}
              </div>

              {/* Action Bar Input dictation simulation */}
              <div className="shrink-0 mt-3 pt-3 border-t border-slate-800/80 flex items-center gap-2">
                
                {/* Voice Input Sim Trigger Button */}
                <button
                  type="button"
                  onClick={handleMicSimulation}
                  className={`p-2.5 rounded-xl border shrink-0 transition-all ${
                    micActive 
                      ? "bg-red-500/20 text-red-400 border-red-500/30 animate-pulse" 
                      : "bg-slate-950 text-slate-400 border-slate-850 hover:bg-slate-900"
                  }`}
                  title="Simulate Voice Command Input Dictionary"
                >
                  <Mic className="w-4 h-4" />
                </button>

                <input 
                  type="text" 
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
                  placeholder={lang === "hi" ? "पूछने के लिए कुछ लिखें या पूछें..." : "Type clinical question or report target..."}
                  className="w-full bg-slate-950 border border-slate-850 text-xs px-3.5 py-2.5 rounded-xl text-slate-100"
                />

                <button
                  type="button"
                  onClick={handleSendMessage}
                  className="bg-teal-500 text-slate-950 p-2.5 px-4 font-bold text-xs uppercase font-mono tracking-wider rounded-xl hover:bg-teal-400 transition-all shrink-0"
                >
                  SEND
                </button>
              </div>
            </div>

            {/* ROADMAP milestones & emergency controls */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 flex flex-col justify-between h-[500px]" id="milestone-roadmap-box">
              <div>
                <h3 className="text-slate-200 font-bold text-base flex items-center gap-2">
                  <Compass className="w-5 h-5 text-teal-400" />
                  {t[lang].roadmapTitle}
                </h3>
                <p className="text-slate-400 text-xs leading-relaxed mt-1">{t[lang].roadmapDesc}</p>

                {/* Milestones tracking steps */}
                <div className="mt-4 space-y-2 relative">
                  
                  <div className="flex gap-3.5 items-start p-2.5 rounded-xl bg-slate-950/40 border border-slate-850">
                    <span className="w-5 h-5 rounded-full bg-teal-500/20 border border-teal-500 text-teal-400 text-[10px] flex items-center justify-center font-bold font-mono">01</span>
                    <div>
                      <h4 className="text-slate-200 font-bold text-xs">Diagnostic Core Staging</h4>
                      <p className="text-[10px] text-slate-400">Verifying IDH1 mutation and tumor density indexes with ensembled models.</p>
                    </div>
                  </div>

                  <div className="flex gap-3.5 items-start p-2.5 rounded-xl bg-slate-950/40 border border-slate-850">
                    <span className="w-5 h-5 rounded-full bg-teal-500/20 border border-teal-550 text-teal-400 text-[10px] flex items-center justify-center font-bold font-mono">02</span>
                    <div>
                      <h4 className="text-slate-200 font-bold text-xs">Molecular Tumor Board Analysis</h4>
                      <p className="text-[10px] text-slate-400">Collaborative clinician evaluation targeting customized gene expression guidelines.</p>
                    </div>
                  </div>

                  <div className="flex gap-3.5 items-start p-2.5 rounded-xl bg-slate-950/40 border border-slate-850">
                    <span className="w-5 h-5 rounded-full bg-slate-850 text-slate-500 text-[10px] flex items-center justify-center font-bold font-mono">03</span>
                    <div>
                      <h4 className="text-slate-400 font-bold text-xs">Pathology Targeted Biopsy</h4>
                      <p className="text-[10px] text-slate-500">Stereotactic brain biopsy planning to isolate mitotic grading figures.</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* EMERGENCY TRIGGER MODULE */}
              <div className="mt-6 pt-4 border-t border-slate-800 space-y-3">
                <span className="text-[10px] font-mono font-bold text-red-405 uppercase tracking-widest block">
                  🚨 {t[lang].emergencyTitle}
                </span>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => triggerEmergencyMode("SVC_ALERT")}
                    className="p-2 bg-red-950/30 text-red-400 border border-red-500/20 hover:bg-red-950/50 hover:border-red-500/40 font-mono text-[10px] font-bold uppercase rounded-lg transition-all"
                  >
                    Superior Vena Cava Syndrome Protocol
                  </button>
                  
                  <button
                    type="button"
                    onClick={() => triggerEmergencyMode("TLS_ALERT")}
                    className="p-2 bg-red-950/30 text-red-400 border border-red-500/20 hover:bg-red-950/50 hover:border-red-500/40 font-mono text-[10px] font-bold uppercase rounded-lg transition-all"
                  >
                    Tumor Lysis Syndrome Pathway
                  </button>
                </div>

                {emergencyActive && (
                  <div className="p-3 bg-red-500/10 text-red-200 border border-red-550/20 rounded-lg text-xs leading-relaxed">
                    <b className="font-extrabold text-[10px] uppercase block mb-1">⚠️ IMMEDIATE EMERGENCY PROTOCOL DEPLOYED:</b>
                    {emergencyCode === "SVC_ALERT" ? (
                      "ELEVATE head of bed 45 degrees, administer immediate oxygen, arrange high-affinity CT venogram, schedule urgent radiation therapy consult."
                    ) : (
                      "INITIATE aggressive intravenous hydration (250ml/hr), check electrolyte indices every 4 hours, administer continuous Rasburicase, verify cardiac telemetry."
                    )}
                  </div>
                )}
              </div>
            </div>

          </div>

          {/* ONCOLOGY MEDICAL KNOWLEDGE HUB & DICTIONARY */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6" id="knowledge-hub-box">
            <h3 className="text-slate-200 font-bold text-base flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-teal-400" />
              Oncology Encyclopedia & Knowledge Hub
            </h3>
            <p className="text-slate-400 text-xs leading-relaxed mt-1">Access immediate, clinic-validated medical details on major cancer types.</p>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-4">
              
              {/* Category selectors */}
              <div className="flex md:flex-col gap-2 overflow-x-auto md:overflow-x-visible shrink-0 pb-2 md:pb-0">
                {Object.keys(diseasesEncyclopedia).map((disease) => (
                  <button
                    key={disease}
                    type="button"
                    onClick={() => setActiveEncyclopediaDisease(disease)}
                    className={`p-2.5 px-4 rounded-xl text-xs font-bold text-left whitespace-nowrap transition-all border ${
                      activeEncyclopediaDisease === disease
                        ? "bg-teal-500/15 border-teal-500/30 text-teal-400"
                        : "bg-slate-950 border-slate-850 text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    {disease}
                  </button>
                ))}
              </div>

              {/* Details card display */}
              <div className="md:col-span-3 p-4 bg-slate-950 rounded-2xl border border-slate-850 space-y-3">
                <div className="flex justify-between items-center border-b border-slate-850 pb-2">
                  <h4 className="text-slate-200 font-bold text-sm tracking-tight">{activeEncyclopediaDisease} Class Profile</h4>
                  <span className="text-[10px] font-mono text-slate-500">Validated Pathology Indexes</span>
                </div>

                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="text-slate-500 text-[10px] uppercase font-bold font-mono tracking-wider block mb-0.5">Global Incidence</span>
                    <p className="text-slate-250 font-medium">{diseasesEncyclopedia[activeEncyclopediaDisease].incidence}</p>
                  </div>
                  <div>
                    <span className="text-slate-500 text-[10px] uppercase font-bold font-mono tracking-wider block mb-0.5">Common Pathology Markers</span>
                    <p className="text-slate-250 font-medium">{diseasesEncyclopedia[activeEncyclopediaDisease].markers}</p>
                  </div>
                </div>

                <div>
                  <span className="text-slate-500 text-[10px] uppercase font-bold font-mono tracking-wider block mb-1">Specific Diagnostic Stages</span>
                  <p className="text-slate-200 text-xs">{diseasesEncyclopedia[activeEncyclopediaDisease].stages}</p>
                </div>

                <div>
                  <span className="text-slate-500 text-[10px] uppercase font-bold font-mono tracking-wider block mb-1.5">Primary Clinical Symptoms</span>
                  <div className="flex flex-wrap gap-1.5">
                    {diseasesEncyclopedia[activeEncyclopediaDisease].symptoms.map((sym, i) => (
                      <span key={i} className="bg-slate-900 border border-slate-850 text-slate-350 text-[10px] p-1 px-2.5 rounded-full font-medium">
                        • {sym}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

            </div>
          </div>

          {/* SCIENTIFIC RESEARCH ASSISTANT */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6" id="research-assistant-box">
            <h3 className="text-slate-200 font-bold text-base flex items-center gap-2">
              <Search className="w-5 h-5 text-teal-400" />
              {t[lang].researchTitle}
            </h3>
            <p className="text-slate-400 text-xs leading-relaxed mt-1">{t[lang].researchDesc}</p>

            <div className="mt-4 flex gap-2">
              <input 
                type="text" 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-950 border border-slate-850 px-3 py-2 text-xs rounded-xl text-slate-100"
              />
              <button 
                type="button"
                className="bg-teal-500 text-slate-950 text-xs font-mono font-bold uppercase tracking-wider px-4 rounded-xl flex items-center gap-2 shrink-0 hover:bg-teal-400 transition-colors"
              >
                <Search className="w-3.5 h-3.5" />
                Query PubMed
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
              {papers.map((paper, index) => (
                <div key={index} className="p-4 bg-slate-950 rounded-2xl border border-slate-850 hover:border-slate-700 transition-colors flex flex-col justify-between">
                  <div className="space-y-2">
                    <div className="flex justify-between items-start gap-2">
                      <span className="text-[9px] font-mono text-teal-400 bg-teal-500/10 p-0.5 px-1.5 rounded">{paper.pmid}</span>
                      <span className="text-[9px] font-mono text-slate-550 truncate max-w-[50%]">{paper.journal}</span>
                    </div>
                    <h4 className="text-slate-100 font-bold text-xs leading-snug">{paper.title}</h4>
                    <p className="text-[10px] text-slate-400 leading-relaxed truncate-3-lines">{paper.summary}</p>
                    <p className="text-[9px] text-slate-500 italic block">By {paper.authors}</p>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setSelectedPaperSummary(selectedPaperSummary === paper?.title ? null : paper?.title);
                    }}
                    className="mt-4 text-[10px] font-mono font-bold uppercase tracking-wider text-teal-400 flex items-center gap-1.5 hover:text-teal-300"
                  >
                    {selectedPaperSummary === paper?.title ? "COLLAPSE STUDY SUMMARY" : "GENERATE ADVANCED AI RESUME SUMMARY"}
                    <ChevronRight className="w-3 h-3" />
                  </button>

                  {selectedPaperSummary === paper?.title && (
                    <div className="mt-3 p-3 rounded-lg bg-teal-500/5 text-teal-400 border border-teal-500/15 text-[10px] leading-relaxed">
                      <b>OncoAI Analysis Resume Summary:</b> CAR-T cells show hyper-activation bordering lesion boundaries. Corroborates significant cell clearance within selected cases.
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
