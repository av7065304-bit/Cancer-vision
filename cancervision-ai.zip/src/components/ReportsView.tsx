import React, { useState } from "react";
import { MedicalScan } from "../types";
import { 
  FileText, 
  Download, 
  Printer, 
  CheckCircle, 
  AlertTriangle, 
  User, 
  Building, 
  ShieldCheck,
  Check,
  Edit3,
  Award,
  Calendar,
  Layers,
  Activity,
  UserCheck
} from "lucide-react";

interface ReportsProps {
  scans: MedicalScan[];
}

export default function ReportsView({ scans }: ReportsProps) {
  const [selectedScanId, setSelectedScanId] = useState<string>(scans[0]?.id || "");
  const [reportFormat, setReportFormat] = useState<'Doctor' | 'Patient'>('Doctor');
  const [isExporting, setIsExporting] = useState(false);
  const [exportLogged, setExportLogged] = useState(false);

  // Advanced Clinician Report Inputs
  const [orderingPhysician, setOrderingPhysician] = useState("Dr. Sandra Mehta, MD");
  const [clinicalImpression, setClinicalImpression] = useState(
    "Correlate findings with active neurological biopsy assessment. Baseline tissue margin expansion meets standard grade thresholds. Recommend continuous telemetry assessment cycles."
  );
  const [facilityName, setFacilityName] = useState("Metro Oncology & Radiomics Labs (HOS-89)");
  const [includeSecureHash, setIncludeSecureHash] = useState(true);

  const selectedScan = scans.find(s => s.id === selectedScanId) || scans[0];

  // Cryptographic signature preview
  const mockSha256 = React.useMemo(() => {
    if (!selectedScan) return "";
    const prefix = selectedScan.id.substring(0, 8);
    const dateCode = selectedScan.date || "2026";
    return `SHA256:E9C7${prefix}F8A1B2D3C4E5F6789${dateCode.replace(/[-:]/g, "")}`;
  }, [selectedScan]);

  const handlePrint = () => {
    setIsExporting(true);
    setTimeout(() => {
      setIsExporting(false);
      setExportLogged(true);
      window.print();
      setTimeout(() => setExportLogged(false), 5000);
    }, 800);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Dynamic Injectable CSS for full Media Print layouts */}
      <style dangerouslySetInnerHTML={{ __html: `
        @media print {
          /* Force standard white page margins & print color modes */
          html, body {
            background-color: #ffffff !important;
            color: #000000 !important;
            margin: 0 !important;
            padding: 0 !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }

          /* Hide UI Chrome (Navigation sidebar, filter controls, config headers, buttons) */
          header, 
          nav, 
          aside, 
          footer, 
          .no-print, 
          #btn-print-report, 
          #btn-download-report, 
          .lg\\:col-span-4,
          button,
          input,
          textarea,
          select,
          .bg-slate-900\\/50 {
            display: none !important;
          }

          /* Remap standard layout to isolate ONLY the Report Document Wrapper */
          #printable-report-wrapper {
            display: block !important;
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
            max-width: 100% !important;
            background: #ffffff !important;
            color: #000000 !important;
            margin: 0 !important;
            padding: 30px !important;
            border: none !important;
            box-shadow: none !important;
          }

          /* Color overrides for pristine grayscale high contrast reading */
          #printable-report-wrapper * {
            color: #111827 !important;
            border-color: #d1d5db !important;
          }

          #printable-report-wrapper .text-teal-450,
          #printable-report-wrapper .text-teal-400,
          #printable-report-wrapper .text-teal-500 {
            color: #0f766e !important; /* Dark solid clinical teal */
          }

          #printable-report-wrapper .text-red-400 {
            color: #be123c !important; /* High risk red translation */
          }

          #printable-report-wrapper .bg-slate-900,
          #printable-report-wrapper .bg-slate-950,
          #printable-report-wrapper .bg-teal-500\\/5 {
            background-color: #f8fafc !important;
            border: 1px solid #e2e8f0 !important;
          }

          #printable-report-wrapper .border-teal-500\\/10 {
            border-color: #cbd5e1 !important;
          }
        }
      `}} />

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 no-print">
        <div>
          <h2 className="text-2xl font-bold text-slate-100 font-sans tracking-tight">Oncology Clinical Reports</h2>
          <p className="text-slate-400 text-sm mt-1">Generate diagnostic summaries of active patient scans in doctor or patient formats.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Side: Report Options Panel (HIDDEN ON PRINT) */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-5 text-left no-print">
          <div className="space-y-4">
            <h3 className="text-slate-200 text-xs font-bold uppercase tracking-wider font-mono flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-teal-400" />
              Report Customizations
            </h3>
            
            {/* Choose patient scan */}
            <div>
              <label htmlFor="select-scan-report" className="text-slate-450 text-[10px] uppercase font-bold font-mono block mb-1">Active Medical Scan</label>
              <select
                id="select-scan-report"
                value={selectedScanId}
                onChange={(e) => setSelectedScanId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-850 text-slate-250 text-xs px-3 py-2.5 rounded-xl font-medium focus:border-teal-500/40 transition-colors"
              >
                {scans.length === 0 ? (
                  <option>No scans available</option>
                ) : (
                  scans.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.patientName} — {s.cancerType} ({s.scanType})
                    </option>
                  ))
                )}
              </select>
            </div>

            {/* Target Audience Format */}
            <div>
              <label className="text-slate-450 text-[10px] uppercase font-bold font-mono block mb-1">Audience Formulation</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setReportFormat('Doctor')}
                  className={`py-2 px-3 rounded-xl border text-xs font-bold font-mono transition-all ${
                    reportFormat === 'Doctor'
                      ? "bg-teal-500/10 text-teal-400 border-teal-500/40"
                      : "bg-slate-950 border-slate-850 text-slate-400 hover:text-slate-300"
                  }`}
                >
                  💼 Clinical
                </button>
                <button
                  type="button"
                  onClick={() => setReportFormat('Patient')}
                  className={`py-2 px-3 rounded-xl border text-xs font-bold font-mono transition-all ${
                    reportFormat === 'Patient'
                      ? "bg-teal-500/10 text-teal-400 border-teal-500/40"
                      : "bg-slate-950 border-slate-850 text-slate-400 hover:text-slate-300"
                  }`}
                >
                  👤 Patient-Safe
                </button>
              </div>
            </div>

            {/* Ordering Physician Signature Block */}
            <div>
              <label htmlFor="ordering-physician" className="text-slate-450 text-[10px] uppercase font-bold font-mono block mb-1">Ordering Practitioner</label>
              <div className="relative">
                <input
                  id="ordering-physician"
                  type="text"
                  value={orderingPhysician}
                  onChange={(e) => setOrderingPhysician(e.target.value)}
                  placeholder="e.g. Dr. Sandra Mehta, MD"
                  className="w-full bg-slate-950 border border-slate-850 text-slate-250 text-xs pl-8 pr-3 py-2 rounded-xl font-medium focus:border-teal-500/40 transition-colors"
                />
                <UserCheck className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-3" />
              </div>
            </div>

            {/* Radiomics lab center list */}
            <div>
              <label htmlFor="facility-selection" className="text-slate-450 text-[10px] uppercase font-bold font-mono block mb-1">Clinic/Facility Letterhead</label>
              <select
                id="facility-selection"
                value={facilityName}
                onChange={(e) => setFacilityName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-850 text-slate-250 text-xs px-3 py-2.5 rounded-xl font-medium focus:border-teal-500/40 transition-colors"
              >
                <option value="Metro Oncology & Radiomics Labs (HOS-89)">Metro Oncology Labs (HOS-89)</option>
                <option value="Apex AI Therapeutics Center">Apex AI Therapeutics Center</option>
                <option value="State Solid Tumor Imaging Suite">State Solid Tumor Imaging Suite</option>
                <option value="St. Jude Integrated Oncology Pavilion">St. Jude Pavilion</option>
              </select>
            </div>

            {/* Physician Addendum Notes */}
            <div>
              <label htmlFor="clinical-opinion" className="text-slate-450 text-[10px] uppercase font-bold font-mono block mb-1 flex items-center justify-between">
                <span>Clinician Impression Note</span>
                <span className="text-[9px] text-teal-400 lowercase font-medium flex items-center gap-1"><Edit3 className="w-2.5 h-2.5" /> renders live</span>
              </label>
              <textarea
                id="clinical-opinion"
                value={clinicalImpression}
                onChange={(e) => setClinicalImpression(e.target.value)}
                rows={3}
                placeholder="Type additional findings, clinical guidelines, biopsy scheduling details..."
                className="w-full bg-slate-950 border border-slate-850 text-slate-250 text-xs px-3 py-2 rounded-xl leading-relaxed focus:border-teal-500/40 transition-colors resize-none font-sans"
              />
            </div>

            {/* Crypto Stamp Settings Toggle */}
            <div className="flex items-center gap-2 bg-slate-950 p-2.5 border border-slate-850 rounded-xl">
              <input
                id="checkbox-secure-hash"
                type="checkbox"
                checked={includeSecureHash}
                onChange={(e) => setIncludeSecureHash(e.target.checked)}
                className="w-4 h-4 rounded text-teal-500 border-slate-800 bg-slate-900 focus:ring-0 focus:ring-offset-0"
              />
              <label htmlFor="checkbox-secure-hash" className="text-slate-350 text-[10.5px] font-mono tracking-wide cursor-pointer flex-1">
                Crypto Integrity Verification
              </label>
            </div>
          </div>

          {/* Action button container */}
          <div className="border-t border-slate-800/80 pt-4 space-y-2.5">
            <button
              onClick={handlePrint}
              id="btn-print-report"
              disabled={isExporting || !selectedScan}
              className="w-full bg-teal-500 hover:bg-teal-450 disabled:opacity-50 text-slate-950 font-bold py-2.5 rounded-xl text-xs transition-all flex items-center justify-center gap-2 shadow-[0_4px_12px_rgba(20,184,166,0.15)] select-none cursor-pointer"
            >
              <Printer className="w-4 h-4" /> 
              {isExporting ? "Formatting document..." : "Print / Export to PDF"}
            </button>

            <span className="text-[10px] text-slate-500 block text-center font-mono leading-relaxed px-1">
              Provides clean print formats. Select <b>"Save as PDF"</b> in your device browser print dialogue to retrieve the offline file.
            </span>

            {exportLogged && (
              <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-mono font-semibold uppercase tracking-wider text-center py-2 rounded-lg">
                ✓ Local EHR audit logged. Registry ready.
              </div>
            )}
          </div>
        </div>

        {/* Right Side: High-Fidelity Report Document Mock (ISOLATES AND RENDERS FOR PRINTING) */}
        <div 
          id="printable-report-wrapper" 
          className="lg:col-span-8 bg-slate-950 border border-slate-800 p-8 sm:p-10 rounded-2xl flex flex-col justify-between text-left space-y-6 text-slate-300 shadow-xl relative overflow-hidden"
        >
          {/* Subtle medical watermark */}
          <div className="absolute top-0 right-0 p-6 opacity-[0.03] pointer-events-none print:opacity-[0.01]">
            <FileText className="w-56 h-56 text-teal-400" />
          </div>

          {!selectedScan ? (
            <div className="h-64 flex flex-col items-center justify-center text-slate-500 text-sm">
              <FileText className="w-12 h-12 mb-2 text-slate-500" />
              <span>No clinical patient data matches current filtration query.</span>
            </div>
          ) : (
            <>
              {/* Document Letterhead */}
              <div className="flex flex-col sm:flex-row justify-between items-start gap-4 pb-6 border-b border-slate-800">
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <Activity className="w-5 h-5 text-teal-450" />
                    <h3 className="text-lg font-extrabold font-sans tracking-tight text-slate-100 uppercase">
                      {facilityName}
                    </h3>
                  </div>
                  <p className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">
                    Diagnostic Radiomics Laboratory • CancerVision Node
                  </p>
                </div>
                <div className="text-right sm:text-right space-y-1">
                  <p className="text-[11px] font-bold text-teal-400 font-mono">AUTOMATED CLINICAL CLEARANCE REPORT</p>
                  <p className="text-[9.5px] text-slate-500 font-mono">Report Ref: CV-ML-{selectedScan.id.substring(0,8).toUpperCase()}</p>
                </div>
              </div>

              {/* Patient Profile Demographics and Source Scans */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-sans">
                <div className="bg-slate-900/50 border border-slate-800/60 p-4 rounded-xl space-y-2">
                  <span className="text-teal-400 text-[10px] uppercase font-bold font-mono tracking-widest block">Patient Identification</span>
                  <p className="text-slate-100 font-bold text-sm tracking-tight">{selectedScan.patientName}</p>
                  <div className="grid grid-cols-3 gap-2 text-slate-400 font-mono text-[9.5px] pt-1">
                    <div>
                      <span className="block text-slate-500 lowercase">Age</span>
                      <b className="text-slate-300">{selectedScan.patientAge} Years</b>
                    </div>
                    <div>
                      <span className="block text-slate-500 lowercase">Gender</span>
                      <b className="text-slate-300">{selectedScan.patientSex === "M" ? "Male" : selectedScan.patientSex === "F" ? "Female" : "Other"}</b>
                    </div>
                    <div>
                      <span className="block text-slate-500 lowercase">Status</span>
                      <b className="text-emerald-400">Validated</b>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-900/50 border border-slate-800/60 p-4 rounded-xl space-y-3">
                  <span className="text-teal-400 text-[10px] uppercase font-bold font-mono tracking-widest block">Clinical Referral Metrics</span>
                  <div className="grid grid-cols-2 gap-2 text-slate-300 font-mono text-[9.5px]">
                    <div>
                      <span className="text-slate-500 block lowercase">Assigned Practitioner</span>
                      <b className="text-slate-200 block truncate">{orderingPhysician}</b>
                    </div>
                    <div>
                      <span className="text-slate-500 block lowercase">Scan Classification</span>
                      <b className="text-slate-200 block">{selectedScan.scanType} Frame</b>
                    </div>
                    <div>
                      <span className="text-slate-500 block lowercase">Compile Date</span>
                      <b className="text-slate-200 block">{selectedScan.date || "2026-06-07"}</b>
                    </div>
                    <div>
                      <span className="text-slate-500 block lowercase">Oncology Target</span>
                      <b className="text-slate-200 block">{selectedScan.cancerType}</b>
                    </div>
                  </div>
                </div>
              </div>

              {/* Patient Scan Image preview simulation in light markup */}
              <div className="no-print bg-slate-900 border border-slate-850 p-3 rounded-xl flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <img 
                    src={selectedScan.imageUrl} 
                    alt="Scan thumbnail" 
                    className="w-12 h-12 object-cover rounded-lg border border-slate-700 bg-slate-950 shrink-0" 
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <h5 className="text-slate-200 text-xs font-semibold">{selectedScan.fileName}</h5>
                    <p className="text-slate-500 text-[10px] font-mono uppercase mt-0.5">Source radiological array matrix</p>
                  </div>
                </div>
                <div className="text-xs text-right font-mono">
                  <span className="text-slate-400 block text-[9px] lowercase">Active Annotations</span>
                  <b className="text-teal-400">{selectedScan.annotations?.length || 0} Segment Tracing</b>
                </div>
              </div>

              {/* Vital Intelligence Section: AI Radiomics Score */}
              <div className="p-5 bg-teal-500/5 rounded-xl border border-teal-500/10 text-left space-y-3">
                <div className="flex justify-between items-center text-xs font-mono font-bold">
                  <span className="text-teal-400 uppercase tracking-wider flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-teal-450" />
                    CancerVision AI Forecast Summary
                  </span>
                  <span className="text-teal-400 font-extrabold">{selectedScan.confidence}% Probability Yield</span>
                </div>
                
                <div className="space-y-1">
                  <p className="text-slate-150 text-base font-extrabold leading-tight tracking-tight">
                    {selectedScan.prediction}
                  </p>
                  <p className="text-[10.5px] text-slate-400 leading-normal">
                    Target parameters processed via multi-model radiology convolutional ensembles.
                  </p>
                </div>
                
                <div className="flex flex-wrap items-center gap-2 pt-1 text-slate-450 text-[10px] font-mono">
                  <span className={`inline-flex px-2 py-0.5 rounded text-[9.5px] font-bold uppercase border ${
                    selectedScan.riskLevel === 'High' 
                      ? "bg-red-950/40 text-red-400 border-red-900/35" 
                      : "bg-yellow-950/40 text-yellow-500 border-yellow-900/35"
                  }`}>
                    {selectedScan.riskLevel} Triage Risk Category
                  </span>
                  <span className="text-slate-500">•</span>
                  <span>Neural Gradient CAM isolation indicates severe active cluster bounds.</span>
                </div>
              </div>

              {/* Histopathological / Patient Findings block */}
              <div className="space-y-3.5">
                <h4 className="text-slate-100 font-extrabold text-xs uppercase font-mono tracking-widest border-l-2 border-teal-500 pl-2">
                  {reportFormat === 'Doctor' ? "Histopathological & Radiographic Findings" : "Patient-Friendly Scan Observations & Explanations"}
                </h4>

                <div className="space-y-2.5 pl-1">
                  {selectedScan.findings.map((finding, idx) => (
                    <div key={idx} className="flex gap-2.5 text-xs leading-relaxed">
                      <span className="text-teal-400 font-bold font-mono">[{idx + 1}]</span>
                      <p className="text-slate-300">
                        {reportFormat === 'Doctor' 
                          ? finding 
                          : finding.replace(/spiculed|adenocarcinoma|glioma|vasogenic/gi, "atypical anomalous micro-structure indicators")}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Advanced Physician Diagnosis & Impressions Addendum */}
              <div className="space-y-3 bg-slate-900/40 p-4 rounded-xl border border-slate-850/50">
                <h4 className="text-slate-100 font-extrabold text-xs uppercase font-mono tracking-widest flex items-center gap-1.5 text-slate-300">
                  <Award className="w-4 h-4 text-slate-400" />
                  Ordering Physician Clinical Impression
                </h4>
                <p className="text-slate-200 text-xs leading-relaxed font-sans font-medium italic pl-1">
                  "{clinicalImpression || "No secondary clinician comments appended."}"
                </p>
              </div>

              {/* Core Patient Action Items & Recommendations */}
              <div className="space-y-3.5">
                <h4 className="text-slate-100 font-extrabold text-xs uppercase font-mono tracking-widest flex items-center gap-1.5 text-red-400 pl-1">
                  <AlertTriangle className="w-4.5 h-4.5" /> 
                  Oncology Recommendation Plan
                </h4>
                <div className="space-y-2.5 pl-1">
                  {selectedScan.recommendations.map((rec, idx) => (
                    <div key={idx} className="flex gap-2.5 text-xs leading-relaxed">
                      <span className="text-red-400 font-extrabold">•</span>
                      <p className="text-slate-300 font-medium">{rec}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Formal physical endorsement & Cryptographic certification blocks */}
              <div className="pt-6 border-t border-slate-850 space-y-6">
                
                {/* Visual cryptographic SHA indicator */}
                {includeSecureHash && (
                  <div className="bg-slate-900/60 p-3 rounded-lg border border-slate-850/80 flex items-center justify-between text-[10px] font-mono text-slate-500">
                    <span className="uppercase text-[9px] flex items-center gap-1 text-slate-400">
                      <ShieldCheck className="w-3.5 h-3.5 text-teal-500" />
                      EHR Secure Registry Stamp
                    </span>
                    <span className="truncate max-w-[280px] text-slate-400 text-right uppercase selection:bg-teal-500/30">
                      {mockSha256}
                    </span>
                  </div>
                )}

                {/* Hand Signature Block for offline clinician sign-off */}
                <div className="flex flex-col sm:flex-row justify-between items-end gap-6 text-[10px] font-mono text-slate-500 pt-2">
                  <div className="space-y-1">
                    <p className="uppercase text-[9px] text-slate-400">Report Authenticated By</p>
                    <p className="text-slate-200 text-sm font-extrabold">{orderingPhysician}</p>
                    <p className="text-[9px] text-slate-500 uppercase tracking-widest">{facilityName}</p>
                  </div>
                  
                  {/* Signature Placeholder Line */}
                  <div className="text-right w-full sm:w-48 border-t border-slate-800 leading-normal pt-2 mt-4 space-y-0.5">
                    <span className="text-slate-400 block font-mono text-[9px] uppercase tracking-wider">Authorized Endorsement</span>
                    <span className="text-slate-600 block text-[8px] uppercase">Date Sign: _____________________</span>
                  </div>
                </div>

                <div className="text-[9px] text-slate-600 font-mono text-center flex flex-col sm:flex-row justify-between gap-2 border-t border-slate-900 pt-4">
                  <span>© CancerVision Radiomics Diagnostic Suite • Encrypted HIPAA Compliant Interface</span>
                  <span>Page 1 of 1 • Local Timestamp {new Date().toLocaleDateString()}</span>
                </div>
              </div>
            </>
          )}

        </div>

      </div>
    </div>
  );
}
