import React, { useState, useMemo } from "react";
import { CancerType, RiskLevel } from "../types";
import { 
  Pill, 
  ShieldAlert, 
  Search, 
  Filter, 
  ChevronDown, 
  ChevronUp, 
  Info, 
  Printer, 
  CheckCircle2, 
  Sparkles, 
  Plus, 
  Trash2, 
  Activity,
  Heart,
  Calendar,
  AlertTriangle
} from "lucide-react";

interface CancerMedicineRecommendationsProps {
  cancerType: CancerType;
  confidence: number;
  riskLevel: RiskLevel;
}

interface Medicine {
  name: string;
  type: "Chemotherapy" | "Immunotherapy" | "Targeted Therapy" | "Hormone Therapy" | "Corticosteroid" | "Supportive Care" | "Antibody-Drug Conjugate";
  purpose: string;
  howItWorks: string;
  commonDosage: string;
  administration: string;
  sideEffects: string[];
  protocolRelevance: number; // 0-100 score for how standard it is
}

// Global dictionary map of Oncology Medicines by Cancer Type
const MEDICINE_REGISTRY: Record<string, Medicine[]> = {
  "Brain Tumor": [
    {
      name: "Temozolomide (Temodar)",
      type: "Chemotherapy",
      purpose: "Standard first-line adjuvant chemotherapy alongside and post cranial radiation therapy.",
      howItWorks: "Undergoes rapid chemical conversion at physiological pH to an active alkylating agent, cross-linking DNA coils of glial cells.",
      commonDosage: "150mg to 200mg/m² orally once daily for 5 consecutive days of a 28-day cycle.",
      administration: "Oral capsules (empty stomach at bedtime to reduce nausea).",
      sideEffects: ["Myelosuppression", "Nausea/Vomiting", "Fatigue", "Thrombocytopenia"],
      protocolRelevance: 98
    },
    {
      name: "Bevacizumab (Avastin)",
      type: "Targeted Therapy",
      purpose: "Approved for recurrent glioblastoma (GBM) to shrink vascular pathways feeding the neoplasm.",
      howItWorks: "Monoclonal antibody that maps and binds to VEGF ligands, preventing endothelial angiogenesis and lowering peritumoral edema.",
      commonDosage: "10 mg/kg intravenously every 2 weeks.",
      administration: "Intravenous infusion (IV over 30-60 minutes).",
      sideEffects: ["Hypertension", "Delayed Wound Healing", "Proteinuria", "Nosebleeds"],
      protocolRelevance: 85
    },
    {
      name: "Lomustine (Gleostine)",
      type: "Chemotherapy",
      purpose: "Prescribed as a high-efficacy single-agent therapy for progressive or recurrent brain tumors.",
      howItWorks: "Nitrosourea alkylating agent that is highly lipid-soluble, allowing it to easily slip through the blood-brain barrier to disrupt DNA replication.",
      commonDosage: "110 mg/m² orally as a single dose once every 6 weeks.",
      administration: "Oral capsules taken altogether in a single night dose.",
      sideEffects: ["Delayed Bone Marrow Suppression", "Leukopenia", "Pulmonary Fibrosis"],
      protocolRelevance: 78
    },
    {
      name: "Carmustine (Gliadel Wafer)",
      type: "Chemotherapy",
      purpose: "Direct intracranial implantation during surgical resection of high-grade malignant gliomas.",
      howItWorks: "Biodegradable polymer wafers dissolve directly in the post-operative cavity, dispersing carmustine over several weeks.",
      commonDosage: "Up to 8 wafers (total 61.6 mg) implanted directly inside the surgical resection margin.",
      administration: "Surgical local implantation (neurosurgeon placed).",
      sideEffects: ["Impaired Healing", "Intracranial Infection", "Cerebrospinal Fluid Leak"],
      protocolRelevance: 72
    },
    {
      name: "Dexamethasone (Decadron)",
      type: "Corticosteroid",
      purpose: "Vital companion drug to handle cerebral edema, raised intracranial pressure, and neurological symptoms.",
      howItWorks: "Inhibits macrophage activation and local inflammatory response, reducing vessel perm-permeability in the glial microenvironment.",
      commonDosage: "4 mg to 16 mg daily in split oral or IV doses.",
      administration: "Oral tablets, liquid syrups, or Intravenous.",
      sideEffects: ["Hyperglycemia", "Weight Gain / Fluid Retention", "Adrenal Suppression", "Insomnia"],
      protocolRelevance: 95
    },
    {
      name: "Etoposide (VP-16)",
      type: "Chemotherapy",
      purpose: "Used in salvage regimens for refractory brain neoplasms, medulloblastomas, or pineoblastomas.",
      howItWorks: "Inhibits Topoisomerase II enzyme activity, arresting DNA cleavage and causing fatal double-strand fractures in rapidly growing cells.",
      commonDosage: "50 mg/m² per day orally for 21 consecutive days of a 28-day cycle.",
      administration: "Oral capsules or Intravenous infusion.",
      sideEffects: ["Alopecia", "Severe Leukopenia", "Anaphylaxis on rapid infusion"],
      protocolRelevance: 65
    }
  ],
  "Lung Cancer": [
    {
      name: "Pembrolizumab (Keytruda)",
      type: "Immunotherapy",
      purpose: "First-line option for advanced, metastatic non-small cell lung cancer (NSCLC) overexpressing PD-L1.",
      howItWorks: "Blocks the PD-1 receptor pathway on host T-cells, preventing cancer cells from hiding and enabling immune-driven clearance.",
      commonDosage: "200 mg intravenously every 3 weeks or 400 mg every 6 weeks.",
      administration: "Intravenous infusion (IV over 30 minutes).",
      sideEffects: ["Pneumonitis", "Immune-Mediated Colitis", "Thyroiditis", "Skin Rash"],
      protocolRelevance: 96
    },
    {
      name: "Osimertinib (Tagrisso)",
      type: "Targeted Therapy",
      purpose: "Standard adjuvant or first-line treatment for EGFR mutation-positive NSCLC (exon 19 deletions, L858R).",
      howItWorks: "Irreversible third-generation EGFR tyrosine kinase inhibitor that traps active signaling loops in mutant lung cells.",
      commonDosage: "80 mg orally once daily.",
      administration: "Oral tablet (with or without food).",
      sideEffects: ["Diarrhea", "Dry Skin / Nail Toxicity", "QT Prolongation", "Interstitial Lung Disease"],
      protocolRelevance: 92
    },
    {
      name: "Cisplatin (Platinol)",
      type: "Chemotherapy",
      purpose: "The fundamental platinum core for dual-chemotherapy protocols in both NSCLC and small cell lung cancer (SCLC).",
      howItWorks: "Formulates covalent intrastrand crosslinks with purine DNA bases, kinking the genome structure to stimulate high-rate apoptosis.",
      commonDosage: "50 mg to 100 mg/m² intravenously once every 3 to 4 weeks.",
      administration: "Intravenous infusion with aggressive saline pre-hydration.",
      sideEffects: ["Severe Nephrotoxicity", "Ototoxicity (Hearing Loss)", "Peripheral Neuropathy"],
      protocolRelevance: 90
    },
    {
      name: "Pemetrexed (Alimta)",
      type: "Chemotherapy",
      purpose: "Specifically indicated for maintenance of advanced non-squamous non-small cell lung cancer.",
      howItWorks: "Antifolate drug that inhibits thymidylate synthase and dihydrofolate reductase, preventing thymidine nucleotide assembly.",
      commonDosage: "500 mg/m² intravenously on day 1 of each 21-day cycle.",
      administration: "IV infusion flanked by vitamin B12 and folic acid support.",
      sideEffects: ["Hematologic Toxicity", "Severe Mucositis", "Hand-Foot Skin Cracking"],
      protocolRelevance: 82
    },
    {
      name: "Nivolumab (Opdivo)",
      type: "Immunotherapy",
      purpose: "Prescribed for metastatic squamous-cell lung cancer following platinum-based chemotherapy failures.",
      howItWorks: "Monoclonal checkpoint antibody targeting PD-1 receptors, restoring anti-tumor cytotoxicity.",
      commonDosage: "240 mg intravenously every 2 weeks or 480 mg every 4 weeks.",
      administration: "Intravenous infusion.",
      sideEffects: ["Pruritis / Rash", "Colitis", "Hepatitis", "Hypophysitis"],
      protocolRelevance: 80
    },
    {
      name: "Alectinib (Alecensa)",
      type: "Targeted Therapy",
      purpose: "Designed solely for patients with ALK gene rearrangement-positive metastatic NSCLC.",
      howItWorks: "Highly selective inhibitor of ALK and RET tyrosine kinases, halting intracellular phosphorylation vectors.",
      commonDosage: "600 mg orally twice daily.",
      administration: "Oral capsules taken with food.",
      sideEffects: ["Bradycardia", "Myalgia / Creatine Kinase Elevation", "Hepatotoxicity", "Photosensitivity"],
      protocolRelevance: 88
    }
  ],
  "Skin Cancer": [
    {
      name: "Dabrafenib (Tafinlar)",
      type: "Targeted Therapy",
      purpose: "Indicated to treat advanced melanomas positive for BRAF V600E or V600K oncogenic mutations.",
      howItWorks: "Inhibits mutant RAF kinase activity, halting downstream MAP kinase pathway activation in cutaneous cells.",
      commonDosage: "150 mg orally twice daily.",
      administration: "Oral capsule, taken 1 hour before or 2 hours after meals.",
      sideEffects: ["Hyperkeratosis", "Pyrexia (Severe Fever)", "Arthralgia", "Squamous Cell Carcinomas of skin"],
      protocolRelevance: 90
    },
    {
      name: "Trametinib (Mekinist)",
      type: "Targeted Therapy",
      purpose: "Combined with Dabrafenib to prevent rapid drug resistance and augment outcome metrics in BRAF melanoma.",
      howItWorks: "Highly selective kinase inhibitor targeting MEK1 and MEK2 proteins directly below RAF inside cell cycles.",
      commonDosage: "2 mg orally once daily.",
      administration: "Oral tablet, taken on an empty stomach at the same time each day.",
      sideEffects: ["Lymphedema", "Hypertension", "Dermatitis Acneiform", "Intermittent Chills"],
      protocolRelevance: 89
    },
    {
      name: "Ipilimumab (Yervoy)",
      type: "Immunotherapy",
      purpose: "Treats unresectable, metastatic, or node-positive cutaneous melanoma following resection.",
      howItWorks: "Recombinant monoclonal antibody that binds CTLA-4, blocking its down-regulation loop to keep T-lymphocytes aggressively active.",
      commonDosage: "3 mg/kg intravenously every 3 weeks for up to 4 doses total.",
      administration: "Intravenous infusion (with telemetry filter).",
      sideEffects: ["Autoimmune Enterocolitis", "Severe Skin Pruritus", "Endocrinopathies"],
      protocolRelevance: 85
    },
    {
      name: "Pembrolizumab (Keytruda)",
      type: "Immunotherapy",
      purpose: "Adjuvant care for stage IIB, IIC, or III melanoma following complete surgical excision of the primary lesion.",
      howItWorks: "PD-1 receptor blocker that wakes up cytotoxic T-cells, enabling them to destroy remaining local micro-nodules.",
      commonDosage: "200 mg intravenously every 3 weeks.",
      administration: "Intravenous infusion.",
      sideEffects: ["Thyroid anomalies", "Pneumonitis", "Skin depolarization (Vitiligo)"],
      protocolRelevance: 92
    },
    {
      name: "Vismodegib (Erivedge)",
      type: "Targeted Therapy",
      purpose: "Designed solely for advanced, metastatic, or recurrent Basal Cell Carcinoma (BCC) that is unfit for surgery or radiation.",
      howItWorks: "Inhibits smoothened (SMO) receptor in the Hedgehog signaling pathway, disrupting dermal tissue metastasis.",
      commonDosage: "150 mg orally once daily.",
      administration: "Oral capsule (swallowed whole).",
      sideEffects: ["Muscle Spasms (Severe)", "Dysgeusia (Loss of Taste)", "Alopecia", "Weight Loss"],
      protocolRelevance: 84
    },
    {
      name: "Fluorouracil (5-FU / Efudex)",
      type: "Chemotherapy",
      purpose: "Topical chemotherapy for actinic keratoses and superficial, multi-focal Basal Cell Carcinomas.",
      howItWorks: "Binds thymidylate synthase topically, starving local abnormal cells of pyrimidine co-factors, which provokes sloughing.",
      commonDosage: "Apply a thin film of 5% cream twice daily to selected skin lesions.",
      administration: "Topical cream application (wear gloves, avoid eyes/lips).",
      sideEffects: ["Local Erythema", "Burning / Ulceration", "Severe Photosensitivity", "Pain"],
      protocolRelevance: 75
    }
  ],
  "Breast Cancer": [
    {
      name: "Tamoxifen (Nolvadex)",
      type: "Hormone Therapy",
      purpose: "Essential chemoprevention and adjuvant treatment for estrogen receptor-positive (ER+) breast cancer in pre- and postmenopausal women.",
      howItWorks: "Selective Estrogen Receptor Modulator (SERM) that binds estrogen receptors in breast cells, blocking estrogen-mediated mitosis.",
      commonDosage: "20 mg orally once daily.",
      administration: "Oral tablet, taken daily for 5 to 10 consecutive years.",
      sideEffects: ["Hot Flashes", "Endometrial Carcinoma Risk", "Deep Vein Thrombosis", "Fluid Retention"],
      protocolRelevance: 97
    },
    {
      name: "Trastuzumab (Herceptin)",
      type: "Targeted Therapy",
      purpose: "Indicated to treat early-stage or metastatic breast cancer overexpressing HER2.",
      howItWorks: "Monoclonal antibody that binds the extracellular domain of HER2 receptors to disrupt downstream signaling and tag cell coordinates for ADCC immune clearing.",
      commonDosage: "4 mg/kg loading dose, then 2 mg/kg weekly; or 8 mg/kg loading, then 6 mg/kg every 3 weeks.",
      administration: "Intravenous infusion over 30-90 minutes (monitor Cardiac LVEF periodically).",
      sideEffects: ["Cardiomyopathy (Congestive Heart Failure)", "Infusion-related Chills", "Pulmonary toxicity"],
      protocolRelevance: 95
    },
    {
      name: "Anastrozole (Arimidex)",
      type: "Hormone Therapy",
      purpose: "Adjuvant endocrine therapy for hormone receptor-positive early breast cancer in postmenopausal women.",
      howItWorks: "Potent and selective non-steroidal aromatase inhibitor, shutting down conversion of adrenally derived androgens into estrogen.",
      commonDosage: "1 mg orally once daily.",
      administration: "Oral tablet, taken daily for 5 years.",
      sideEffects: ["Joint Pain (Arthralgia)", "Osteoporosis/Fractures", "Ischemic Cardiovascular Disease"],
      protocolRelevance: 94
    },
    {
      name: "Palbociclib (Ibrance)",
      type: "Targeted Therapy",
      purpose: "Taken in combination with endocrine blockers (Letrozole or Fulvestrant) for newly diagnosed HR+/HER2- metastatic stage IV cancers.",
      howItWorks: "Reversible inhibitor of Cyclin-Dependent Kinases 4 and 6 (CDK4/6), stopping cell replication at the G1 restriction envelope.",
      commonDosage: "125 mg orally once daily for 21 days, followed by 7 drug-free days (28-day cycle).",
      administration: "Oral capsule or tablet taken with food.",
      sideEffects: ["Neutropenia", "Leukopenia", "Fatigue", "Anemia"],
      protocolRelevance: 88
    },
    {
      name: "Paclitaxel (Taxol)",
      type: "Chemotherapy",
      purpose: "Adjuvant node-positive or metastatic breast cancer taxane chemotherapy standard of care.",
      howItWorks: "Microtubule stabilizer. Promotes assembly of tubulin dimers and prevents their disassembly, locking the cell in G2/M phase and triggering cell death.",
      commonDosage: "80 mg/m² intravenously weekly, or 175 mg/m² every 3 weeks.",
      administration: "IV infusion over 3 hours with corticosteroid & antihistamine pre-medications to prevent hypersensitivity.",
      sideEffects: ["Severe Peripheral Neuropathy", "Neutropenia", "Complete Alopecia (Hair Loss)", "Myalgia"],
      protocolRelevance: 88
    },
    {
      name: "Pembrolizumab (Keytruda)",
      type: "Immunotherapy",
      purpose: "High-risk, early-stage triple-negative breast cancer (TNBC) in combination with upfront chemotherapy.",
      howItWorks: "Blocks the PD-1 immune checkpoint to allow T-cells to aggressively clear the active TNBC clonal population.",
      commonDosage: "200 mg intravenously every 3 weeks.",
      administration: "Intravenous infusion.",
      sideEffects: ["Pneumonitis", "Adrenal Insufficiency", "Skin Pruritus/Vitiligo"],
      protocolRelevance: 85
    }
  ],
  "Colon Cancer": [
    {
      name: "Fluorouracil (5-FU / Adrucil)",
      type: "Chemotherapy",
      purpose: "The fundamental antimetabolite backbone of all stage III and metastatic colon chemotherapy regimens (FOLFOX).",
      howItWorks: "Pyrimidine analog that is converted to active nucleotide metabolites, blocking thymidylate synthase and halting pyrimidine synthesis required for DNA repair.",
      commonDosage: "400 mg/m² IV bolus on Day 1, followed by 2400 mg/m² as a continuous IV infusion over 46 hours.",
      administration: "Continuous ambulatory intravenous infusion pump, requiring surgically placed Port-a-Cath.",
      sideEffects: ["Hand-Foot Syndrome", "Severe Mucositis", "Diarrhea", "Leukopenia"],
      protocolRelevance: 99
    },
    {
      name: "Oxaliplatin (Eloxatin)",
      type: "Chemotherapy",
      purpose: "Paired with 5-FU and Leucovorin (FOLFOX) as first-line adjuvant therapy for resected high-risk stage III colon cancer.",
      howItWorks: "Third-generation platinum agent that induces intrastrand and interstrand DNA cross-links, locking transcription.",
      commonDosage: "85 mg/m² intravenously on Day 1 of a 14-day cycle.",
      administration: "Intravenous infusion over 2 hours.",
      sideEffects: ["Cold-Induced Laryngeal Dysesthesia (Throat Spasm)", "Peripheral Neuropathy", "Thrombocytopenia"],
      protocolRelevance: 95
    },
    {
      name: "Capecitabine (Xeloda)",
      type: "Chemotherapy",
      purpose: "Oral alternative to intravenous continuous 5-FU for adjuvant treatment of stage III colon carcinoma.",
      howItWorks: "Systemic oral fluoropyrimidine carbamate prodrug that undergoes 3-step enzymatic conversion to active 5-FU, concentrating inside tumor sectors.",
      commonDosage: "1250 mg/m² orally twice daily for 14 days, followed by a 7-day rest (21-day cycle).",
      administration: "Oral tablets, swallowed with water within 30 minutes after eating.",
      sideEffects: ["Dominant Hand-Foot Syndrome", "Diarrhea", "Nausea", "Hyperbilirubinemia"],
      protocolRelevance: 92
    },
    {
      name: "Irinotecan (Camptosar)",
      type: "Chemotherapy",
      purpose: "Given in FOLFIRI combinations for progressive, metastatic colorectal cancer.",
      howItWorks: "Semi-synthetic camptothecin derivative that binds topoisomerase I, blocking replication fork transition and causing double-strand breaks.",
      commonDosage: "180 mg/m² intravenously on Day 1 of a 14-day cycle.",
      administration: "Intravenous infusion over 90 minutes.",
      sideEffects: ["Severe Acute and Delayed Diarrhea (Cholinergic Syndrome)", "Neutropenia", "Abdominal Pain"],
      protocolRelevance: 88
    },
    {
      name: "Cetuximab (Erbitux)",
      type: "Targeted Therapy",
      purpose: "Indicated to treat EGFR-expressing, RAS wild-type (unmutated KRAS/NRAS) metastatic colorectal cancer.",
      howItWorks: "Recombinant chimeric human/mouse monoclonal antibody that blocks ligand binding on EGFR, stopping RAF-MEK downstream tumor proliferation.",
      commonDosage: "400 mg/m² initial IV loading dose, then 250 mg/m² weekly.",
      administration: "Intravenous infusion preceded by H1-antagonist premedication.",
      sideEffects: ["Acneiform Skin Rash (Correlates with therapeutic efficacy)", "Severe Hypomagnesemia"],
      protocolRelevance: 82
    },
    {
      name: "Panitumumab (Vectibix)",
      type: "Targeted Therapy",
      purpose: "Alternative EGFR monoclonal antibody for unmutated KRAS colorectal cancers when chimerism reactions occur with Cetuximab.",
      howItWorks: "Fully human IgG2 monoclonal antibody targeting EGFR, causing internal degradation of the cell surface receptor.",
      commonDosage: "6 mg/kg intravenously once every 14 days.",
      administration: "Intravenous infusion.",
      sideEffects: ["Dermatologic Toxicity", "Paronychia", "Electrolyte Depletion (Magnesium, Potassium)"],
      protocolRelevance: 80
    }
  ],
  "Cervical Cancer": [
    {
      name: "Cisplatin (Platinol)",
      type: "Chemotherapy",
      purpose: "Primary radiosensitizing chemotherapeutic drug administered concurrently with weekly pelvic radiotherapy.",
      howItWorks: "Produces platinum-DNA adducts in cervical cells, impairing cellular repair loops to maximize the DNA-shattering effects of radiation beams.",
      commonDosage: "40 mg/m² intravenously weekly on radiation days, for 5 to 6 weeks.",
      administration: "IV infusion with mandatory high-volume pre-hydration and anti-emetics.",
      sideEffects: ["Oliguric Renal Failure", "Severe Acute Emesis", "Anemia"],
      protocolRelevance: 98
    },
    {
      name: "Paclitaxel (Taxol)",
      type: "Chemotherapy",
      purpose: "Paired with platinum drugs (Cisplatin or Carboplatin) as standard systemic therapy for advanced stage IV or recurrent cervix tumors.",
      howItWorks: "Mitotic inhibitor that freezes tubulin spindle arrays in cervical squamous tissues, stopping metaphase processes.",
      commonDosage: "135 to 175 mg/m² intravenously over 3 hours every 3 weeks.",
      administration: "Intravenous infusion.",
      sideEffects: ["Neutropenia", "Complete Hair Loss", "Hypersensitivity / Anaphylaxis Risk"],
      protocolRelevance: 88
    },
    {
      name: "Pembrolizumab (Keytruda)",
      type: "Immunotherapy",
      purpose: "Approved in combination with chemotherapy + Bevacizumab for persistent, recurrent, or metastatic cervical cancer expressing PD-L1.",
      howItWorks: "Interrupts PD-1 checkpoint shields to mobilize cervical pelvic immune clearings.",
      commonDosage: "200 mg intravenously every 3 weeks.",
      administration: "Intravenous infusion.",
      sideEffects: ["Hypophysitis", "Pneumonitis", "Immune skin blistering"],
      protocolRelevance: 85
    },
    {
      name: "Bevacizumab (Avastin)",
      type: "Targeted Therapy",
      purpose: "Administered alongside cisplatin/paclitaxel to treat recurrent cervical cancers.",
      howItWorks: "Blocks VEGF angiogenesis pathways, cutting off active micro-vascular supply lines inside pelvic lesions.",
      commonDosage: "15 mg/kg intravenously every 3 weeks.",
      administration: "Intravenous infusion.",
      sideEffects: ["Gastrointestinal Fistula or Perforation", "Hypertensive Crises", "Slow Scarring / Wound Dehiscence"],
      protocolRelevance: 82
    },
    {
      name: "Topotecan (Hycamtin)",
      type: "Chemotherapy",
      purpose: "Alternative combination chemotherapy standard for patients with cervical cancer progressing after cisplatin therapy.",
      howItWorks: "Camptothecin analogue that inhibits Topoisomerase I, promoting double-stranded DNA cracks during replication phase.",
      commonDosage: "0.75 mg/m² IV daily on Days 1, 2, and 3 of a 21-day cycle.",
      administration: "Intravenous infusion.",
      sideEffects: ["Extreme Neutropenia (Life-threatening)", "Severe Thrombocytopenia", "Anorexia"],
      protocolRelevance: 70
    },
    {
      name: "Tisotumab Vedotin (Tivdak)",
      type: "Antibody-Drug Conjugate",
      purpose: "Approved for recurrent, chemotherapy-refractory cervical squamous or adenocarcinoma.",
      howItWorks: "First-in-class antibody-drug conjugate (ADC). Target-binds Tissue Factor (TF) on tumor cell membranes, undergoes cellular internalization, and releases monomethyl auristatin E (MMAE) micro-toxins to disrupt tubulin assembly.",
      commonDosage: "2 mg/kg intravenously once every 3 weeks.",
      administration: "IV infusion with strictly mandated protective cool eye packs during infusion.",
      sideEffects: ["Severe Conjunctivitis and Keratitis (Corneal Ulceration)", "Neuropathy", "Epistaxis"],
      protocolRelevance: 75
    }
  ],
  "Leukemia": [
    {
      name: "Imatinib (Gleevec)",
      type: "Targeted Therapy",
      purpose: "Standard first-line kinase blocker for Chronic Myelogenous Leukemia (CML) showing active Philadelphia chromosome (Ph+, t(9;22)).",
      howItWorks: "Selectively maps the ATP-binding crevice of mutant BCR-ABL fusion protein kinase, shutting down the white blast cell division cascade.",
      commonDosage: "400 mg to 600 mg orally once daily.",
      administration: "Oral tablet, taken with a meal and a large glass of water.",
      sideEffects: ["Fluid Retention (Periorbital Edema)", "Muscle Cramps (Skeletal)", "Nausea", "Neutropenia"],
      protocolRelevance: 99
    },
    {
      name: "Rituximab (Rituxan)",
      type: "Targeted Therapy",
      purpose: "Indicated to treat CD20-expressing Chronic Lymphocytic Leukemia (CLL) in combination with Fludarabine and Cyclophosphamide (FCR).",
      howItWorks: "Chimeric monoclonal antibody that targets the CD20 antigen expressed on B-cell surfaces, triggering ADCC and complement-dependent cytolysis.",
      commonDosage: "375 mg/m² intravenously for cycle 1, then 500 mg/m² for cycles 2-6.",
      administration: "Intravenous infusion with slow titration. Requires severe tumor lysis syndrome pre-prophylaxis.",
      sideEffects: ["Fatal Infusion Reactions", "Severe Tumor Lysis Syndrome", "Hepatitis B Reactivation"],
      protocolRelevance: 95
    },
    {
      name: "Cytarabine (Ara-C / Tarabine)",
      type: "Chemotherapy",
      purpose: "Major pyrimidine antimetabolite induction and consolidation core for Acute Myeloid Leukemia (AML) (e.g. 7+3 regimen).",
      howItWorks: "Becomes active Ara-CTP in cells, competitively integrating with replicating strands to block DNA polymerase activity.",
      commonDosage: "100 to 200 mg/m² IV continuous daily infusion for 7 consecutive days (induction).",
      administration: "Continuous IV infusion or high-dose subcutaneous.",
      sideEffects: ["Cytarabine-induced Cerebellar Toxicity (Ataxia, Dysarthria)", "Chemical Conjunctivitis", "Myelosuppression"],
      protocolRelevance: 96
    },
    {
      name: "Venetoclax (Venclexta)",
      type: "Targeted Therapy",
      purpose: "Treats CLL or AML (first-line in elderly, in combination with Azacitidine).",
      howItWorks: "Selectively binds B-cell Lymphoma-2 (BCL-2) anti-apoptotic protein, restoring the cell's natural apoptotic signaling to self-destruct leukemic cells.",
      commonDosage: "Weekly dose ramp-up scale from 20 mg up to 400 mg daily (to prevent rapid tumor lysis).",
      administration: "Oral tablet taken daily at constant times with food.",
      sideEffects: ["Tumor Lysis Syndrome", "Neutropenia", "Upper respiratory infections"],
      protocolRelevance: 90
    },
    {
      name: "Blinatumomab (Blincyto)",
      type: "Immunotherapy",
      purpose: "Indicated to treat Philadelphia-negative relapsed/refractory B-cell precursor Acute Lymphoblastic Leukemia (ALL).",
      howItWorks: "Bispecific T-cell Engager (BiTE) antibody that forms a transient physical link between T-cell CD3 receptors and leukemia CD19 antigens.",
      commonDosage: "9 mcg/day continuous IV infusion on Days 1-7, then 28 mcg/day on Days 8-28. 28-day continuous cycle.",
      administration: "Continuous 28-day constant IV infusion via specialized ambulatory portable pump.",
      sideEffects: ["Cytokine Release Syndrome (CRS)", "Neurological Toxicities (ICANS - Seizures, Aphasia)"],
      protocolRelevance: 82
    },
    {
      name: "Vincristine (Oncovin)",
      type: "Chemotherapy",
      purpose: "Essential mitotic spindle inhibitor in ALL induction chemotherapy (hyper-CVAD protocol).",
      howItWorks: "Binds intracellular tubulin, halting spindle formation, which halts leukemic cells during metaphase.",
      commonDosage: "1.4 mg/m² (capped at a strict absolute maximum dose of 2 mg) intravenously weekly.",
      administration: "Intravenous infusion ONLY. (FATAL IF GIVEN BY OTHER ROUTES like intrathecal. Must use fatal warning labels).",
      sideEffects: ["Severe Neuropathy / Foot Drop", "Constipation / Paralytic Ileus", "Alopecia"],
      protocolRelevance: 92
    }
  ]
};

// Extremely professional fallback medications if is generic solid tumor scan is present
const FALLBACK_MEDS: Medicine[] = [
  {
    name: "Cyclophosphamide (Cytoxan)",
    type: "Chemotherapy",
    purpose: "Broad-spectrum solid tumor alkylating therapeutic frequently used in combined regimens.",
    howItWorks: "Undergoes hepatic activation to phosphoramide mustard, binding DNA strands and creating fatal crosslinks.",
    commonDosage: "600 mg/m² intravenously every 3 weeks as part of multi-agent plans.",
    administration: "Intravenous or oral capsules (maintain heavy hydration to guard bladder).",
    sideEffects: ["Hemorrhagic Cystitis (Bladder bleeding)", "Significant Neutropenia", "Alopecia"],
    protocolRelevance: 85
  },
  {
    name: "Doxorubicin (Adriamycin)",
    type: "Chemotherapy",
    purpose: "Anthracycline antitumor antibiotic used for diverse adenocarcinomas and sarcomas.",
    howItWorks: "Intercalates between DNA base pairs, inhibits Topoisomerase II, and releases free oxygen radicals that damage cellular structures.",
    commonDosage: "60 mg to 75 mg/m² intravenously once every 3 weeks.",
    administration: "IV push via free-flowing saline (extravasation vesicant risk).",
    sideEffects: ["Irreversible Cardiotoxicity (CHF)", "Red Urine (Benign discoloration)", "Severe Stomatitis/Myelosuppression"],
    protocolRelevance: 88
  },
  {
    name: "Everolimus (Afinitor)",
    type: "Targeted Therapy",
    purpose: "Prescribed to treat hormone-positive advanced cancers and neuroendocrine solid lesions.",
    howItWorks: "Inhibitor of mTOR (mammalian target of rapamycin), turning off growth factor vectors that drive proliferation and angiogenesis.",
    commonDosage: "10 mg orally once daily.",
    administration: "Oral tablet taken daily at constant times.",
    sideEffects: ["severe Aphthous Ulcers (Mouth sores)", "Hyperlipidemia", "Non-infectious Pneumonitis"],
    protocolRelevance: 78
  },
  {
    name: "Prednisone (Rayos)",
    type: "Corticosteroid",
    purpose: "Broad auxiliary medication to suppress systemic immune distress and mitigate infusion anomalies.",
    howItWorks: "Binds to glucocorticoid receptors to dial down pro-inflammatory cytokine transcription networks.",
    commonDosage: "20 mg to 100 mg orally daily depending on protocol triggers.",
    administration: "Oral tablets.",
    sideEffects: ["Mood Alterations", "Insomnia", "Transient Immune Suppression"],
    protocolRelevance: 90
  }
];

export default function CancerMedicineRecommendations({ cancerType, confidence, riskLevel }: CancerMedicineRecommendationsProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedTypeFilter, setSelectedTypeFilter] = useState<string>("All");
  const [expandedMeds, setExpandedMeds] = useState<Record<string, boolean>>({});
  const [customDosageNotes, setCustomDosageNotes] = useState<Record<string, string>>({});
  const [customOrders, setCustomOrders] = useState<Array<{ id: string; name: string; type: string; dose: string; note: string }>>([]);

  const drugCategories = ["All", "Chemotherapy", "Immunotherapy", "Targeted Therapy", "Hormone Therapy", "Corticosteroid", "Antibody-Drug Conjugate"];

  // Match cancerType safely or use fallbacks
  const medicines = useMemo(() => {
    // Find matching key safely (case/prefix friendly)
    const matchingKey = Object.keys(MEDICINE_REGISTRY).find(
      (key) => key.toLowerCase().includes(cancerType.toLowerCase()) || cancerType.toLowerCase().includes(key.toLowerCase())
    );
    return matchingKey ? MEDICINE_REGISTRY[matchingKey] : FALLBACK_MEDS;
  }, [cancerType]);

  const filteredMedicines = useMemo(() => {
    return medicines.filter((med) => {
      const matchesSearch = med.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            med.purpose.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            med.howItWorks.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesFilter = selectedTypeFilter === "All" || med.type === selectedTypeFilter;
      return matchesSearch && matchesFilter;
    });
  }, [medicines, searchTerm, selectedTypeFilter]);

  const toggleExpand = (medName: string) => {
    setExpandedMeds(prev => ({
      ...prev,
      [medName]: !prev[medName]
    }));
  };

  // Custom Order Planner actions
  const handleAddOrder = (med: Medicine) => {
    const defaultDose = med.commonDosage.split(" for ")[0] || med.commonDosage;
    const notesInput = customDosageNotes[med.name] || "";
    
    // Avoid double adding
    if (customOrders.some(o => o.name === med.name)) {
      alert("This medication is already inside the active treatment plan planner.");
      return;
    }

    const newOrder = {
      id: `order-${Date.now()}-${Math.random().toString(36).substring(2,7)}`,
      name: med.name,
      type: med.type,
      dose: defaultDose,
      note: notesInput || "Standard institutional protocol. Monitor labs."
    };

    setCustomOrders(prev => [...prev, newOrder]);
    // clear input
    setCustomDosageNotes(prev => ({ ...prev, [med.name]: "" }));
  };

  const handleRemoveOrder = (id: string) => {
    setCustomOrders(prev => prev.filter(o => o.id !== id));
  };

  const handlePrintPlan = () => {
    const printWindow = window.open("", "_blank");
    if (!printWindow) {
      alert("Please allow popups to retrieve the formatted prescription guideline sheet.");
      return;
    }

    const orderLinesHtml = customOrders.length > 0 
      ? customOrders.map((o, idx) => `
        <tr style="border-bottom: 1px solid #e2e8f0;">
          <td style="padding: 10px; font-weight: bold; font-size: 12px; color: #1e293b;">[${idx + 1}] ${o.name}</td>
          <td style="padding: 10px; font-size: 11px; font-family: monospace; font-weight: bold; color: #0d9488;">${o.type}</td>
          <td style="padding: 10px; font-size: 11.5px; font-weight: bold; color: #0284c7;">${o.dose}</td>
          <td style="padding: 10px; font-size: 11px; color: #475569; font-style: italic;">"${o.note}"</td>
        </tr>
      `).join("")
      : `<tr><td colspan="4" style="text-align: center; padding: 24px; color: #94a3b8; font-style: italic;">No medications custom appended by oncologist. Showing typical defaults below.</td></tr>`;

    const defaultsHtml = medicines.map((m, idx) => `
      <div style="margin-bottom: 15px; border-bottom: 1px dashed #cbd5e1; padding-bottom: 10px;">
        <span style="font-weight: bold; color:#1e293b; font-size: 12px;">💊 ${m.name}</span> 
        <span style="font-size: 10px; padding: 2px 6px; background: #f1f5f9; border-radius: 4px; font-weight: bold; color: #475569; margin-left: 8px;">${m.type}</span>
        <p style="margin: 5px 0 2px 0; font-size: 11px; color: #334155;"><b>Purpose:</b> ${m.purpose}</p>
        <p style="margin: 0; font-size: 11px; color: #475569;"><b>Mechanism of Action:</b> ${m.howItWorks}</p>
        <p style="margin: 3px 0 0 0; font-size: 11px; font-family: monospace; color:#0d9488;"><b>Recommended Dosage:</b> ${m.commonDosage}</p>
      </div>
    `).join("");

    printWindow.document.write(`
      <html>
        <head>
          <title>Clinical Oncological Drug Guideline — ${cancerType}</title>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; padding: 40px; color: #1e293b; line-height: 1.5; }
            .header { border-bottom: 2px solid #0d9488; padding-bottom: 15px; margin-bottom: 25px; }
            .title { font-size: 18px; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; color: #0f172a; margin: 0; }
            .subtitle { font-size: 11px; font-family: monospace; color: #64748b; margin-top: 4px; }
            .meta-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 15px; margin-bottom: 20px; display: flex; justify-content: space-between; font-size: 12px; }
            .meta-item b { color: #0f172a; }
            .disclaimer { border: 1px solid #fca5a5; background: #fef2f2; border-radius: 6px; padding: 12px; font-size: 10.5px; color: #991b1b; font-style: italic; margin-top: 30px; margin-bottom: 20px; }
            .section-title { font-size: 13px; font-weight: bold; text-transform: uppercase; color: #0d9488; border-left: 3px solid #0d9488; padding-left: 8px; margin-top: 25px; margin-bottom: 12px; }
            table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
            th { text-align: left; background: #f8fafc; padding: 10px; font-size: 11px; text-transform: uppercase; color: #475569; border-bottom: 2px solid #e2e8f0; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1 class="title">CancerVision Medicine recommendation registry</h1>
            <p class="subtitle">Oncology AI Clinical Decision Support Pipeline • Date Triggered: ${new Date().toLocaleDateString()}</p>
          </div>

          <div class="meta-box">
            <div class="meta-item">🧬 <b>Detected Type:</b> ${cancerType}</div>
            <div class="meta-item">🎯 <b>AI Confidence:</b> ${confidence.toFixed(1)}%</div>
            <div class="meta-item">⚠️ <b>Triage Risk:</b> ${riskLevel}</div>
          </div>

          <div class="section-title">Dr-Formulated Treatment Plan (Added Orders)</div>
          <table>
            <thead>
              <tr>
                <th>Drug Name</th>
                <th>Category</th>
                <th>Prescribed Dosing Outline</th>
                <th>Special Clinician Notes</th>
              </tr>
            </thead>
            <tbody>
              ${orderLinesHtml}
            </tbody>
          </table>

          <div class="section-title">Standard Care Registry Reference for ${cancerType}</div>
          <div style="font-size: 11px;">
            ${defaultsHtml}
          </div>

          <div class="disclaimer">
            <b>MEDICAL DISCLAIMER:</b> These medicines are provided for educational and informational purposes only. Actual treatment decisions, medicine selection, and dosage must be determined by a qualified oncologist based on the patient's cancer type, stage, medical history, laboratory reports, and overall health condition.
          </div>

          <div style="text-align: center; margin-top: 40px; font-size: 10px; color: #94a3b8; border-t: 1px solid #f1f5f9; padding-top: 15px;">
            CancerVision AI Oncology Suite • Secure HIPAA Registry Report Ref: ONC-MED-${Math.random().toString(36).substring(2,7).toUpperCase()}
          </div>

          <script>
            window.onload = function() { window.print(); }
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 md:p-6 space-y-6 relative overflow-hidden text-left bg-gradient-to-br from-slate-900 via-slate-900/40 to-slate-950 shadow-2xl">
      {/* Decorative absolute lights */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-teal-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-32 h-32 bg-purple-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Title & Metadata Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/80 pb-5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-pink-500/10 via-purple-500/10 to-cyan-500/10 border border-purple-500/20 flex items-center justify-center text-pink-400 shadow-[0_0_15px_rgba(236,72,153,0.15)]">
            <Pill className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h3 className="text-base font-extrabold text-slate-100 font-sans tracking-tight flex items-center gap-1.5">
              Oncology Medicine Recommendations
              <span className="text-[10px] uppercase font-mono bg-pink-950/40 border border-pink-500/25 px-1.5 py-0.5 rounded text-pink-400 font-bold tracking-wider flex items-center gap-1">
                <Sparkles className="w-2.5 h-2.5 animate-spin" /> Live AI Guide
              </span>
            </h3>
            <p className="text-slate-405 text-xs font-mono mt-0.5">TARGETED PHARMACOTHERAPY & MOLECULAR ONCOLOGY REGISTRY</p>
          </div>
        </div>

        {/* Action Controls for Plan printing */}
        <button
          onClick={handlePrintPlan}
          className="bg-slate-950 border border-slate-800 hover:border-pink-500/30 text-slate-200 hover:text-pink-400 text-xs font-bold font-mono px-4 py-2 rounded-xl transition-all flex items-center gap-2 cursor-pointer shadow-lg"
        >
          <Printer className="w-4 h-4" /> Print Treatment Guidelines
        </button>
      </div>

      {/* 📋 Section 1: Detected Cancer Information (Bento Grid cards) */}
      <div className="bg-slate-950/80 border border-slate-850 p-4 rounded-xl space-y-3 relative">
        <div className="flex items-center justify-between border-b border-slate-900 pb-2">
          <h4 className="text-xs font-bold font-mono text-slate-350 flex items-center gap-1.5">
            <Info className="w-3.5 h-3.5 text-teal-400" />
            📋 CANCER DIAGNOSTIC CLASSIFICATION
          </h4>
          <span className="text-[9px] font-mono text-slate-500">OncoRef-Secure</span>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5 pt-1">
          {/* Detected Cancer Card */}
          <div className="bg-slate-900/80 border border-slate-800/60 p-3 rounded-lg flex flex-col justify-between relative group hover:border-cyan-500/20 transition-all">
            <span className="text-[10px] text-slate-500 font-mono uppercase">Detected Cancer Type</span>
            <span className="font-extrabold text-slate-100 text-sm mt-1.5 font-sans leading-tight group-hover:text-cyan-400 transition-colors">
              {cancerType}
            </span>
          </div>

          {/* Confidence Score Gauge */}
          <div className="bg-slate-900/80 border border-slate-800/60 p-3 rounded-lg flex items-center justify-between relative group hover:border-purple-500/20 transition-all">
            <div className="flex flex-col">
              <span className="text-[10px] text-slate-500 font-mono uppercase">Classification Confidence</span>
              <span className="font-mono font-extrabold text-[#06b6d4] text-lg mt-1 group-hover:text-cyan-300 transition-colors">
                {confidence.toFixed(1)}%
              </span>
            </div>
            
            {/* Holographic Circular Progress wheel */}
            <div className="relative w-11 h-11 flex items-center justify-center shrink-0">
              <svg className="w-full h-full transform -rotate-90">
                <circle cx="22" cy="22" r="18" className="stroke-slate-800" strokeWidth="3" fill="none" />
                <circle 
                  cx="22" 
                  cy="22" 
                  r="18" 
                  className="stroke-cyan-500/70" 
                  strokeWidth="3.5" 
                  fill="none" 
                  strokeDasharray="113" 
                  strokeDashoffset={113 - (113 * confidence) / 100}
                />
              </svg>
              <span className="absolute text-[8.5px] font-bold font-mono text-cyan-400">CI</span>
            </div>
          </div>

          {/* Risk Level gauge */}
          <div className="bg-slate-900/80 border border-slate-800/60 p-3 rounded-lg flex items-center justify-between relative group hover:border-pink-500/20 transition-all">
            <div className="flex flex-col">
              <span className="text-[10px] text-slate-500 font-mono uppercase">Clinical Oncology Risk</span>
              <span className={`font-bold text-sm uppercase mt-2 inline-flex items-center gap-1.5 ${
                riskLevel === "High" 
                  ? "text-red-400" 
                  : riskLevel === "Medium" 
                  ? "text-amber-400" 
                  : "text-emerald-400"
              }`}>
                <Activity className="w-3.5 h-3.5 animate-pulse" />
                {riskLevel} Severity
              </span>
            </div>
            <div className="p-2 rounded-lg bg-slate-950">
              <span className={`w-3.5 h-3.5 rounded-full block border ${
                riskLevel === "High" 
                  ? "bg-red-500 border-red-400 animate-ping" 
                  : riskLevel === "Medium" 
                  ? "bg-amber-500 border-amber-400" 
                  : "bg-emerald-500 border-emerald-450"
              }`} />
            </div>
          </div>
        </div>
      </div>

      {/* Treatment Planner Builder Panel */}
      <div className="bg-slate-950/60 border border-slate-850 p-4 rounded-xl space-y-4">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-bold font-mono text-slate-355 flex items-center gap-1.5">
            <Heart className="w-3.5 h-3.5 text-pink-400" />
            DRUG FORMULARY CLINICAL PLANNER
          </h4>
          <span className="text-[10px] text-slate-500 font-mono font-bold uppercase">{customOrders.length} active orders</span>
        </div>

        {customOrders.length === 0 ? (
          <p className="text-[11px] text-slate-500 italic font-medium leading-relaxed bg-slate-900/30 p-4 border border-slate-850/40 rounded-lg text-center">
            No customized prescriptions or active drug orders listed yet. Use the <b>"+ Add to Active Plan"</b> toggles on medications listed below to draft a customized patient-facing guidance outline.
          </p>
        ) : (
          <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
            {customOrders.map((order) => (
              <div key={order.id} className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex items-center justify-between gap-4 group transition-all hover:border-pink-500/25">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-100">{order.name}</span>
                    <span className="text-[8.5px] font-mono bg-teal-900/30 border border-teal-500/20 px-1 py-0.5 rounded text-teal-400 uppercase font-semibold">{order.type}</span>
                  </div>
                  <div className="flex flex-col sm:flex-row sm:items-center gap-4 text-[10.5px] text-slate-400 leading-normal">
                    <span className="font-mono text-slate-300 font-semibold text-[10px]">Dosage: <b className="text-pink-400 font-bold">{order.dose}</b></span>
                    <span className="italic truncate max-w-[280px]">"{order.note}"</span>
                  </div>
                </div>

                <button
                  onClick={() => handleRemoveOrder(order.id)}
                  className="p-1.5 hover:bg-red-950/20 border border-transparent hover:border-red-900/40 text-slate-500 hover:text-red-400 rounded-lg transition-all"
                  title="Remove from planner"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Search and Category filtration row */}
      <div className="flex flex-col md:flex-row md:items-center gap-3.5 justify-between">
        <div className="relative flex-1">
          <input
            type="text"
            placeholder="Search medications by name, category, or symptoms..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-850 text-slate-200 text-xs pl-8.5 pr-4 py-2.5 rounded-xl font-medium focus:border-purple-500/40 transition-colors"
          />
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3.5" />
        </div>

        {/* Category toggler slider */}
        <div className="flex gap-1 overflow-x-auto pb-1 max-w-full">
          {drugCategories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedTypeFilter(cat)}
              className={`px-3 py-1.5 rounded-lg text-[10.5px] font-bold font-mono transition-all uppercase whitespace-nowrap ${
                selectedTypeFilter === cat
                  ? "bg-gradient-to-r from-purple-500/10 to-pink-500/10 text-pink-400 border border-pink-500/25 font-bold"
                  : "bg-slate-950 text-slate-500 hover:text-slate-300 border border-transparent hover:bg-slate-900/60"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* 💊 Section 2: Recommended Medicines Cards List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between px-1">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-widest font-bold">
            💊 Recommended FDA-Approved Protocols ({filteredMedicines.length} found)
          </span>
          <span className="text-[10px] text-slate-500 font-mono">Matched specifically to {cancerType} indications</span>
        </div>

        {filteredMedicines.length === 0 ? (
          <div className="h-28 bg-slate-950/60 border border-slate-850/75 rounded-2xl flex flex-col items-center justify-center gap-1.5 text-slate-500 text-xs italic">
            <Search className="w-8 h-8 text-slate-650 animate-bounce" />
            <span>No oncology medicines match current filtrations.</span>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4">
            {filteredMedicines.map((med) => {
              const isExpanded = !!expandedMeds[med.name];
              return (
                <div 
                  key={med.name} 
                  className={`bg-slate-950 border transition-all duration-300 rounded-xl overflow-hidden ${
                    isExpanded 
                      ? "border-purple-500/30 bg-gradient-to-b from-slate-950 to-slate-900/20 shadow-xl" 
                      : "border-slate-850 hover:border-slate-800"
                  }`}
                >
                  {/* Collapsed top bar trigger */}
                  <div 
                    onClick={() => toggleExpand(med.name)}
                    className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 cursor-pointer select-none group"
                  >
                    <div className="space-y-1.5 flex-1 pr-4">
                      <div className="flex items-center flex-wrap gap-2.5">
                        <h5 className="font-extrabold text-xs text-slate-100 font-mono tracking-tight flex items-center gap-1.5 group-hover:text-pink-450 transition-colors">
                          💊 MEDICINE: {med.name}
                        </h5>
                        <span className={`px-2 py-0.5 rounded text-[8.5px] font-mono uppercase font-bold border ${
                          med.type === "Chemotherapy" 
                            ? "bg-red-950/40 text-red-400 border-red-500/20" 
                            : med.type === "Immunotherapy" 
                            ? "bg-blue-950/40 text-blue-400 border-blue-500/20" 
                            : med.type === "Targeted Therapy" 
                            ? "bg-cyan-950/40 text-cyan-400 border-cyan-500/20" 
                            : "bg-purple-950/40 text-purple-400 border-purple-500/20"
                        }`}>
                          Type: {med.type}
                        </span>
                      </div>
                      <p className="text-[11.5px] text-slate-350 leading-relaxed font-sans font-medium line-clamp-1 group-hover:text-slate-200 transition-colors">
                        Purp: {med.purpose}
                      </p>
                    </div>

                    {/* Progress score + expanded arrow */}
                    <div className="flex items-center gap-4 shrink-0 justify-between sm:justify-end">
                      <div className="text-right flex flex-col gap-0.5 pr-2">
                        <span className="text-[8.5px] font-mono text-slate-500 uppercase tracking-widest block">Standard Practice Ratio</span>
                        <div className="flex items-center gap-2">
                          <div className="w-16 h-1.5 bg-slate-900 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-gradient-to-r from-pink-500 to-purple-500 rounded-full" 
                              style={{ width: `${med.protocolRelevance}%` }} 
                            />
                          </div>
                          <span className="text-[10px] font-bold font-mono text-slate-300">{med.protocolRelevance}%</span>
                        </div>
                      </div>

                      <div className="p-1 px-1.5 bg-slate-900 rounded-lg group-hover:bg-slate-850 transition-all text-slate-400">
                        {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </div>
                    </div>
                  </div>

                  {/* Expanded Body section */}
                  {isExpanded && (
                    <div className="border-t border-slate-900 p-4 space-y-4 bg-slate-900/20 text-xs text-left animate-[fadeIn_0.2s_ease-out]">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Dynamic fields */}
                        <div className="space-y-3">
                          <div>
                            <span className="text-[9.5px] uppercase font-mono text-slate-500 tracking-wider block font-bold mb-1">Mechanism / How It Works</span>
                            <p className="text-slate-300 font-sans leading-relaxed pl-1 border-l-2 border-purple-505/20 bg-slate-900/30 p-2 rounded">
                              <b>Mechanism of Action:</b> {med.howItWorks}
                            </p>
                          </div>

                          <div>
                            <span className="text-[9.5px] uppercase font-mono text-slate-500 tracking-wider block font-bold mb-1">Efficacy Guidance / Common Dosage</span>
                            <p className="text-pink-400 font-mono tracking-tight pl-1 flex items-center gap-1">
                              <Calendar className="w-3.5 h-3.5 shrink-0" />
                              {med.commonDosage}
                            </p>
                          </div>

                          <div>
                            <span className="text-[9.5px] uppercase font-mono text-slate-500 tracking-wider block font-bold mb-1">Administration Route</span>
                            <p className="text-slate-300 font-sans tracking-wide pl-1.5 flex items-center gap-1.5">
                              <span className="w-1.5 h-1.5 bg-teal-450 rounded-full inline-block" />
                              {med.administration}
                            </p>
                          </div>
                        </div>

                        {/* Side effects list and prescriber planner input */}
                        <div className="space-y-4">
                          <div>
                            <span className="text-[9.5px] uppercase font-mono text-slate-500 tracking-wider block font-bold mb-1.5">Primary Adverse Side Effects</span>
                            <div className="flex flex-wrap gap-1.5 pl-1">
                              {med.sideEffects.map((se) => (
                                <span key={se} className="px-2 py-0.5 rounded text-[9.5px] font-bold bg-rose-950/20 border border-rose-900/25 text-rose-450">
                                  ⚠️ {se}
                                </span>
                              ))}
                            </div>
                          </div>

                          {/* Quick prescriptive notes builder */}
                          <div className="bg-slate-950/90 border border-slate-850 p-3 rounded-lg space-y-2">
                            <span className="text-[9.5px] uppercase font-mono text-pink-400 font-bold tracking-wider block">Prescriber Custom Addendum</span>
                            
                            <div className="flex gap-2">
                              <input
                                type="text"
                                placeholder="E.g. Cycles 1-4. Baseline hepatic panel tests..."
                                value={customDosageNotes[med.name] || ""}
                                onChange={(e) => setCustomDosageNotes(prev => ({ ...prev, [med.name]: e.target.value }))}
                                className="flex-1 bg-slate-900 border border-slate-800 text-slate-200 text-[10.5px] px-2.5 py-1.5 rounded-lg focus:border-pink-500/30 transition-colors"
                              />
                              <button
                                type="button"
                                onClick={() => handleAddOrder(med)}
                                className="bg-pink-500 hover:bg-pink-450 text-slate-950 font-extrabold font-mono text-[10.5px] px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1 shrink-0 select-none cursor-pointer"
                              >
                                <Plus className="w-3.5 h-3.5" /> Plan Order
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* ⚠️ Medical Disclaimer Section */}
      <div className="bg-red-950/15 border border-red-500/20 p-4 rounded-xl flex items-start gap-3 select-none">
        <ShieldAlert className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
        <div className="space-y-1 text-left">
          <span className="text-[10px] font-mono font-bold text-red-400 uppercase tracking-wider block flex items-center gap-1">
            <AlertTriangle className="w-3.5 h-3.5 animate-bounce" /> ⚠️ Medical Disclaimer
          </span>
          <p className="text-slate-400 text-[10.5px] leading-relaxed font-medium font-sans">
            "These medicines are provided for educational and informational purposes only. Actual treatment decisions, medicine selection, and dosage must be determined by a qualified oncologist based on the patient's cancer type, stage, medical history, laboratory reports, and overall health condition."
          </p>
        </div>
      </div>
    </div>
  );
}
