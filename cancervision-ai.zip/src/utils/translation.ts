export type Language = "en" | "es" | "fr" | "de" | "ar";

export const LANGUAGES: Record<Language, { label: string; flag: string; dir: "ltr" | "rtl" }> = {
  en: { label: "English", flag: "🇺🇸", dir: "ltr" },
  es: { label: "Español", flag: "🇪🇸", dir: "ltr" },
  fr: { label: "Français", flag: "🇫🇷", dir: "ltr" },
  de: { label: "Deutsch", flag: "🇩🇪", dir: "ltr" },
  ar: { label: "العربية", flag: "🇸🇦", dir: "rtl" },
};

export const UI_TRANSLATIONS: Record<Language, Record<string, string>> = {
  en: {
    title: "Diagnostic Assessment Result",
    cancerType: "Cancer Type",
    organ: "Affected Organ/Zone",
    confidence: "Model Confidence",
    riskLevel: "Risk Level",
    prediction: "Primary Prediction",
    findings: "Clinical Findings",
    recommendations: "Pathology Recommendations",
    high: "High",
    medium: "Medium",
    low: "Low",
    noDiagnosis: "No oncology study loaded. Upload an image or select a sample case.",
  },
  es: {
    title: "Resultado de la Evaluación Diagnóstica",
    cancerType: "Tipo de Cáncer",
    organ: "Órgano/Zona Afectada",
    confidence: "Confianza del Modelo",
    riskLevel: "Nivel de Riesgo",
    prediction: "Predicción Primaria",
    findings: "Hallazgos Clínicos",
    recommendations: "Recomendaciones Patológicas",
    high: "Alto",
    medium: "Medio",
    low: "Bajo",
    noDiagnosis: "No se ha cargado ningún estudio oncológico. Suba una imagen o seleccione un caso de muestra.",
  },
  fr: {
    title: "Résultat de l'Évaluation Diagnostique",
    cancerType: "Type de Cancer",
    organ: "Organe/Zone Affecté",
    confidence: "Confiance du Modèle",
    riskLevel: "Niveau de Risque",
    prediction: "Prédiction Primaire",
    findings: "Observations Cliniques",
    recommendations: "Recommandations Pathologiques",
    high: "Élevé",
    medium: "Modéré",
    low: "Faible",
    noDiagnosis: "Aucune étude oncologique chargée. Téléchargez une image ou sélectionnez un cas.",
  },
  de: {
    title: "Ergebnis der diagnostischen Bewertung",
    cancerType: "Krebsart",
    organ: "Betroffenes Organ/Zone",
    confidence: "Modellkonfidenz",
    riskLevel: "Risikostufe",
    prediction: "Primäre Vorhersage",
    findings: "Klinische Befunde",
    recommendations: "Pathologische Empfehlungen",
    high: "Hoch",
    medium: "Mittel",
    low: "Niedrig",
    noDiagnosis: "Keine Onkologiestudie geladen. Laden Sie ein Bild hoch oder wählen Sie ein Muster aus.",
  },
  ar: {
    title: "نتائج التقييم التشخيصي",
    cancerType: "نوع السرطان",
    organ: "العضو/المنطقة المصابة",
    confidence: "درجة ثقة النموذج",
    riskLevel: "مستوى الخطورة",
    prediction: "التنبؤ الأولي",
    findings: "النتائج السريرية",
    recommendations: "توصيات علم الأمراض",
    high: "مرتفع",
    medium: "متوسط",
    low: "منخفض",
    noDiagnosis: "لم يتم تحميل أي دراسة أورام. يرجى تحميل صورة أو تحديد حالة نموذجية.",
  }
};

// Precise medical sentence translations for pre-seeded template records to maintain high clinical fidelity
export const SENTENCE_TRANSLATIONS: Record<string, Record<Language, string>> = {
  // Cancer types
  "Brain Tumor": { en: "Brain Tumor", es: "Tumor Cerebral", fr: "Tumeur Cérébrale", de: "Hirntumor", ar: "ورم الدماغ" },
  "Lung Cancer": { en: "Lung Cancer", es: "Cáncer de Pulmón", fr: "Cancer du Poumon", de: "Lungenkrebs", ar: "سرطان الرئة" },
  "Skin Cancer": { en: "Skin Cancer", es: "Cáncer de Piel", fr: "Cancer de la Peau", de: "Hautkrebs", ar: "سرطان الجلد" },
  "Breast Cancer": { en: "Breast Cancer", es: "Cáncer de Mama", fr: "Cancer du Sein", de: "Brustkrebs", ar: "سرطان الثدي" },
  "Oral Cancer": { en: "Oral Cancer", es: "Cáncer Oral", fr: "Cancer de la Bouche", de: "Mundhöhlenkrebs", ar: "سرطان الفم" },
  "Colon Cancer": { en: "Colon Cancer", es: "Cáncer de Colon", fr: "Cancer du Colon", de: "Darmkrebs", ar: "سرطان القولون" },
  "Cervical Cancer": { en: "Cervical Cancer", es: "Cáncer Cervical", fr: "Cancer du Col de l'Utérus", de: "Gebärmutterhalskrebs", ar: "سرطان عنق الرحم" },
  "Prostate Cancer": { en: "Prostate Cancer", es: "Cáncer de Próstata", fr: "Cancer de la Prostate", de: "Prostatakrebs", ar: "سرطان البروستاتا" },
  "Liver Cancer": { en: "Liver Cancer", es: "Cáncer de Hígado", fr: "Cancer du Foie", de: "Leberkrebs", ar: "سرطان الكبد" },
  "Stomach Cancer": { en: "Stomach Cancer", es: "Cáncer de Estómago", fr: "Cancer de l'Estomac", de: "Magenkrebs", ar: "سرطان المعدة" },
  "Pancreatic Cancer": { en: "Pancreatic Cancer", es: "Cáncer de Páncreas", fr: "Cancer du Pancréas", de: "Bauchspeicheldrüsenkrebs", ar: "سرطان البنكرياس" },
  "Kidney Cancer": { en: "Kidney Cancer", es: "Cáncer de Riñón", fr: "Cancer du Rein", de: "Nierenkrebs", ar: "سرطان الكلى" },
  "Bladder Cancer": { en: "Bladder Cancer", es: "Cáncer de Vejiga", fr: "Cancer de la Vessie", de: "Blasenkrebs", ar: "سرطان المثانة" },
  "Thyroid Cancer": { en: "Thyroid Cancer", es: "Cáncer de Tiroides", fr: "Cancer de la Thyroïde", de: "Schilddrüsenkrebs", ar: "سرطان الغدة الدرقية" },
  "Ovarian Cancer": { en: "Ovarian Cancer", es: "Cáncer de Ovario", fr: "Cancer de l'Ovaire", de: "Eierstockkrebs", ar: "سرطان المبيض" },
  "Uterine Cancer": { en: "Uterine Cancer", es: "Cáncer de Útero", fr: "Cancer de l'Utérus", de: "Gebärmutterkrebs", ar: "سرطان الرحم" },
  "Esophageal Cancer": { en: "Esophageal Cancer", es: "Cáncer de Esófago", fr: "Cancer de l'Œsophage", de: "Speiseröhrenkrebs", ar: "سرطان المريء" },
  "Testicular Cancer": { en: "Testicular Cancer", es: "Cáncer de Testículo", fr: "Cancer du Testicule", de: "Hodenkrebs", ar: "سرطان الخصية" },
  "Laryngeal Cancer": { en: "Laryngeal Cancer", es: "Cáncer de Laringe", fr: "Cancer du Larynx", de: "Kehlkopfkrebs", ar: "سرطان الحنجرة" },
  "Gallbladder Cancer": { en: "Gallbladder Cancer", es: "Cáncer de Vesícula Biliar", fr: "Cancer de la Vésicule Biliaire", de: "Gallenblasenkrebs", ar: "سرطان المرارة" },
  "Rectal Cancer": { en: "Rectal Cancer", es: "Cáncer de Recto", fr: "Cancer du Rectum", de: "Rektumkarzinom", ar: "سرطان المستقيم" },
  "Anal Cancer": { en: "Anal Cancer", es: "Cáncer de Ano", fr: "Cancer de l'Anus", de: "Analkrebs", ar: "سرطان الشرج" },
  "Penile Cancer": { en: "Penile Cancer", es: "Cáncer de Pene", fr: "Cancer du Pénis", de: "Peniskrebs", ar: "سرطان القضيب" },
  "Vaginal Cancer": { en: "Vaginal Cancer", es: "Cáncer de Vagina", fr: "Cancer du Vagin", de: "Scheidenkrebs", ar: "سرطان المهبل" },
  "Vulvar Cancer": { en: "Vulvar Cancer", es: "Cáncer de Vulva", fr: "Cancer de la Vulve", de: "Vulvakrebs", ar: "سرطان الفرج" },
  "Bone Cancer": { en: "Bone Cancer", es: "Cáncer de Hueso", fr: "Cancer des Os", de: "Knochenkrebs", ar: "سرطان العظام" },
  "Leukemia": { en: "Leukemia", es: "Leucemia", fr: "Leucémie", de: "Leukämie", ar: "سرطان الدم" },
  "Lymphoma": { en: "Lymphoma", es: "Linfoma", fr: "Lymphome", de: "Lymphom", ar: "سرطان الغدد الليمفاوية" },
  "Multiple Myeloma": { en: "Multiple Myeloma", es: "Mieloma Múltiple", fr: "Myélome Multiple", de: "Multiples Myelom", ar: "الميلوما المتعددة" },
  "Retinoblastoma": { en: "Retinoblastoma", es: "Retinoblastoma", fr: "Rétinoblastome", de: "Retinoblastom", ar: "ورم الأرومة الشبكية" },

  // Organs
  "MRI": { en: "Brain / Cranial anatomy", es: "Cerebro / Anatomía craneal", fr: "Cerveau / Anatomie crânienne", de: "Gehirn / Schädelanatomie", ar: "الدماغ / تشريح الجمجمة" },
  "CT": { en: "Pulmonary / Lung parenchyma", es: "Pulmonar / Parénquima pulmonar", fr: "Pulmonaire / Parenchyme pulmonaire", de: "Lunge / Lungenparenchym", ar: "الرئة / نسيج الرئة" },
  "Skin Image": { en: "Dermal epidermal junction", es: "Unión dermoepidérmica", fr: "Jonction dermo-épidermique", de: "Dermal-epidermale Junktion", ar: "الوصل البشروي الأدمي" },

  // Predictions
  "Astrocytoma suspicious grade IV glioblastoma mass": {
    en: "Astrocytoma suspicious grade IV glioblastoma mass",
    es: "Astrocitoma sospechoso de masa de glioblastoma de grado IV",
    fr: "Astrocytome suspect d'une masse de glioblastome de grade IV",
    de: "Astrozytom verdächtig auf Glioblastom-Masse Grad IV",
    ar: "ورم نجمي يشتبه في كونه كتلة ورم أرومي دبقي من الدرجة الرابعة"
  },
  "Spiculed Solitary Pulmonary Nodule (Oncology Grade II)": {
    en: "Spiculed Solitary Pulmonary Nodule (Oncology Grade II)",
    es: "Nódulo pulmonar solitario espiculado (Grado oncológico II)",
    fr: "Nodule pulmonaire solitaire spiculé (Grade oncologique II)",
    de: "Spikulierter solitärer Lungenrundherd (Onkologischer Grad II)",
    ar: "عقدة رئوية منفردة شائكة (درجة الأورام الثانية)"
  },
  "Basal Cell Carcinoma / Early Stage Melanoma Indicators": {
    en: "Basal Cell Carcinoma / Early Stage Melanoma Indicators",
    es: "Carcinoma basocelular / Indicadores de melanoma en etapa temprana",
    fr: "Carcinome basocellulaire / Indicateurs de mélanome à un stade précoce",
    de: "Basalzellkarzinom / Indikatoren für ein Melanom im Frühstadium",
    ar: "سرطان الخلايا القاعدية / مؤشرات الميلانوم في مرحلة مبكرة"
  },

  // Findings - Brain
  "Large expansive ring-enhancing visual mass of size 34 x 28 mm in left cortex.": {
    en: "Large expansive ring-enhancing visual mass of size 34 x 28 mm in left cortex.",
    es: "Gran masa visual expansiva con realce en anillo de 34 x 28 mm en la corteza izquierda.",
    fr: "Grande masse expansive rehaussée par un anneau de 34 x 28 mm dans le cortex gauche.",
    de: "Große expansive, ringförmig anreichernde visuelle Masse von 34 x 28 mm im linken Kortex.",
    ar: "كتلة بصرية كبيرة متسعة تعززها حلقة بحجم 34 × 28 مم في القشرة اليسرى."
  },
  "Considerable edema surrounding the localized margins.": {
    en: "Considerable edema surrounding the localized margins.",
    es: "Edema considerable alrededor de los márgenes localizados.",
    fr: "Œdème considérable entourant les marges localisées.",
    de: "Erhebliches Ödem um die lokalisierten Ränder.",
    ar: "وذمة كبيرة تحيط بالحواف المحددة."
  },
  "Clear compression on the neighboring ventricular wall structures.": {
    en: "Clear compression on the neighboring ventricular wall structures.",
    es: "Compresión clara sobre las estructuras de la pared ventricular vecina.",
    fr: "Compression nette sur les structures de la paroi ventriculaire voisine.",
    de: "Deutliche Kompression der benachbarten Ventrikelwandstrukturen.",
    ar: "ضغط واضح على هياكل جدار البطين المجاور."
  },

  // Recommendations - Brain
  "Arrange high-priority neurological biopsy assessment.": {
    en: "Arrange high-priority neurological biopsy assessment.",
    es: "Organizar una evaluación de biopsia neurológica de alta prioridad.",
    fr: "Organiser une évaluation de biopsie neurologique de haute priorité.",
    de: "Neurologische Biopsie mit hoher Priorität arrangieren.",
    ar: "ترتيب إجراء تقييم خزعة عصبية عالي الأولوية."
  },
  "Introduce immediate edema reduction corticosteroids.": {
    en: "Introduce immediate edema reduction corticosteroids.",
    es: "Introducir corticoesteroides inmediatos para reducir el edema.",
    fr: "Introduire des corticostéroïdes immédiats pour la réduction de l'œdème.",
    de: "Sofortige Kortikosteroide zur Ödemreduktion verabreichen.",
    ar: "إعطاء الكورتيكوستيرويدات الفورية لتقليل الوذمة."
  },
  "Schedule cranial contrast telemetry updates to verify progression indices.": {
    en: "Schedule cranial contrast telemetry updates to verify progression indices.",
    es: "Programar actualizaciones de telemetría de contraste craneal para verificar los índices de progresión.",
    fr: "Planifier des mises à jour de télémétrie de contraste crânien pour vérifier les indices de progression.",
    de: "Schädel-Kontrast-Telemetrie planen, um Progressionsindizes zu überprüfen.",
    ar: "جدولة تحديثات القياس عن بعد للنقائل القحفية للتحقق من مؤشرات تقدم المرض."
  },

  // Findings - Lung
  "Peripheral 14mm nodule with high surface density in the right lung lobe.": {
    en: "Peripheral 14mm nodule with high surface density in the right lung lobe.",
    es: "Nódulo periférico de 14 mm con alta densidad superficial en el lóbulo pulmonar derecho.",
    fr: "Nodule périphérique de 14 mm à haute densité de surface dans le lobe pulmonaire droit.",
    de: "Peripherer 14-mm-Rundherd mit hoher Oberflächendichte im rechten Lungenlappen.",
    ar: "عقدة جانبية بحجم 14 مم ذات كثافة سطحية عالية في الفص الرئوي الأيمن."
  },
  "Spiculated borders showing early signs of visceral pleural traction lines.": {
    en: "Spiculated borders showing early signs of visceral pleural traction lines.",
    es: "Márgenes espiculados que muestran signos tempranos de líneas de tracción pleural visceral.",
    fr: "Bords spiculés montrant des signes précoces de lignes de traction de la plèvre viscérale.",
    de: "Spikulierte Ränder mit frühen Anzeichen von viszeralen pleuralen Traktionslinien.",
    ar: "حواف شائكة تظهر علامات مبكرة لخطوط سحب الجنب الحشوية."
  },
  "Vascular congestion targeting direct nodule roots.": {
    en: "Vascular congestion targeting direct nodule roots.",
    es: "Congestión vascular dirigida directamente a las raíces del nódulo.",
    fr: "Congestion vasculaire ciblant les racines directes du nodule.",
    de: "Gefäßstauung, die direkt auf die Wurzeln des Rundherdes abzielt.",
    ar: "احتقان وعائي يستهدف جذور العقدة مباشرة."
  },

  // Recommendations - Lung
  "Recommend low-dose lung CT re-scans in 4 weeks.": {
    en: "Recommend low-dose lung CT re-scans in 4 weeks.",
    es: "Recomendar volver a realizar una TC de pulmón de dosis baja en 4 semanas.",
    fr: "Recommander de refaire un scanner pulmonaire à faible dose dans 4 semaines.",
    de: "Niedrigdosis-Lungen-CT-Wiederholung in 4 Wochen empfohlen.",
    ar: "توصية بإعادة فحص الصدر بالأشعة المقطعية بجرعة منخفضة خلال 4 أسابيع."
  },
  "Coordinate high-precision PET-CT to evaluate hypermetabolism.": {
    en: "Coordinate high-precision PET-CT to evaluate hypermetabolism.",
    es: "Coordinar PET-TC de alta precisión para evaluar el hipermetabolismo.",
    fr: "Coordonner un TEP-scan de haute précision pour évaluer l'hypermétabolisme.",
    de: "Hochpräzise PET-CT zur Bewertung des Hypermetabolismus koordinieren.",
    ar: "تنسيق فحص التصوير المقطعي بالإصدار البوزيتروني (PET-CT) عالي الدقة لتقييم فرط الاستقلاب."
  },
  "Evaluate eligibility for immediate robotic-assisted bronchoscopy biopsy.": {
    en: "Evaluate eligibility for immediate robotic-assisted bronchoscopy biopsy.",
    es: "Evaluar la elegibilidad para una biopsia por broncoscopia asistida por robot inmediata.",
    fr: "Évaluer l'éligibilité pour une biopsie par bronchoscopie assistée par robot immédiate.",
    de: "Eignung für eine sofortige roboterassistierte Bronchoskopie-Biopsie prüfen.",
    ar: "تقييم الأهلية لإجراء خزعة فورية عبر تنظير القصبات بمساعدة الروبوت."
  },

  // Findings - Skin
  "Slightly asymmetric melanocytic cluster with minor color variegation.": {
    en: "Slightly asymmetric melanocytic cluster with minor color variegation.",
    es: "Grupo melanocítico ligeramente asimétrico con menor variegación de color.",
    fr: "Amas mélanocytaire légèrement asymétrique avec une légère variation de couleur.",
    de: "Leicht asymmetrischer melanozytärer Cluster mit geringer Farbabweichung.",
    ar: "تكتل أسوداني غير متماثل قليلاً مع تباين طفيف في اللون."
  },
  "Irregular border contours but holds a diameter under 6mm.": {
    en: "Irregular border contours but holds a diameter under 6mm.",
    es: "Contornos de borde irregulares pero mantiene un diámetro menor de 6 mm.",
    fr: "Contours des bords irréguliers mais conserve un diamètre inférieur à 6 mm.",
    de: "Unregelmäßige Grenzkonturen, hält jedoch einen Durchmesser unter 6 mm.",
    ar: "خطوط حواف غير منتظمة ولكن قطرها يقل عن 6 مم."
  },
  "Absence of secondary surrounding satellitosis nodes.": {
    en: "Absence of secondary surrounding satellitosis nodes.",
    es: "Ausencia de nódulos de satelitosis circundantes secundarios.",
    fr: "Absence de nodules de satellitose environnants secondaires.",
    de: "Fehlen von sekundär umgebenden Satellitosis-Knoten.",
    ar: "غياب العقد التابعة المحيطة الثانوية."
  },

  // Recommendations - Skin
  "Monitor monthly skin borders strictly using standard ABCDE guidelines.": {
    en: "Monitor monthly skin borders strictly using standard ABCDE guidelines.",
    es: "Monitorear mensualmente los bordes de la piel estrictamente utilizando las pautas ABCDE estándar.",
    fr: "Surveiller mensuellement et strictement les contours de la peau selon les critères ABCDE classiques.",
    de: "Monatliche strenge Überwachung der Hautgrenzen nach den Standard-ABCDE-Richtlinien.",
    ar: "مراقبة حدود الجلد شهرياً بدقة باستخدام إرشادات ABCDE القياسية."
  },
  "Dermatology visual consultation for potential clinical excision study.": {
    en: "Dermatology visual consultation for potential clinical excision study.",
    es: "Consulta visual de dermatología para un posible estudio de escisión clínica.",
    fr: "Consultation visuelle en dermatologie pour une éventuelle étude d'excision clinique.",
    de: "Dermatologische visuelle Konsultation für eine mögliche klinische Exzisionsstudie.",
    ar: "استشارة بصرية في عيادة الجلدية لإمكانية إجراء دراسة استئصال سريري."
  },
  "Apply high factor UV protectants constantly on the focal dermal interface.": {
    en: "Apply high factor UV protectants constantly on the focal dermal interface.",
    es: "Aplicar protectores UV de alto factor constantemente en la interfaz dérmica focal.",
    fr: "Appliquer constamment des protecteurs UV à indice élevé sur l'interface cutanée focale.",
    de: "Ständig UV-Schutzmittel mit hohem Lichtschutzfaktor auf die dermale Schnittstelle auftragen.",
    ar: "وضع واقيات شمسية ذات عامل حماية عالٍ باستمرار على منطقة الجلد المصابة."
  }
};

// A fallback helper function that dynamically maps or translates generic texts (perfect for dynamic real AI responses)
export function translateText(text: string, lang: Language): string {
  if (!text) return "";
  const cleanText = text.trim();
  
  // Check direct sentence dictionary
  if (SENTENCE_TRANSLATIONS[cleanText] && SENTENCE_TRANSLATIONS[cleanText][lang]) {
    return SENTENCE_TRANSLATIONS[cleanText][lang];
  }
  
  // Basic vocabulary fallback dictionary for dynamic Gemini phrases
  const vocabulary: Record<string, Record<Language, string>> = {
    "astrocytoma": { en: "astrocytoma", es: "astrocitoma", fr: "astrocytome", de: "Astrozytom", ar: "ورم نجمي" },
    "glioblastoma": { en: "glioblastoma", es: "glioblastoma", fr: "glioblastome", de: "Glioblastom", ar: "ورم أرومي دبقي" },
    "tumor": { en: "tumor", es: "tumor", fr: "tumeur", de: "Tumor", ar: "ورم" },
    "cancer": { en: "cancer", es: "cáncer", fr: "cancer", de: "Krebs", ar: "سرطان" },
    "nodule": { en: "nodule", es: "nódulo", fr: "nodule", de: "Rundherd", ar: "عقدة" },
    "lesion": { en: "lesion", es: "lesión", fr: "lésion", de: "Läsion", ar: "آفة" },
    "melanoma": { en: "melanoma", es: "melanoma", fr: "mélanome", de: "Melanom", ar: "ميلانوما" },
    "carcinoma": { en: "carcinoma", es: "carcinoma", fr: "carcinome", de: "Karzinom", ar: "سرطانة" },
    "high risk": { en: "High Risk", es: "Riesgo Alto", fr: "Risque Élevé", de: "Hohes Risiko", ar: "خطر مرتفع" },
    "medium risk": { en: "Medium Risk", es: "Riesgo Medio", fr: "Risque Modéré", de: "Mittleres Risiko", ar: "خطر متوسط" },
    "low risk": { en: "Low Risk", es: "Riesgo Bajo", fr: "Risque Faible", de: "Niedriges Risiko", ar: "خطر منخفض" },
    "brain": { en: "Brain", es: "Cerebro", fr: "Cerveau", de: "Gehirn", ar: "الدماغ" },
    "lung": { en: "Lung", es: "Pulmón", fr: "Poumon", de: "Lunge", ar: "الرئة" },
    "skin": { en: "Skin", es: "Piel", fr: "Peau", de: "Haut", ar: "الجلد" },
    "breast": { en: "Breast", es: "Mama", fr: "Sein", de: "Brust", ar: "الثدي" },
  };

  let translated = cleanText;

  // Let's do simple word replacements if no full sentence is mapped
  for (const [key, value] of Object.entries(vocabulary)) {
    const regex = new RegExp(`\\b${key}\\b`, "gi");
    if (regex.test(translated)) {
      translated = translated.replace(regex, value[lang]);
    }
  }

  // If language is Arabic, we can prefix or translate the structure nicely, or just return the mapped word/fallback
  return translated;
}
